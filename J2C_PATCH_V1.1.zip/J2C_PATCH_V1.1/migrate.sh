#!/usr/bin/env bash
# Run / inspect the J2C database migrations (0003-0006 are new in V1.1; all are additive).
#   ./migrate.sh --bot-dir /home/ubuntu/YOUR_BOT [--python PATH] [--status] [--db /path/j2c.db]
set -euo pipefail
BOT_DIR=""; PY=""; ARGS=()
while [ $# -gt 0 ]; do case "$1" in
  --bot-dir) BOT_DIR="$2"; shift 2;; --python) PY="$2"; shift 2;;
  --status) ARGS+=(--status); shift;; --db) ARGS+=(--db "$2"); shift 2;;
  *) echo "unknown option $1"; exit 1;; esac; done
[ -d "$BOT_DIR/j2c" ] || { echo "--bot-dir must contain j2c/"; exit 1; }
if [ -z "$PY" ]; then for p in "$BOT_DIR/venv/bin/python" "$BOT_DIR/.venv/bin/python" "$(command -v python3)"; do [ -x "$p" ] && { PY="$p"; break; }; done; fi
cd "$BOT_DIR" && exec "$PY" -m j2c.db.migrate "${ARGS[@]}"
