# 💀 DEATH DEVELOPMENT — J2C PATCH V1.1 (incremental)

Upgrades an **existing J2C v1.0.x** install on your AWS Ubuntu bot to **1.1.0**. It contains only the
22 new/modified files, the DB migrations, an installer with an **automatic pre-install backup**, and a
verifier. Your `.env`, tokens, cogs, config, other bot files, database records and your uploaded J2C
image are never overwritten. There is **no rollback script and no rollback feature** in this patch.

## What's new
| Feature | How it works |
|---|---|
| Owner-based VC names | Default template is `{username}Vc` → `deathdevVc`. Follows the new owner on transfer/claim/auto-transfer **until the room is manually renamed** (then the name is pinned). Change it: `/j2c config name_template "{username} Vc"` or Customize → Naming. Servers still on the old stock template are moved to the new one; customised templates are kept. |
| Persistent J2C menu channel | `/j2c menu` creates a read-only `🎛️・j2c-menu` text channel with the menu (your image as banner). Buttons act on the room the clicker is in. Survives restarts; re-posted if the message/channel changes. `/j2c menu #channel` uses an existing channel. |
| Admin Customize panel | `/j2c customize` or the **⚙️ Customize** button on the menu (Manage Server / Administrator only). Pages: Buttons · Permissions · Menu channel · Naming. |
| Buttons: edit / add / remove / restore / reorder | Edit label, emoji, style, section heading. Add **info** (shows text) or **link** buttons. Remove is reversible (Restore / Restore all). Up/Down reorders. Reset layout returns to stock. Panels refresh automatically. |
| Category permissions | Categories: Privacy, Members, Settings, Room. Each can be **Allow / Deny / Inherit** for: VC owners, Administrators, Trusted roles (you choose which roles), any custom role (incl. @everyone), individual members. |
| Charcoal theme | Red accents removed; accent `#2B2D31`; all buttons grey. (Red button style is intentionally not offered.) |

### Permission rules (simple version)
Start: owner + admins allowed, everyone else denied (Claim: anyone in the room, as before). Then rules apply
in order **owner/admin/trusted → custom roles → individual member**. Deny beats Allow within a level; a
member rule is final. No rule = Inherit. People who are not owner/admin must be **inside the voice channel**.
Admin tools are never blocked by these rules.

---
## 1 · Upload (run on YOUR computer)
```bash
KEY=~/.ssh/YOUR_KEY.pem
HOST=ubuntu@YOUR_EC2_PUBLIC_IP
scp -i "$KEY" J2C_PATCH_V1.1.zip "$HOST":/home/ubuntu/
```
(Windows PowerShell: `scp -i C:\path\YOUR_KEY.pem .\J2C_PATCH_V1.1.zip ubuntu@YOUR_EC2_PUBLIC_IP:/home/ubuntu/`)

## 2 · Extract (on the server)
```bash
ssh -i ~/.ssh/YOUR_KEY.pem ubuntu@YOUR_EC2_PUBLIC_IP
sudo apt-get install -y unzip            # only if unzip is missing
cd /home/ubuntu
rm -rf J2C_PATCH_V1.1 && unzip -o J2C_PATCH_V1.1.zip
cd J2C_PATCH_V1.1
chmod +x install.sh verify.sh migrate.sh
```

## 3 · Dry run (changes nothing)
```bash
BOT_DIR=/home/ubuntu/YOUR_BOT_FOLDER     # contains your main file, .env and the j2c/ folder
./install.sh --bot-dir "$BOT_DIR" --dry-run
```
It finds your venv Python and systemd service, verifies checksums, and compile-checks the new files.
If detection guesses wrong add `--python /path/to/venv/bin/python` and/or `--service YOUR_SERVICE`.

## 4 · Install (backup → copy → migrate → restart → health check)
```bash
./install.sh --bot-dir "$BOT_DIR" --service YOUR_SERVICE
```
* **Automatic backup first**: `$BOT_DIR/.j2c_backups/pre-V1.1.0_<timestamp>_from-<version>/` holds a tarball of
  `j2c/` and a consistent SQLite copy of `data/j2c.db`. If the backup fails, nothing is changed.
* Only the files listed in `MANIFEST.sha256` (all under `j2c/`) are copied.
* If a step fails the installer stops with a clear message and **does not restart your bot**.
* Not systemd (pm2/docker)? add `--no-restart` and restart your bot yourself.

## 5 · Migrations (the installer already ran them; manual equivalents)
```bash
./migrate.sh --bot-dir "$BOT_DIR" --status     # applied / pending
./migrate.sh --bot-dir "$BOT_DIR"              # apply pending
```
New, additive migrations: `0003_menu`, `0004_buttons`, `0005_permissions`, `0006_owner_naming`
(adds `j2c_channels.auto_named`, moves only the stock name template). Existing rows are kept.

## 6 · Restart / logs
```bash
sudo systemctl restart YOUR_SERVICE
sudo journalctl -u YOUR_SERVICE -n 100 --no-pager | grep -i j2c
# expected: [J2C] ready v1.1.0 ...   and   [J2C] startup complete
```

## 7 · Verify
```bash
./verify.sh --bot-dir "$BOT_DIR" --service YOUR_SERVICE
systemctl status YOUR_SERVICE --no-pager | head -5
```

## 8 · Live check in Discord (~10 min, please do this once)
1. `/j2c` → shows Menu channel line. (If new commands are missing, restart once more or run `/j2c sync`.)
2. `/j2c menu` → menu channel appears with your image + grey buttons.
3. Join the hub → room named `<username>Vc`; panel posted inside it. Click Lock/Unlock/Limit/Rename etc.
4. From a second account (not owner): buttons must be refused. In **Customize → Permissions** give that account's
   role *Allow* on Privacy; they join the room and Lock now works, Rename still refused.
5. **Customize → Buttons**: edit a label, move one up, remove one, restore it, add an info button — the menu and
   open room panels update within ~2 s.
6. Restart the bot; the menu buttons still work without re-posting.

## Notes & limits
* Discord allows 40 components per message; the editor refuses layouts that don't fit (it tells you).
* Channel renames are rate-limited by Discord (2 per 10 min); a skipped auto-rename keeps the old name.
* Old room panels posted before the update keep working; removed buttons answer "disabled by admins".
* Interpretation of `"{username}"Vc`: channel name = username immediately followed by `Vc`. Want a space or
  quotes? change the template (above).
* Backups are kept in `.j2c_backups/` (not auto-deleted). Your earlier `.j2c_patch/` folder is untouched.
