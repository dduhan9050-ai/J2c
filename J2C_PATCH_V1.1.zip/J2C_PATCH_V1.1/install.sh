#!/usr/bin/env bash
# DEATH DEVELOPMENT - J2C PATCH V1.1 installer (incremental; v1.0.x -> v1.1.0)
#
#   ./install.sh --bot-dir /home/ubuntu/YOUR_BOT [--service NAME] [--python PATH] [--no-restart] [--dry-run]
#
# Steps: pre-checks -> AUTOMATIC BACKUP -> verify payload -> copy only the patch files -> migrate DB
#        -> restart -> health check.
# Touches ONLY <bot>/j2c/ (the files listed in MANIFEST.sha256) and <bot>/.j2c_backups/.
# Never reads or writes .env, tokens, your cogs/config, or any other bot file.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_VERSION="$(tr -d '[:space:]' < "$HERE/VERSION")"
BOT_DIR=""; SERVICE=""; PY=""; DRY=0; NO_RESTART=0; FORCE=0; DB_ARG=()

c() { printf '\033[%sm%s\033[0m\n' "$1" "$2"; }
ok() { c 32 "  ✔ $*"; }
warn() { c 33 "  ! $*"; }
die() { c 31 "  ✘ $*"; exit 1; }
step() { c "1;37" "[$1] $2"; }

while [ $# -gt 0 ]; do
  case "$1" in
    --bot-dir) BOT_DIR="${2:-}"; shift 2;;
    --service) SERVICE="${2:-}"; shift 2;;
    --python) PY="${2:-}"; shift 2;;
    --db) DB_ARG=(--db "${2:-}"); shift 2;;
    --no-restart) NO_RESTART=1; shift;;
    --dry-run) DRY=1; shift;;
    --force) FORCE=1; shift;;
    -h|--help) sed -n '2,10p' "$0"; exit 0;;
    *) die "unknown option: $1";;
  esac
done
[ -n "$BOT_DIR" ] || die "missing --bot-dir (the folder that contains your bot's main file, .env and the j2c/ folder)"
BOT_DIR="$(cd "$BOT_DIR" 2>/dev/null && pwd)" || die "bot directory not found"

c "1" "DEATH DEVELOPMENT • J2C PATCH V$TARGET_VERSION  →  $BOT_DIR"

# ------------------------------------------------------------------ 1. pre-checks
step 1/7 "Pre-checks"
[ -d "$BOT_DIR/j2c" ] || die "$BOT_DIR/j2c not found. This is an incremental patch: install J2C v1.0 first."
[ -w "$BOT_DIR" ] && [ -w "$BOT_DIR/j2c" ] || die "no write permission on $BOT_DIR (run as the user that owns the bot, not root-owned files)"
CUR="$(sed -n 's/^__version__ *= *"\(.*\)"/\1/p' "$BOT_DIR/j2c/__init__.py" | head -1)"
[ -n "$CUR" ] || die "cannot read the installed J2C version"
if [ "$CUR" = "$TARGET_VERSION" ] && [ "$FORCE" = 0 ]; then ok "J2C $CUR is already installed - nothing to do (use --force to re-apply)"; exit 0; fi
case "$CUR" in 1.0.*|1.1.*) ok "installed J2C version: $CUR";; *) die "unsupported installed version $CUR (expected 1.0.x)";; esac
[ -f "$BOT_DIR/j2c/assets/j2c_buttons.png" ] && ok "your J2C image is present (j2c/assets/j2c_buttons.png) and will be kept" \
  || warn "j2c/assets/j2c_buttons.png is missing - the panel banner will be skipped (restore the image from your J2C_PATCH.zip)"

if [ -z "$PY" ]; then
  for cand in "$BOT_DIR/venv/bin/python" "$BOT_DIR/.venv/bin/python" "$BOT_DIR/env/bin/python" "$(command -v python3 || true)"; do
    [ -n "$cand" ] && [ -x "$cand" ] && "$cand" -c 'import discord' >/dev/null 2>&1 && { PY="$cand"; break; }
  done
fi
[ -n "$PY" ] || die "could not find the bot's Python with discord.py installed. Pass it: --python /path/to/venv/bin/python"
"$PY" - <<'PYEOF' || die "discord.py on this interpreter is too old / incomplete for V1.1 (needs >= 2.6). Upgrade: $PY -m pip install -U 'discord.py>=2.6'"
import sys, discord
assert sys.version_info >= (3, 10), "Python 3.10+ required"
assert all(hasattr(discord.ui, n) for n in ("LayoutView", "Container", "RoleSelect", "ChannelSelect", "MediaGallery")), "discord.py too old"
PYEOF
ok "python: $PY"

if [ -z "$SERVICE" ] && command -v systemctl >/dev/null 2>&1; then
  mapfile -t found < <(grep -lE "(WorkingDirectory=|ExecStart=).*${BOT_DIR}" /etc/systemd/system/*.service 2>/dev/null | xargs -r -n1 basename | sed 's/\.service$//')
  if [ "${#found[@]}" -eq 1 ]; then SERVICE="${found[0]}"; ok "systemd service detected: $SERVICE"
  elif [ "${#found[@]}" -gt 1 ]; then die "several services reference this bot (${found[*]}). Pass --service NAME"
  else warn "no systemd service detected - pass --service NAME or restart the bot yourself"; fi
fi

# payload integrity
( cd "$HERE/payload" && sha256sum -c --quiet "$HERE/MANIFEST.sha256" ) || die "patch files are damaged (checksum mismatch). Re-upload the zip."
ok "patch checksums verified ($(wc -l < "$HERE/MANIFEST.sha256") files)"
# scope guard: only j2c/ paths, nothing that could be a secret
if awk '{print $2}' "$HERE/MANIFEST.sha256" | grep -vE '^j2c/[A-Za-z0-9_./-]+$' | grep -q .; then die "manifest contains paths outside j2c/ - refusing"; fi
if awk '{print $2}' "$HERE/MANIFEST.sha256" | grep -qiE '(^|/)\.env|token|secret'; then die "manifest touches a secret-like path - refusing"; fi
# syntax check with the bot's own Python before anything is modified
"$PY" -I - "$HERE/payload" <<'PYEOF' || die "syntax check of the new files failed"
import ast, pathlib, sys
for p in pathlib.Path(sys.argv[1]).rglob("*.py"):
    ast.parse(p.read_text(encoding="utf-8"), str(p))
PYEOF
ok "new files compile with your Python"

DB="$BOT_DIR/data/j2c.db"; [ -n "${J2C_DB_PATH:-}" ] && DB="$J2C_DB_PATH"
if [ "${#DB_ARG[@]}" -gt 0 ]; then DB="${DB_ARG[1]}"; fi
[ -f "$DB" ] && ok "database: $DB" || warn "database $DB not found yet (it will be created by the migrations)"

if [ "$DRY" = 1 ]; then c 32 "Dry run complete - every check passed, nothing was changed."; exit 0; fi

# ------------------------------------------------------------------ 2. automatic backup
step 2/7 "Automatic pre-installation backup"
STAMP="$(date +%Y%m%d-%H%M%S)"
BK="$BOT_DIR/.j2c_backups/pre-V${TARGET_VERSION}_${STAMP}_from-${CUR}"
mkdir -p "$BK"
tar -C "$BOT_DIR" -czf "$BK/j2c_package.tar.gz" j2c || die "backup of j2c/ failed - NOTHING was changed"
tar -tzf "$BK/j2c_package.tar.gz" >/dev/null || die "backup archive is unreadable - NOTHING was changed"
if [ -f "$DB" ]; then
  "$PY" - "$DB" "$BK/j2c.db" <<'PYEOF' || die "database backup failed - NOTHING was changed"
import sqlite3, sys
src = sqlite3.connect(sys.argv[1]); dst = sqlite3.connect(sys.argv[2])
src.backup(dst)                                   # consistent online copy (safe while the bot runs)
ok = dst.execute("PRAGMA integrity_check").fetchone()[0]
dst.close(); src.close()
assert ok == "ok", f"backup integrity check failed: {ok}"
PYEOF
fi
{ echo "created: $(date -Is)"; echo "from_version: $CUR"; echo "to_version: $TARGET_VERSION"; echo "bot_dir: $BOT_DIR"; echo "database: $DB"; } > "$BK/INFO.txt"
ok "backup saved: $BK"

# ------------------------------------------------------------------ 3. copy files
step 3/7 "Installing patch files (only the files in the manifest)"
n=0
while read -r _hash rel; do
  mkdir -p "$BOT_DIR/$(dirname "$rel")"
  cp -f "$HERE/payload/$rel" "$BOT_DIR/$rel"
  n=$((n+1))
done < "$HERE/MANIFEST.sha256"
find "$BOT_DIR/j2c" -name '__pycache__' -type d -prune -exec rm -rf {} + 2>/dev/null || true
( cd "$BOT_DIR" && sha256sum -c --quiet "$HERE/MANIFEST.sha256" 2>/dev/null ) || \
  ( cd "$HERE/payload" && while read -r h rel; do [ "$(sha256sum "$BOT_DIR/$rel" | cut -d' ' -f1)" = "$h" ] || { echo "mismatch: $rel"; exit 1; }; done < "$HERE/MANIFEST.sha256" ) \
  || die "installed files do not match the manifest"
ok "$n file(s) installed; .env, tokens, cogs and your other files were not touched"

# record the new version in the v1.0 install record (cosmetic, keeps old tooling consistent)
"$PY" - "$BOT_DIR/j2c/.j2c_install.json" "$TARGET_VERSION" "$HERE/MANIFEST.sha256" <<'PYEOF' 2>/dev/null || true
import json, sys, pathlib
p = pathlib.Path(sys.argv[1])
if p.exists():
    d = json.loads(p.read_text()); d["version"] = sys.argv[2]
    for line in pathlib.Path(sys.argv[3]).read_text().splitlines():
        h, rel = line.split(None, 1); d.setdefault("files", {})[rel.strip()] = h
    p.write_text(json.dumps(d, indent=2) + "\n")
PYEOF

# ------------------------------------------------------------------ 4. import check
step 4/7 "Import check"
( cd "$BOT_DIR" && "$PY" -I -c "import sys; sys.path.insert(0,'.'); import j2c.bootstrap, j2c.ext, j2c.cogs.commands, j2c.cogs.events, j2c.ui.panel, j2c.ui.admin, j2c.services.menu, j2c.services.rules, j2c.services.layout; print('IMPORT_OK')" ) | grep -q IMPORT_OK \
  || die "J2C failed to import after copying. Your backup is at $BK. The bot was NOT restarted."
ok "all J2C modules import cleanly"

# ------------------------------------------------------------------ 5. migrations
step 5/7 "Database migrations"
( cd "$BOT_DIR" && "$PY" -m j2c.db.migrate "${DB_ARG[@]}" ) || die "migration failed (your database backup is at $BK). The bot was NOT restarted."
ok "database is up to date"

# ------------------------------------------------------------------ 6. restart
step 6/7 "Restart"
if [ "$NO_RESTART" = 1 ] || [ -z "$SERVICE" ]; then
  step 7/7 "Health check"
  warn "skipped (no restart). Restart your bot yourself, then run ./verify.sh --bot-dir $BOT_DIR --service NAME"
else
  SINCE="$(date '+%Y-%m-%d %H:%M:%S')"
  sudo systemctl restart "$SERVICE" || die "systemctl restart $SERVICE failed"
  ok "restarted $SERVICE"
  step 7/7 "Health check"
  good=0
  for _ in $(seq 1 30); do
    sleep 2
    if sudo journalctl -u "$SERVICE" --since "$SINCE" --no-pager 2>/dev/null | grep -q "\[J2C\] ready v$TARGET_VERSION"; then good=1; break; fi
  done
  if [ "$good" = 1 ] && systemctl is-active --quiet "$SERVICE"; then ok "bot is running J2C $TARGET_VERSION"
  else die "J2C $TARGET_VERSION did not report ready. Check: sudo journalctl -u $SERVICE -n 100 --no-pager | grep -i j2c   (backup: $BK)"; fi
fi
c "1;32" "✔ J2C V$TARGET_VERSION installed.  Next: ./verify.sh --bot-dir $BOT_DIR${SERVICE:+ --service $SERVICE}   then run /j2c menu in Discord."
