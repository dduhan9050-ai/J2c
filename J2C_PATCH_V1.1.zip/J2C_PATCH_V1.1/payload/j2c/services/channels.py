"""Core J2C service: temp-channel lifecycle, ownership and channel operations."""
from __future__ import annotations

import asyncio
import logging
import time
from typing import Optional

import discord

from .. import config
from ..db.models import Hub, Profile, TempChannel
from ..db.repository import Repository
from . import names
from .layout import LayoutService
from .rules import RuleService

log = logging.getLogger("j2c.service")

OWNER_PERMS = dict(view_channel=True, connect=True, speak=True, stream=True,
                   move_members=True, mute_members=True, send_messages=True)
BOT_PERMS = dict(view_channel=True, connect=True, manage_channels=True, manage_permissions=True,
                 move_members=True, send_messages=True, embed_links=True, attach_files=True)


class J2CError(Exception):
    """User-facing error (message is shown as-is)."""


def humans(channel: discord.VoiceChannel) -> list[discord.Member]:
    return [m for m in channel.members if not m.bot]


class J2CService:
    def __init__(self, bot, repo: Repository):
        self.bot = bot
        self.repo = repo
        self.layout = LayoutService(repo)
        self.rules = RuleService(repo)
        self.menu = None                            # set by j2c.ext (MenuService)
        self._panel_views: list = []
        self.hubs: dict[int, Hub] = {}
        self.temp: dict[int, TempChannel] = {}
        self.waiting: dict[int, int] = {}          # waiting channel id -> main channel id
        self.loaded = False
        self._delete_tasks: dict[int, asyncio.Task] = {}
        self._grace_tasks: dict[int, asyncio.Task] = {}
        self._user_locks: dict[tuple[int, int], asyncio.Lock] = {}
        self._last_create: dict[int, float] = {}
        self._bg: Optional[asyncio.Task] = None
        self._refresh_tasks: dict[int, asyncio.Task] = {}

    # ------------------------------------------------------------ cache/start
    async def load_cache(self) -> None:
        self.hubs = {h.channel_id: h for h in await self.repo.list_hubs()}
        self.temp = {c.channel_id: c for c in await self.repo.list_channels()}
        self.waiting = {c.waiting_channel_id: c.channel_id for c in self.temp.values() if c.waiting_channel_id}
        self.loaded = True

    def start_background(self) -> None:
        self._bg = asyncio.create_task(self._startup(), name="j2c-startup")

    async def _startup(self) -> None:
        """Post-login work. Every step is isolated so one failure cannot skip the rest."""
        try:
            while not self.bot.is_ready():
                await asyncio.sleep(1)
        except asyncio.CancelledError:
            raise
        failed = False

        async def guarded(label, coro):
            nonlocal failed
            try:
                return await coro
            except asyncio.CancelledError:
                raise
            except Exception:
                log.exception("J2C startup step '%s' failed", label)
                config.say(f"{config.FAIL_MARKER} startup step '{label}' (traceback above)")
                failed = True

        from ..ui import icons
        from ..ui.panel import PanelView
        from .sync import maybe_sync

        async def icons_step():
            try:
                await icons.ensure(self.bot)      # non-fatal: unicode fallbacks are used
            except Exception:
                log.exception("icon setup failed; using unicode icons")

        async def views_step():
            await self.register_views()                             # persistent dispatch (stock + custom ids)
            PanelView(self, owner_id=1, banner=True)                # smoke-test the V2 layout API

        async def menu_step():
            if self.menu is not None:
                await self.menu.reconcile_all()

        async def sync_step():
            config.say(f"[J2C] {await maybe_sync(self.bot, self.repo)}")

        await icons_step()
        await guarded("persistent panel view", views_step())
        await guarded("reconcile", self.reconcile())
        await guarded("menu channels", menu_step())
        await guarded("command sync", sync_step())
        config.say("[J2C] startup complete" + (" (with errors)" if failed else ""))

    async def shutdown(self) -> None:
        for t in [self._bg, *self._delete_tasks.values(), *self._grace_tasks.values(), *self._refresh_tasks.values()]:
            if t and not t.done():
                t.cancel()

    async def register_views(self) -> None:
        """(Re)register persistent dispatch views.

        * one stock view with every built-in custom_id (keeps panels posted by v1.0 / older layouts working;
          the callbacks themselves refuse buttons an admin has since removed)
        * small views carrying the custom (info) buttons of every server that has any
        """
        from ..ui.panel import PanelView, custom_dispatch_views
        for v in self._panel_views:
            v.stop()
        self._panel_views = []
        stock = PanelView(self, menu=True)
        self.bot.add_view(stock)
        self._panel_views.append(stock)
        for v in custom_dispatch_views(self, await self.repo.list_custom_buttons()):
            self.bot.add_view(v)
            self._panel_views.append(v)

    async def reconcile(self) -> None:
        """Drop stale rows, delete empty leftovers, resume grace timers."""
        for hub in list(self.hubs.values()):
            if self.bot.get_channel(hub.channel_id) is None and self.bot.get_guild(hub.guild_id):
                log.warning("hub %s no longer exists - removing", hub.channel_id)
                await self.repo.remove_hub(hub.channel_id)
                self.hubs.pop(hub.channel_id, None)
        for rec in list(self.temp.values()):
            guild = self.bot.get_guild(rec.guild_id)
            if guild is None:
                continue
            ch = guild.get_channel(rec.channel_id)
            if ch is None:
                await self._forget(rec.channel_id)
            elif not humans(ch):
                await self.destroy(rec.channel_id, ch)
            elif guild.get_member(rec.owner_id) not in ch.members:
                self._schedule_grace(rec)

    # -------------------------------------------------------------- events
    async def on_voice_state(self, member: discord.Member, before: discord.VoiceState,
                             after: discord.VoiceState) -> None:
        if member.bot or not self.loaded:
            return
        b, a = before.channel, after.channel
        if (b and b.id) == (a and a.id):
            return
        if a is not None:
            try:
                await self._joined(member, a)
            except Exception:
                log.exception("J2C join handler failed")
        if b is not None:
            try:
                await self._left(member, b)
            except Exception:
                log.exception("J2C leave handler failed")

    async def _joined(self, member: discord.Member, channel) -> None:
        if channel.id in self.hubs:
            await self.create_for(member, channel, self.hubs[channel.id])
        elif channel.id in self.temp:
            self._cancel(self._delete_tasks, channel.id)
            rec = self.temp[channel.id]
            if member.id == rec.owner_id:
                self._cancel(self._grace_tasks, channel.id)
                if rec.owner_left_at:
                    rec.owner_left_at = None
                    await self.repo.update_channel(channel.id, owner_left_at=None)
        elif channel.id in self.waiting:
            await self._waiting_joined(member, self.waiting[channel.id])

    async def _left(self, member: discord.Member, channel) -> None:
        rec = self.temp.get(channel.id)
        if rec is None:
            return
        settings = await self.repo.get_guild(rec.guild_id)
        if not humans(channel):
            self._schedule_delete(channel.id, settings.delete_delay)
        elif member.id == rec.owner_id:
            rec.owner_left_at = int(time.time())
            await self.repo.update_channel(channel.id, owner_left_at=rec.owner_left_at)
            if settings.auto_transfer:
                self._schedule_grace(rec)

    async def on_channel_delete(self, channel) -> None:
        cid = channel.id
        if cid in self.hubs:
            await self.repo.remove_hub(cid)
            self.hubs.pop(cid, None)
        if cid in self.temp:
            await self._forget(cid)
        elif cid in self.waiting:
            main = self.waiting.pop(cid)
            rec = self.temp.get(main)
            if rec:
                rec.waiting_channel_id = None
                await self.repo.update_channel(main, waiting_channel_id=None)

    async def on_guild_remove(self, guild: discord.Guild) -> None:
        for rec in [r for r in self.temp.values() if r.guild_id == guild.id]:
            await self._forget(rec.channel_id)
        await self.repo.reset_guild(guild.id)
        for cid in [c for c, h in self.hubs.items() if h.guild_id == guild.id]:
            self.hubs.pop(cid, None)

    # ------------------------------------------------------------- creation
    async def create_for(self, member: discord.Member, hub_channel, hub: Hub) -> None:
        guild = member.guild
        settings = await self.repo.get_guild(guild.id)
        if not settings.enabled:
            return
        lock = self._user_locks.setdefault((guild.id, member.id), asyncio.Lock())
        async with lock:
            now = time.monotonic()
            if now - self._last_create.get(member.id, 0.0) < config.CREATE_COOLDOWN:
                await self._safe_disconnect(member, "J2C cooldown")
                return
            owned = [r for r in self.temp.values()
                     if r.guild_id == guild.id and r.owner_id == member.id and guild.get_channel(r.channel_id)]
            if len(owned) >= settings.max_per_user:
                try:
                    await member.move_to(guild.get_channel(owned[0].channel_id), reason="J2C: existing room")
                except discord.HTTPException:
                    pass
                return
            self._last_create[member.id] = now

            category = guild.get_channel(hub.category_id) if hub.category_id else None
            category = category or getattr(hub_channel, "category", None)
            profile = await self.repo.get_profile(guild.id, member.id)

            auto_named = not (profile and profile.name)
            if profile and profile.name:
                name = names.sanitize(profile.name, names.owner_room_name(config.DEFAULT_NAME_TEMPLATE, member))
            else:
                count = sum(1 for r in self.temp.values() if r.guild_id == guild.id) + 1
                name = names.owner_room_name(settings.name_template, member, count)

            overwrites = dict(category.overwrites) if category else {}
            everyone = overwrites.get(guild.default_role, discord.PermissionOverwrite())
            if profile and profile.locked:
                everyone.connect = False
            if profile and profile.hidden:
                everyone.view_channel = False
            if profile and profile.chat_locked:
                everyone.send_messages = False
            overwrites[guild.default_role] = everyone
            overwrites[member] = discord.PermissionOverwrite(**OWNER_PERMS)
            overwrites[guild.me] = discord.PermissionOverwrite(**BOT_PERMS)

            kwargs: dict = dict(name=name, overwrites=overwrites, reason=f"J2C room for {member}")
            if category:
                kwargs["category"] = category
            limit = profile.user_limit if profile and profile.user_limit is not None else settings.default_limit
            if limit:
                kwargs["user_limit"] = max(0, min(99, limit))
            bitrate = profile.bitrate if profile and profile.bitrate else settings.default_bitrate
            if bitrate:
                kwargs["bitrate"] = max(8000, min(guild.bitrate_limit, bitrate))
            if profile and profile.rtc_region:
                kwargs["rtc_region"] = profile.rtc_region

            channel = await guild.create_voice_channel(**kwargs)
            rec = await self.repo.add_channel(
                channel.id, guild.id, member.id,
                locked=bool(profile and profile.locked), hidden=bool(profile and profile.hidden),
                chat_locked=bool(profile and profile.chat_locked), auto_named=auto_named)
            self.temp[channel.id] = rec
            try:
                await member.move_to(channel, reason="J2C: join to create")
            except discord.HTTPException:
                await self.destroy(channel.id, channel)
                return
        await self.send_panel(channel, rec)

    @staticmethod
    async def _safe_disconnect(member: discord.Member, reason: str) -> None:
        try:
            await member.move_to(None, reason=reason)
        except discord.HTTPException:
            pass

    # ---------------------------------------------------------------- panel
    async def send_panel(self, channel: discord.VoiceChannel, rec: TempChannel) -> None:
        from ..ui.panel import PanelView, banner_file
        try:
            settings = await self.repo.get_guild(rec.guild_id)
            file = banner_file() if settings.banner else None
            buttons = await self.layout.visible(rec.guild_id)
            kwargs = dict(view=PanelView(self, owner_id=rec.owner_id, banner=file is not None, buttons=buttons),
                          allowed_mentions=discord.AllowedMentions.none())
            if file is not None:
                kwargs["file"] = file
            msg = await channel.send(**kwargs)
            rec.panel_message_id = msg.id
            await self.repo.update_channel(channel.id, panel_message_id=msg.id)
        except discord.HTTPException:
            log.exception("could not post J2C panel in %s", channel.id)

    async def refresh_panel(self, channel: discord.VoiceChannel, rec: TempChannel) -> None:
        from ..ui.panel import PanelView
        if not rec.panel_message_id:
            return
        try:
            settings = await self.repo.get_guild(rec.guild_id)
            buttons = await self.layout.visible(rec.guild_id)
            msg = channel.get_partial_message(rec.panel_message_id)
            await msg.edit(view=PanelView(self, owner_id=rec.owner_id, banner=settings.banner, buttons=buttons),
                           allowed_mentions=discord.AllowedMentions.none())
        except (discord.HTTPException, TypeError):
            pass

    def schedule_refresh(self, guild_id: int, delay: float = 2.0) -> None:
        """Debounced refresh_all_panels (an admin clicking through the editor triggers one refresh)."""
        old = self._refresh_tasks.pop(guild_id, None)
        if old and not old.done():
            old.cancel()

        async def _later() -> None:
            try:
                await asyncio.sleep(delay)
                await self.refresh_all_panels(guild_id)
            except asyncio.CancelledError:
                raise
            except Exception:
                log.exception("panel refresh failed for guild %s", guild_id)
            finally:
                if self._refresh_tasks.get(guild_id) is asyncio.current_task():
                    self._refresh_tasks.pop(guild_id, None)

        self._refresh_tasks[guild_id] = asyncio.create_task(_later())

    async def refresh_all_panels(self, guild_id: int) -> int:
        """Re-render every live room panel + the menu after an admin changed layout / theme."""
        n = 0
        for rec in [r for r in self.temp.values() if r.guild_id == guild_id]:
            ch = self.bot.get_channel(rec.channel_id)
            if ch is not None:
                await self.refresh_panel(ch, rec)
                n += 1
        if self.menu is not None:
            await self.menu.refresh(guild_id)
        await self.register_views()
        return n

    # -------------------------------------------------------------- deletion
    def _cancel(self, bucket: dict[int, asyncio.Task], key: int) -> None:
        t = bucket.pop(key, None)
        if t and not t.done() and t is not asyncio.current_task():
            t.cancel()

    def _schedule_delete(self, channel_id: int, delay: int) -> None:
        self._cancel(self._delete_tasks, channel_id)
        self._delete_tasks[channel_id] = asyncio.create_task(self._delete_later(channel_id, delay))

    async def _delete_later(self, channel_id: int, delay: int) -> None:
        try:
            await asyncio.sleep(max(0, delay))
            ch = self.bot.get_channel(channel_id)
            if ch is not None and humans(ch):
                return
            await self.destroy(channel_id, ch)
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("J2C delete failed for %s", channel_id)
        finally:
            if self._delete_tasks.get(channel_id) is asyncio.current_task():
                self._delete_tasks.pop(channel_id, None)

    async def destroy(self, channel_id: int, channel=None) -> None:
        rec = self.temp.get(channel_id)
        self._cancel(self._grace_tasks, channel_id)
        if rec and rec.waiting_channel_id:
            await self._delete_channel(self.bot.get_channel(rec.waiting_channel_id), "J2C waiting room cleanup")
        await self._delete_channel(channel or self.bot.get_channel(channel_id), "J2C: room empty")
        await self._forget(channel_id)

    @staticmethod
    async def _delete_channel(ch, reason: str) -> None:
        if ch is None:
            return
        try:
            await ch.delete(reason=reason)
        except (discord.NotFound, discord.Forbidden):
            pass
        except discord.HTTPException:
            log.exception("failed deleting channel %s", getattr(ch, "id", "?"))

    async def _forget(self, channel_id: int) -> None:
        rec = self.temp.pop(channel_id, None)
        if rec and rec.waiting_channel_id:
            self.waiting.pop(rec.waiting_channel_id, None)
        self._cancel(self._delete_tasks, channel_id)
        self._cancel(self._grace_tasks, channel_id)
        await self.repo.delete_channel(channel_id)

    # ------------------------------------------------------------- ownership
    def _schedule_grace(self, rec: TempChannel) -> None:
        self._cancel(self._grace_tasks, rec.channel_id)
        self._grace_tasks[rec.channel_id] = asyncio.create_task(self._grace(rec.channel_id))

    async def _grace(self, channel_id: int) -> None:
        try:
            await asyncio.sleep(config.OWNER_GRACE)
            rec, ch = self.temp.get(channel_id), self.bot.get_channel(channel_id)
            if rec is None or ch is None:
                return
            if any(m.id == rec.owner_id for m in ch.members):
                return
            members = humans(ch)
            if not members:
                return
            await self.set_owner(ch, rec, members[0], announce=True)
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("J2C auto-transfer failed")
        finally:
            if self._grace_tasks.get(channel_id) is asyncio.current_task():
                self._grace_tasks.pop(channel_id, None)

    async def set_owner(self, ch: discord.VoiceChannel, rec: TempChannel, new_owner: discord.Member,
                        *, announce: bool = False) -> None:
        old = rec.owner_id
        if old != new_owner.id:
            remaining = {t: ow for t, ow in ch.overwrites.items() if getattr(t, "id", None) != old}
            await ch.edit(overwrites=remaining, reason="J2C: owner changed")
        await ch.set_permissions(new_owner, overwrite=discord.PermissionOverwrite(**OWNER_PERMS),
                                 reason="J2C: new owner")
        rec.owner_id, rec.owner_left_at = new_owner.id, None
        await self.repo.update_channel(ch.id, owner_id=new_owner.id, owner_left_at=None)
        self._cancel(self._grace_tasks, ch.id)
        if old != new_owner.id:
            await self._rename_for_owner(ch, rec, new_owner)
        await self.refresh_panel(ch, rec)
        if announce:
            try:
                await ch.send(f"👑 {new_owner.mention} is now the owner of this channel.",
                              allowed_mentions=discord.AllowedMentions(users=[new_owner]))
            except discord.HTTPException:
                pass

    async def _rename_for_owner(self, ch, rec: TempChannel, owner: discord.Member) -> None:
        """Owner-based naming: if the room is still auto-named, follow the new owner."""
        if not rec.auto_named:
            return
        settings = await self.repo.get_guild(rec.guild_id)
        new_name = names.owner_room_name(settings.name_template, owner)
        if new_name == ch.name:
            return
        try:
            await asyncio.wait_for(ch.edit(name=new_name, reason="J2C: owner-based name"), timeout=10)
        except (asyncio.TimeoutError, discord.HTTPException):
            log.warning("could not rename %s for new owner (rate limit?) - keeping current name", ch.id)

    # -------------------------------------------------------- UI context
    async def context(self, interaction: discord.Interaction, action: str | None = None, *,
                      owner_only: bool = True):
        """Resolve (channel, record) for a panel interaction or raise J2CError.

        ``action`` (a built-in button key) is checked against the category permission rules.
        Without ``action`` the v1.0 rule applies (owner or Manage Server).
        """
        guild = interaction.guild
        if guild is None:
            raise J2CError("This only works inside a server.")
        ch = None
        in_room_chat = interaction.channel_id in self.temp
        if in_room_chat:
            ch = guild.get_channel(interaction.channel_id)
        else:
            vs = getattr(interaction.user, "voice", None)
            vc = vs.channel if vs else None
            if vc is not None and vc.id in self.temp:
                ch = vc
        if ch is None:
            raise J2CError("Join your J2C voice channel first (or use the panel inside it).")
        rec = self.temp[ch.id]
        user = interaction.user
        if action is None:
            if owner_only and rec.owner_id != user.id and not user.guild_permissions.manage_guild:
                raise J2CError(f"Only the channel owner (<@{rec.owner_id}>) can use this.")
            return ch, rec
        if not await self.layout.is_active(guild.id, action):
            raise J2CError("This button has been disabled by the server admins.")
        decision = await self.rules.check(user, rec, action)
        if not decision.allowed:
            from .layout import CATEGORY_OF
            from .rules import CATEGORIES
            title = CATEGORIES[CATEGORY_OF[action]][0]
            if action == "claim":
                raise J2CError("You're not allowed to claim rooms here.")
            raise J2CError(f"You don't have permission for **{title}** controls here. "
                           f"Only the channel owner (<@{rec.owner_id}>) or someone an admin allowed can use them.")
        actor = await self.rules.actor_for(user, rec)
        if not (actor.is_owner or actor.is_admin):
            vs = getattr(user, "voice", None)
            if vs is None or vs.channel is None or vs.channel.id != ch.id:
                raise J2CError("You need to be inside the voice channel to use its controls.")
        return ch, rec

    async def allowed(self, member: discord.Member, rec: TempChannel, action: str) -> bool:
        return (await self.rules.check(member, rec, action)).allowed

    # --------------------------------------------------------- operations
    @staticmethod
    async def _overwrite(ch, target, **perms) -> None:
        ow = ch.overwrites_for(target)
        for k, v in perms.items():
            setattr(ow, k, v)
        await ch.set_permissions(target, overwrite=None if ow.is_empty() else ow, reason="J2C")

    async def set_lock(self, ch, rec, locked: bool) -> None:
        await self._overwrite(ch, ch.guild.default_role, connect=False if locked else None)
        rec.locked = locked
        await self.repo.update_channel(ch.id, locked=locked)

    async def set_hidden(self, ch, rec, hidden: bool) -> None:
        await self._overwrite(ch, ch.guild.default_role, view_channel=False if hidden else None)
        rec.hidden = hidden
        await self.repo.update_channel(ch.id, hidden=hidden)

    async def set_chat_locked(self, ch, rec, locked: bool) -> None:
        await self._overwrite(ch, ch.guild.default_role, send_messages=False if locked else None)
        rec.chat_locked = locked
        await self.repo.update_channel(ch.id, chat_locked=locked)

    async def set_limit(self, ch, value: int) -> None:
        if not 0 <= value <= 99:
            raise J2CError("Limit must be between 0 (unlimited) and 99.")
        await ch.edit(user_limit=value, reason="J2C: limit")

    async def rename(self, ch, new_name: str) -> str:
        new_name = names.sanitize(new_name, "")
        if not new_name:
            raise J2CError("Please provide a valid name.")
        try:
            await asyncio.wait_for(ch.edit(name=new_name, reason="J2C: rename"), timeout=10)
        except asyncio.TimeoutError:
            raise J2CError("Discord is rate-limiting channel renames (2 per 10 minutes). Try again later.")
        rec = self.temp.get(ch.id)
        if rec is not None and rec.auto_named:        # a manual rename pins the name
            rec.auto_named = False
            await self.repo.update_channel(ch.id, auto_named=False)
        return new_name

    async def set_bitrate(self, ch, bitrate: int) -> None:
        bitrate = max(8000, min(ch.guild.bitrate_limit, bitrate))
        await ch.edit(bitrate=bitrate, reason="J2C: bitrate")

    async def set_region(self, ch, region: Optional[str]) -> None:
        await ch.edit(rtc_region=region, reason="J2C: region")

    async def permit(self, ch, rec, member: discord.Member) -> bool:
        """Toggle permit. Returns True if the user is now permitted."""
        if await self.repo.acl_get(ch.id, member.id) == "permit":
            await self._overwrite(ch, member, connect=None, view_channel=None)
            await self.repo.acl_remove(ch.id, member.id)
            return False
        await self._overwrite(ch, member, connect=True, view_channel=True)
        await self.repo.acl_set(ch.id, member.id, "permit")
        return True

    async def ban(self, ch, rec, member: discord.Member) -> bool:
        """Toggle ban. Returns True if the user is now banned."""
        if member.id == rec.owner_id:
            raise J2CError("You can't ban the channel owner.")
        if await self.repo.acl_get(ch.id, member.id) == "ban":
            await self._overwrite(ch, member, connect=None, view_channel=None)
            await self.repo.acl_remove(ch.id, member.id)
            return False
        await self._overwrite(ch, member, connect=False, view_channel=False)
        await self.repo.acl_set(ch.id, member.id, "ban")
        if member in ch.members:
            await self._safe_disconnect(member, "J2C: banned from room")
        return True

    async def invite(self, ch, rec, member: discord.Member, inviter: discord.Member) -> str:
        await self._overwrite(ch, member, connect=True, view_channel=True)
        await self.repo.acl_set(ch.id, member.id, "permit")
        invite = await ch.create_invite(max_age=3600, max_uses=1, unique=True, reason="J2C invite")
        sent = True
        try:
            await member.send(f"🎙️ **{inviter.display_name}** invited you to **{ch.name}** in "
                              f"**{ch.guild.name}**\n{invite.url}")
        except (discord.Forbidden, discord.HTTPException):
            sent = False
        return invite.url if not sent else ""

    async def claim(self, ch, rec, member: discord.Member) -> None:
        if member.voice is None or member.voice.channel is None or member.voice.channel.id != ch.id:
            raise J2CError("You must be in the voice channel to claim it.")
        if rec.owner_id == member.id:
            raise J2CError("You already own this channel.")
        if any(m.id == rec.owner_id for m in ch.members):
            raise J2CError("The owner is still in the channel.")
        await self.set_owner(ch, rec, member, announce=True)

    async def transfer(self, ch, rec, new_owner: discord.Member) -> None:
        if new_owner.bot:
            raise J2CError("You can't transfer a channel to a bot.")
        if new_owner.id == rec.owner_id:
            raise J2CError("That user already owns this channel.")
        if new_owner not in ch.members:
            raise J2CError("The new owner must be in the voice channel.")
        await self.set_owner(ch, rec, new_owner, announce=True)

    # ---- templates ------------------------------------------------------
    async def save_template(self, ch, rec, user_id: int) -> None:
        await self.repo.save_profile(
            ch.guild.id, user_id, name=ch.name, user_limit=ch.user_limit, bitrate=ch.bitrate,
            rtc_region=ch.rtc_region, locked=rec.locked, hidden=rec.hidden, chat_locked=rec.chat_locked)

    async def apply_template(self, ch, rec, profile: Profile) -> None:
        kwargs: dict = {}
        if profile.name:
            kwargs["name"] = names.sanitize(profile.name)
        if profile.user_limit is not None:
            kwargs["user_limit"] = profile.user_limit
        if profile.bitrate:
            kwargs["bitrate"] = max(8000, min(ch.guild.bitrate_limit, profile.bitrate))
        kwargs["rtc_region"] = profile.rtc_region
        try:
            await asyncio.wait_for(ch.edit(reason="J2C: apply template", **kwargs), timeout=10)
        except asyncio.TimeoutError:
            kwargs.pop("name", None)
            await ch.edit(reason="J2C: apply template", **kwargs)
        await self.set_lock(ch, rec, profile.locked)
        await self.set_hidden(ch, rec, profile.hidden)
        await self.set_chat_locked(ch, rec, profile.chat_locked)
        if profile.name and rec.auto_named:
            rec.auto_named = False
            await self.repo.update_channel(ch.id, auto_named=False)

    # ---- waiting room ---------------------------------------------------
    async def toggle_waiting(self, ch, rec) -> bool:
        """Returns True if the waiting room is now enabled."""
        if rec.waiting_channel_id:
            wid = rec.waiting_channel_id
            await self._delete_channel(self.bot.get_channel(wid), "J2C: waiting room disabled")
            self.waiting.pop(wid, None)
            rec.waiting_channel_id = None
            await self.repo.update_channel(ch.id, waiting_channel_id=None)
            return False
        everyone = discord.PermissionOverwrite(view_channel=True, connect=True, speak=False)
        wait = await ch.guild.create_voice_channel(
            name=names.sanitize(f"⏳ {ch.name}")[:100], category=ch.category,
            overwrites={ch.guild.default_role: everyone,
                        ch.guild.me: discord.PermissionOverwrite(**BOT_PERMS)},
            reason="J2C: waiting room")
        rec.waiting_channel_id = wait.id
        self.waiting[wait.id] = ch.id
        await self.repo.update_channel(ch.id, waiting_channel_id=wait.id)
        return True

    async def _waiting_joined(self, member: discord.Member, main_id: int) -> None:
        main = self.bot.get_channel(main_id)
        rec = self.temp.get(main_id)
        if main is None or rec is None:
            return
        if await self.repo.acl_get(main_id, member.id) == "permit":
            await member.move_to(main, reason="J2C: permitted")
            return
        if await self.repo.acl_get(main_id, member.id) == "ban":
            await self._safe_disconnect(member, "J2C: banned")
            return
        from ..ui.pickers import WaitingApprovalView
        wait_id = rec.waiting_channel_id or 0
        try:
            await main.send(
                f"⏳ {member.mention} is waiting to join. <@{rec.owner_id}>, approve or deny:",
                view=WaitingApprovalView(self, rec.owner_id, member.id, main_id, wait_id),
                allowed_mentions=discord.AllowedMentions(users=[member, discord.Object(rec.owner_id)]))
        except discord.HTTPException:
            log.exception("could not post waiting-room notice")
