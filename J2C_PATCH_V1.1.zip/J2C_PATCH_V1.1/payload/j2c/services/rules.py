"""Category-wise permission rules (Allow / Deny / Inherit) for panel actions.

Categories follow the panel sections: privacy, members, settings, room.
Principals (least -> most specific):
    tier 1  owner (VC owner) | admin | trusted (members holding a trusted role)
    tier 2  custom roles (any role, @everyone included)
    tier 3  individual member
Resolution for one (member, action):
    1. start from the baseline: owner and admins are allowed, everyone else denied
       (``claim`` is the exception: baseline-allowed for anyone, as in v1.0, still gated by its own checks)
    2. tier 1: any Deny wins, else any Allow wins, else unchanged (Inherit)
    3. tier 2: same
    4. tier 3: an explicit member rule is final
No row = Inherit. Deny always beats Allow inside a tier, and a more specific tier beats a broader one.
Admin tools (/j2c customize etc.) are NOT governed by these rules, so nobody can lock admins out.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .layout import CATEGORY_OF

CATEGORIES = {
    "privacy": ("🔒 Privacy", "Lock · Unlock · Hide · Unhide"),
    "members": ("👥 Members", "Limit · Invite · Ban · Permit"),
    "settings": ("⚙️ Settings", "Rename · Bitrate · Region · Template"),
    "room": ("👑 Room", "Chat · Waiting · Claim · Transfer"),
}
SUBJECT_TYPES = ("owner", "admin", "trusted", "role", "member")
SUBJECT_LABEL = {"owner": "VC owners", "admin": "Administrators", "trusted": "Trusted roles",
                 "role": "Custom role", "member": "Individual member"}
STATES = ("allow", "deny")


@dataclass(slots=True)
class Actor:
    user_id: int
    is_owner: bool = False
    is_admin: bool = False
    role_ids: frozenset[int] = field(default_factory=frozenset)
    trusted_role_ids: frozenset[int] = field(default_factory=frozenset)

    @property
    def is_trusted(self) -> bool:
        return bool(self.role_ids & self.trusted_role_ids)


@dataclass(slots=True)
class Decision:
    allowed: bool
    reason: str


def _tier(states: list[str | None], current: bool) -> bool:
    got = [s for s in states if s]
    if "deny" in got:
        return False
    if "allow" in got:
        return True
    return current


def decide(rules: dict[tuple[str, int], str], actor: Actor, action: str) -> Decision:
    """``rules`` = {(subject_type, subject_id): 'allow'|'deny'} for ONE category."""
    allowed = actor.is_owner or actor.is_admin or action == "claim"
    why = "baseline"
    t1: list[str | None] = []
    if actor.is_owner:
        t1.append(rules.get(("owner", 0)))
    if actor.is_admin:
        t1.append(rules.get(("admin", 0)))
    if actor.is_trusted:
        t1.append(rules.get(("trusted", 0)))
    new = _tier(t1, allowed)
    if any(t1):
        why = "owner/admin/trusted rule"
    allowed = new
    t2 = [rules.get(("role", rid)) for rid in actor.role_ids]
    new = _tier(t2, allowed)
    if any(t2):
        why = "role rule"
    allowed = new
    m = rules.get(("member", actor.user_id))
    if m:
        allowed, why = (m == "allow"), "member rule"
    return Decision(allowed, why)


class RuleService:
    """Per-guild cache around the rule table + trusted roles."""

    def __init__(self, repo):
        self.repo = repo
        self._rules: dict[int, dict[str, dict[tuple[str, int], str]]] = {}
        self._trusted: dict[int, frozenset[int]] = {}

    async def _load(self, guild_id: int) -> None:
        if guild_id in self._rules:
            return
        cats: dict[str, dict[tuple[str, int], str]] = {c: {} for c in CATEGORIES}
        for cat, stype, sid, state in await self.repo.list_rules(guild_id):
            cats.setdefault(cat, {})[(stype, sid)] = state
        self._rules[guild_id] = cats
        self._trusted[guild_id] = frozenset(await self.repo.list_trusted_roles(guild_id))

    def invalidate(self, guild_id: int) -> None:
        self._rules.pop(guild_id, None)
        self._trusted.pop(guild_id, None)

    async def rules(self, guild_id: int) -> dict[str, dict[tuple[str, int], str]]:
        await self._load(guild_id)
        return self._rules[guild_id]

    async def trusted_roles(self, guild_id: int) -> frozenset[int]:
        await self._load(guild_id)
        return self._trusted[guild_id]

    async def set_rule(self, guild_id: int, category: str, subject_type: str, subject_id: int,
                       state: str | None) -> None:
        if category not in CATEGORIES:
            raise ValueError("unknown category")
        if subject_type not in SUBJECT_TYPES:
            raise ValueError("unknown subject type")
        if state not in (None, *STATES):
            raise ValueError("state must be allow, deny or None (inherit)")
        if subject_type in ("owner", "admin", "trusted"):
            subject_id = 0
        await self.repo.set_rule(guild_id, category, subject_type, subject_id, state)
        self.invalidate(guild_id)

    async def set_trusted_roles(self, guild_id: int, role_ids: list[int]) -> None:
        await self.repo.set_trusted_roles(guild_id, role_ids)
        self.invalidate(guild_id)

    async def reset(self, guild_id: int) -> None:
        await self.repo.clear_rules(guild_id)
        self.invalidate(guild_id)

    async def actor_for(self, member, rec) -> Actor:
        perms = member.guild_permissions
        return Actor(
            user_id=member.id,
            is_owner=bool(rec is not None and rec.owner_id == member.id),
            is_admin=bool(perms.administrator or perms.manage_guild),
            role_ids=frozenset(r.id for r in member.roles),
            trusted_role_ids=await self.trusted_roles(member.guild.id),
        )

    async def check(self, member, rec, action: str) -> Decision:
        category = CATEGORY_OF.get(action)
        if category is None:
            return Decision(True, "ungated")
        rules = (await self.rules(member.guild.id)).get(category, {})
        return decide(rules, await self.actor_for(member, rec), action)

    async def matrix_lines(self, guild, limit_per_cat: int = 12) -> list[str]:
        """Human-readable summary of every explicit rule (everything else = Inherit)."""
        rules = await self.rules(guild.id)
        trusted = await self.trusted_roles(guild.id)
        icon = {"allow": "✅", "deny": "⛔"}
        out = []
        if trusted:
            out.append("**Trusted roles:** " + ", ".join(f"<@&{r}>" for r in sorted(trusted)))
        else:
            out.append("**Trusted roles:** none set")
        for cat, (title, _desc) in CATEGORIES.items():
            rows = []
            for (stype, sid), state in sorted(rules.get(cat, {}).items()):
                if stype == "role":
                    who = f"<@&{sid}>"
                elif stype == "member":
                    who = f"<@{sid}>"
                else:
                    who = SUBJECT_LABEL[stype]
                rows.append(f"{icon[state]} {who} — {state.title()}")
            body = "\n".join(rows[:limit_per_cat]) if rows else "all Inherit (owner + admins only)"
            if len(rows) > limit_per_cat:
                body += f"\n… +{len(rows) - limit_per_cat} more"
            out.append(f"**{title}**\n{body}")
        return out
