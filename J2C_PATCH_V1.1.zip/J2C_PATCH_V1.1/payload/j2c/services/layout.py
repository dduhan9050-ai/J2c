"""Panel layout engine: built-in buttons + admin overrides/custom buttons (per server).

The stock layout is defined here in code. The database only stores what an admin changed
(``j2c_buttons``), so servers that never customise anything keep the stock layout and
future default changes still reach them.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Optional

from ..db.models import ButtonRow
from ..db.repository import Repository

STYLES = ("secondary", "primary", "success")      # no "danger": the theme is charcoal, not red
DEFAULT_STYLE = "secondary"
MAX_LABEL = 20
MAX_SECTION = 30
MAX_INFO = 1500
MAX_COMPONENTS = 40          # Discord Components V2 limit per message
FIXED_COMPONENTS = 9         # container, header, banner(+item), 2 separators, footer, menu admin row+button
ROW_SIZE = 5
MAX_CUSTOM = 8

# key -> (label, section, category)   (order = stock order)
BUILTIN: list[tuple[str, str, str, str]] = [
    ("lock", "Lock", "🔒 Privacy", "privacy"), ("unlock", "Unlock", "🔒 Privacy", "privacy"),
    ("hide", "Hide", "🔒 Privacy", "privacy"), ("unhide", "Unhide", "🔒 Privacy", "privacy"),
    ("limit", "Limit", "👥 Members", "members"), ("invite", "Invite", "👥 Members", "members"),
    ("ban", "Ban", "👥 Members", "members"), ("permit", "Permit", "👥 Members", "members"),
    ("rename", "Rename", "⚙️ Settings", "settings"), ("bitrate", "Bitrate", "⚙️ Settings", "settings"),
    ("region", "Region", "⚙️ Settings", "settings"), ("template", "Template", "⚙️ Settings", "settings"),
    ("chat", "Chat", "👑 Room", "room"), ("waiting", "Waiting", "👑 Room", "room"),
    ("claim", "Claim", "👑 Room", "room"), ("transfer", "Transfer", "👑 Room", "room"),
]
BUILTIN_KEYS = [b[0] for b in BUILTIN]
BUILTIN_INFO = {k: (label, section, cat) for k, label, section, cat in BUILTIN}
CATEGORY_OF = {k: cat for k, _, _, cat in BUILTIN}


class LayoutError(Exception):
    """User-facing validation error."""


@dataclass(slots=True)
class Button:
    key: str
    kind: str                  # builtin | link | info
    label: str
    emoji: Optional[str]       # None = default icon, "" = no icon, else unicode/custom emoji string
    style: str
    section: str
    payload: Optional[str]
    position: int
    removed: bool

    @property
    def custom_id(self) -> str | None:
        if self.kind == "link":
            return None
        return f"j2c:{self.key}" if self.kind == "builtin" else f"j2c:x:{self.key[1:]}"


def _default(i: int, key: str) -> Button:
    label, section, _ = BUILTIN_INFO[key]
    return Button(key, "builtin", label, None, DEFAULT_STYLE, section, None, (i + 1) * 10, False)


def merge(rows: list[ButtonRow]) -> list[Button]:
    """Stock layout + overrides -> full ordered list (including removed ones)."""
    by_key = {r.button_key: r for r in rows}
    out: list[Button] = []
    for i, key in enumerate(BUILTIN_KEYS):
        b = _default(i, key)
        r = by_key.get(key)
        if r:
            b = replace(b, label=r.label or b.label,
                        emoji=r.emoji if r.emoji is not None else b.emoji,
                        style=r.style if r.style in STYLES else b.style,
                        section=r.section or b.section, position=r.position or b.position,
                        removed=bool(r.removed))
        out.append(b)
    for r in rows:
        if r.button_key in BUILTIN_INFO or r.kind == "builtin":
            continue
        out.append(Button(r.button_key, r.kind, r.label or "Button", r.emoji,
                          r.style if r.style in STYLES else DEFAULT_STYLE, r.section or "⭐ Custom",
                          r.payload, r.position, bool(r.removed)))
    out.sort(key=lambda b: (b.position, b.key))
    return out


def visible(buttons: list[Button]) -> list[Button]:
    return [b for b in buttons if not b.removed]


def groups(buttons: list[Button]) -> list[tuple[str, list[list[Button]]]]:
    """Consecutive buttons sharing a section -> (title, rows of <=5)."""
    out: list[tuple[str, list[Button]]] = []
    for b in visible(buttons):
        if out and out[-1][0] == b.section:
            out[-1][1].append(b)
        else:
            out.append((b.section, [b]))
    return [(t, [bs[i:i + ROW_SIZE] for i in range(0, len(bs), ROW_SIZE)]) for t, bs in out]


def component_count(buttons: list[Button]) -> int:
    total = FIXED_COMPONENTS
    for _title, rows in groups(buttons):
        total += 1 + len(rows) + sum(len(r) for r in rows)
    return total


def validate(buttons: list[Button]) -> None:
    vis = visible(buttons)
    if not vis:
        raise LayoutError("The panel needs at least one button.")
    if len(vis) > 25:
        raise LayoutError("A panel can have at most 25 buttons.")
    if component_count(buttons) > MAX_COMPONENTS:
        raise LayoutError("That layout is too large for one Discord message. Remove a button or merge sections "
                          "(each extra section costs space).")


def clean_label(v: str) -> str:
    v = " ".join((v or "").split())
    if not v:
        raise LayoutError("Label can't be empty.")
    return v[:MAX_LABEL]


def clean_section(v: str) -> str:
    v = " ".join((v or "").split())
    return (v or "⭐ Custom")[:MAX_SECTION]


def clean_style(v: str | None, default: str = DEFAULT_STYLE) -> str:
    v = (v or "").strip().lower()
    if not v:
        return default
    alias = {"grey": "secondary", "gray": "secondary", "charcoal": "secondary", "blue": "primary",
             "green": "success"}
    v = alias.get(v, v)
    if v not in STYLES:
        raise LayoutError("Style must be one of: " + ", ".join(STYLES) + " (red is not used in this theme).")
    return v


def clean_emoji(v: str | None) -> Optional[str]:
    """None = keep default, '' = explicitly no icon."""
    v = (v or "").strip()
    if not v:
        return None
    if v.lower() in ("none", "-", "off"):
        return ""
    import discord
    pe = discord.PartialEmoji.from_str(v)
    if pe.id is None and (v.isascii() or len(v) > 16):
        raise LayoutError("That doesn't look like an emoji. Use a unicode emoji, a custom emoji, or `none`.")
    return v


def clean_url(v: str) -> str:
    v = (v or "").strip()
    if not (v.startswith("https://") or v.startswith("http://")) or " " in v or len(v) > 500:
        raise LayoutError("Link buttons need a full URL starting with https://")
    return v


class LayoutService:
    def __init__(self, repo: Repository):
        self.repo = repo
        self._cache: dict[int, list[Button]] = {}

    async def get(self, guild_id: int) -> list[Button]:
        if guild_id not in self._cache:
            self._cache[guild_id] = merge(await self.repo.list_buttons(guild_id))
        # hand out COPIES: a rejected edit must never leave half-applied changes in the cache
        return [replace(b) for b in self._cache[guild_id]]

    async def visible(self, guild_id: int) -> list[Button]:
        return visible(await self.get(guild_id))

    def invalidate(self, guild_id: int) -> None:
        self._cache.pop(guild_id, None)

    async def find(self, guild_id: int, key: str) -> Button | None:
        return next((b for b in await self.get(guild_id) if b.key == key), None)

    async def is_active(self, guild_id: int, key: str) -> bool:
        b = await self.find(guild_id, key)
        return b is not None and not b.removed

    # -- persistence -----------------------------------------------------
    async def _save(self, guild_id: int, buttons: list[Button]) -> None:
        validate(buttons)
        rows = []
        for i, b in enumerate(sorted(buttons, key=lambda x: (x.position, x.key))):
            pos = (i + 1) * 10
            if b.kind == "builtin":
                d = _default(BUILTIN_KEYS.index(b.key), b.key)
                rows.append(ButtonRow(guild_id, b.key, "builtin",
                                      b.label if b.label != d.label else None,
                                      b.emoji, b.style if b.style != d.style else None,
                                      b.section if b.section != d.section else None, None, pos, b.removed))
            else:
                rows.append(ButtonRow(guild_id, b.key, b.kind, b.label, b.emoji, b.style, b.section,
                                      b.payload, pos, b.removed))
        await self.repo.save_buttons(guild_id, rows)
        self.invalidate(guild_id)

    # -- admin operations -------------------------------------------------
    async def edit(self, guild_id: int, key: str, *, label: str | None = None, emoji: str | None = None,
                   style: str | None = None, section: str | None = None, payload: str | None = None) -> Button:
        buttons = await self.get(guild_id)
        b = next((x for x in buttons if x.key == key), None)
        if b is None:
            raise LayoutError("That button no longer exists.")
        if label is not None and label.strip():
            b.label = clean_label(label)
        if emoji is not None:
            e = clean_emoji(emoji)
            if e is not None:
                b.emoji = e
        if style is not None and style.strip():
            b.style = clean_style(style, b.style)
        if section is not None and section.strip():
            b.section = clean_section(section)
        if payload is not None and payload.strip() and b.kind != "builtin":
            b.payload = clean_url(payload) if b.kind == "link" else payload.strip()[:MAX_INFO]
        await self._save(guild_id, buttons)
        return b

    async def add(self, guild_id: int, *, kind: str, label: str, emoji: str | None, section: str | None,
                  payload: str, style: str | None = None) -> Button:
        if kind not in ("link", "info"):
            raise LayoutError("Type must be `link` or `info`.")
        buttons = await self.get(guild_id)
        customs = [b for b in buttons if b.kind != "builtin" and not b.removed]
        if len(customs) >= MAX_CUSTOM:
            raise LayoutError(f"You can add at most {MAX_CUSTOM} custom buttons. Remove one first.")
        n = 1 + max([int(b.key[1:]) for b in buttons if b.kind != "builtin"] + [0])
        value = clean_url(payload) if kind == "link" else (payload or "").strip()[:MAX_INFO]
        if not value:
            raise LayoutError("Info buttons need some text to show.")
        e = clean_emoji(emoji)
        new = Button(f"c{n}", kind, clean_label(label), e, clean_style(style),
                     clean_section(section) if section and section.strip() else "⭐ Custom",
                     value, max([b.position for b in buttons] + [0]) + 10, False)
        buttons.append(new)
        await self._save(guild_id, buttons)
        return new

    async def remove(self, guild_id: int, key: str) -> None:
        buttons = await self.get(guild_id)
        b = next((x for x in buttons if x.key == key), None)
        if b is None or b.removed:
            raise LayoutError("That button is already removed.")
        b.removed = True
        await self._save(guild_id, buttons)

    async def restore(self, guild_id: int, key: str | None = None) -> int:
        """Restore one removed button (or all). Built-ins return with their stock look; returns count."""
        buttons = await self.get(guild_id)
        n = 0
        for b in buttons:
            if b.removed and (key is None or b.key == key):
                b.removed = False
                if b.kind == "builtin":
                    d = _default(BUILTIN_KEYS.index(b.key), b.key)
                    b.label, b.emoji, b.style, b.section = d.label, d.emoji, d.style, d.section
                n += 1
        if n:
            await self._save(guild_id, buttons)
        return n

    async def reset_all(self, guild_id: int) -> None:
        await self.repo.delete_buttons(guild_id)
        self.invalidate(guild_id)

    async def move(self, guild_id: int, key: str, delta: int) -> int:
        """Move a visible button up (-1) / down (+1) in the visible order. Returns new index."""
        buttons = await self.get(guild_id)
        vis = visible(buttons)
        idx = next((i for i, b in enumerate(vis) if b.key == key), None)
        if idx is None:
            raise LayoutError("That button isn't on the panel.")
        j = idx + delta
        if not 0 <= j < len(vis):
            raise LayoutError("It's already at the " + ("top." if delta < 0 else "bottom."))
        a, b = vis[idx], vis[j]
        a.position, b.position = b.position, a.position
        if a.position == b.position:            # defensive: never leave equal positions
            a.position += delta
        await self._save(guild_id, buttons)
        return j
