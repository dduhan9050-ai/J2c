"""Channel-name templating and sanitising."""
from __future__ import annotations

import re

_CONTROL = re.compile(r"[\x00-\x1f\x7f​-‏‪-‮⁠﻿]")
MAX_LEN = 100


def sanitize(name: str, fallback: str = "Room") -> str:
    name = _CONTROL.sub("", name or "")
    name = re.sub(r"\s+", " ", name).strip()
    return (name[:MAX_LEN].strip()) or fallback


def render(template: str, *, display_name: str, username: str, count: int = 1) -> str:
    out = (template or "")
    out = out.replace("{display_name}", display_name).replace("{username}", username)
    out = out.replace("{user}", display_name).replace("{count}", str(count))
    return sanitize(out, fallback=f"{username}Vc")


def owner_room_name(template: str, member, count: int = 1) -> str:
    """Owner-based VC name, e.g. template ``{username}Vc`` -> ``deathdevVc``."""
    return render(template, display_name=member.display_name, username=member.name, count=count)
