"""Dedicated, persistent J2C menu channel.

One read-only text channel per server holds a permanent control menu (same buttons as the room panels,
acting on the room the clicker is currently in). The channel + message ids live in ``j2c_menu``; on every
start the message is verified / re-posted / refreshed, and it is re-posted if somebody deletes it.
"""
from __future__ import annotations

import asyncio
import logging

import discord


log = logging.getLogger("j2c.menu")

MENU_CHANNEL_NAME = "🎛️・j2c-menu"


class MenuService:
    def __init__(self, service):
        self.s = service
        self.repo = service.repo
        self._locks: dict[int, asyncio.Lock] = {}
        self._removing: set[int] = set()

    def _lock(self, guild_id: int) -> asyncio.Lock:
        return self._locks.setdefault(guild_id, asyncio.Lock())

    # ------------------------------------------------------------ building
    async def _payload(self, guild_id: int) -> dict:
        from ..ui.panel import PanelView, banner_file
        settings = await self.repo.get_guild(guild_id)
        buttons = await self.s.layout.visible(guild_id)
        with_banner = bool(settings.banner)
        return dict(view=PanelView(self.s, banner=with_banner, buttons=buttons, menu=True),
                    allowed_mentions=discord.AllowedMentions.none()), (banner_file if with_banner else None)

    async def _post(self, channel: discord.TextChannel) -> discord.Message:
        kwargs, banner = await self._payload(channel.guild.id)
        file = banner() if banner else None
        if file is not None:
            kwargs["file"] = file
        msg = await channel.send(**kwargs)
        await self.repo.set_menu(channel.guild.id, channel.id, msg.id)
        return msg

    # --------------------------------------------------------------- setup
    async def setup(self, guild: discord.Guild, channel: discord.TextChannel | None = None,
                    category: discord.CategoryChannel | None = None) -> discord.TextChannel:
        async with self._lock(guild.id):
            existing = await self.repo.get_menu(guild.id)
            if channel is None and existing is not None:
                channel = guild.get_channel(existing.channel_id)
            if channel is None:
                if category is None:
                    hub = next((guild.get_channel(h.channel_id) for h in self.s.hubs.values()
                                if h.guild_id == guild.id), None)
                    category = getattr(hub, "category", None)
                overwrites = {
                    guild.default_role: discord.PermissionOverwrite(
                        view_channel=True, read_message_history=True, send_messages=False,
                        add_reactions=False, create_public_threads=False, create_private_threads=False),
                    guild.me: discord.PermissionOverwrite(
                        view_channel=True, send_messages=True, embed_links=True, attach_files=True,
                        read_message_history=True, manage_messages=True),
                }
                channel = await guild.create_text_channel(
                    MENU_CHANNEL_NAME, category=category, overwrites=overwrites,
                    topic="Join your J2C voice room, then use these buttons to control it.",
                    reason="J2C menu channel")
            if existing is not None and existing.channel_id != channel.id:
                await self._delete_message(guild, existing)
            await self._ensure_message(channel, existing if existing and existing.channel_id == channel.id else None)
            return channel

    async def _ensure_message(self, channel: discord.TextChannel, existing) -> discord.Message:
        if existing and existing.message_id:
            try:
                msg = await channel.fetch_message(existing.message_id)
                kwargs, _ = await self._payload(channel.guild.id)
                await msg.edit(**kwargs)
                return msg
            except discord.NotFound:
                pass
        return await self._post(channel)

    async def _delete_message(self, guild: discord.Guild, rec) -> None:
        ch = guild.get_channel(rec.channel_id)
        if ch is not None and rec.message_id:
            try:
                await ch.get_partial_message(rec.message_id).delete()
            except (discord.NotFound, discord.Forbidden, discord.HTTPException):
                pass

    async def remove(self, guild: discord.Guild, *, delete_channel: bool = False) -> bool:
        async with self._lock(guild.id):
            rec = await self.repo.get_menu(guild.id)
            if rec is None:
                return False
            self._removing.add(guild.id)
            try:
                await self._delete_message(guild, rec)
                await self.repo.clear_menu(guild.id)
                if delete_channel:
                    ch = guild.get_channel(rec.channel_id)
                    if ch is not None:
                        try:
                            await ch.delete(reason="J2C menu removed")
                        except discord.HTTPException:
                            pass
            finally:
                self._removing.discard(guild.id)
            return True

    # ------------------------------------------------------------- refresh
    async def refresh(self, guild_id: int) -> None:
        """Re-render the menu message (layout / theme change). Re-posts it if it vanished."""
        async with self._lock(guild_id):
            rec = await self.repo.get_menu(guild_id)
            guild = self.s.bot.get_guild(guild_id)
            if rec is None or guild is None:
                return
            channel = guild.get_channel(rec.channel_id)
            if channel is None:
                await self.repo.clear_menu(guild_id)
                return
            try:
                await self._ensure_message(channel, rec)
            except discord.HTTPException:
                log.exception("could not refresh menu in guild %s", guild_id)

    async def reconcile_all(self) -> None:
        for rec in await self.repo.list_menus():
            try:
                await self.refresh(rec.guild_id)
            except Exception:
                log.exception("menu reconcile failed for guild %s", rec.guild_id)

    # -------------------------------------------------------------- events
    async def on_message_deleted(self, guild_id: int | None, channel_id: int, message_id: int) -> None:
        if guild_id is None or guild_id in self._removing:
            return
        rec = await self.repo.get_menu(guild_id)
        if rec is None or rec.message_id != message_id:
            return
        async with self._lock(guild_id):
            guild = self.s.bot.get_guild(guild_id)
            ch = guild.get_channel(channel_id) if guild else None
            if ch is None:
                return
            try:
                await self._post(ch)
            except discord.HTTPException:
                log.exception("could not re-post menu message in guild %s", guild_id)

    async def on_channel_deleted(self, channel) -> None:
        rec = await self.repo.get_menu(channel.guild.id)
        if rec is not None and rec.channel_id == channel.id:
            await self.repo.clear_menu(channel.guild.id)
