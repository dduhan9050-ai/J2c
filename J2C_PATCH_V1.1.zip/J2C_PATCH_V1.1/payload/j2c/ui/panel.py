"""The J2C control panel (Components V2) and its button actions."""
from __future__ import annotations

import logging

import discord

from .. import __version__, config
from ..services.channels import J2CError
from ..services import layout
from . import icons
from .pickers import (BITRATES_KBPS, REGIONS, ChoiceView, TemplateView, TextModal, UserPickView)

log = logging.getLogger("j2c.panel")

STYLE_MAP = {"secondary": discord.ButtonStyle.secondary, "primary": discord.ButtonStyle.primary,
             "success": discord.ButtonStyle.success}
ADMIN_EDIT_ID = "j2c:admin:edit"


def banner_file() -> discord.File | None:
    try:
        if config.BANNER_FILE.exists():
            return discord.File(str(config.BANNER_FILE), filename=config.BANNER_NAME)
    except Exception:
        log.exception("banner unavailable")
    return None


def _emoji_for(b: layout.Button):
    if b.emoji is None:
        return icons.get(b.key) if b.kind == "builtin" else None
    if b.emoji == "":
        return None
    try:
        return discord.PartialEmoji.from_str(b.emoji)
    except Exception:
        return None


def _stock_buttons() -> list[layout.Button]:
    return layout.visible(layout.merge([]))


class PanelView(discord.ui.LayoutView):
    """The J2C control panel (Components V2), rendered from the server's layout.

    ``menu=True`` renders the persistent menu-channel flavour (no owner line + admin Customize button).
    """

    def __init__(self, service, *, owner_id: int | None = None, banner: bool = False,
                 buttons: list[layout.Button] | None = None, menu: bool = False):
        super().__init__(timeout=None)
        self.service = service
        self.actions = PanelActions(service)
        buttons = buttons if buttons is not None else _stock_buttons()
        header = "## 💀 J2C Menu" if menu else "## 💀 J2C Control Panel"
        if owner_id and not menu:
            header += f"\n👑 Owner: <@{owner_id}>"
        if menu:
            header += "\nJoin a J2C voice room, then use these buttons to control it."
        children: list = [discord.ui.TextDisplay(header)]
        if banner:
            try:
                children.append(discord.ui.MediaGallery(
                    discord.MediaGalleryItem(f"attachment://{config.BANNER_NAME}")))
            except Exception:
                log.exception("could not build banner gallery; continuing without it")
        children.append(discord.ui.Separator())
        for title, rows in layout.groups(buttons):
            children.append(discord.ui.TextDisplay(f"**{title}**"))
            for row in rows:
                children.append(discord.ui.ActionRow(*[self._button(b) for b in row]))
        children.append(discord.ui.Separator(visible=False))
        if menu:
            admin = discord.ui.Button(style=discord.ButtonStyle.secondary, label="Customize", emoji="⚙️",
                                      custom_id=ADMIN_EDIT_ID)
            admin.callback = self._admin_callback  # type: ignore[assignment]
            children.append(discord.ui.ActionRow(admin))
            foot = "Controls apply to the J2C room you're in. Admin-only: Customize."
        else:
            foot = "Only the owner (or anyone an admin allowed) can use these controls. Owner gone? Use **Claim**."
        children.append(discord.ui.TextDisplay(f"-# {config.BRAND} • J2C v{__version__} • {foot}"))
        self.add_item(discord.ui.Container(*children, accent_colour=discord.Colour(config.ACCENT)))

    def _button(self, b: layout.Button) -> discord.ui.Button:
        style = STYLE_MAP.get(b.style, discord.ButtonStyle.secondary)
        if b.kind == "link":
            return discord.ui.Button(style=discord.ButtonStyle.link, label=b.label, url=b.payload,
                                     emoji=_emoji_for(b))
        btn = discord.ui.Button(style=style, label=b.label, custom_id=b.custom_id, emoji=_emoji_for(b))
        key = b.key if b.kind == "builtin" else f"x:{b.key[1:]}"

        async def callback(interaction: discord.Interaction, _key: str = key) -> None:
            await self.actions.handle(_key, interaction)

        btn.callback = callback  # type: ignore[assignment]
        return btn

    async def _admin_callback(self, interaction: discord.Interaction) -> None:
        await self.actions.handle("admin_edit", interaction)


def custom_dispatch_views(service, rows) -> list[discord.ui.LayoutView]:
    """Persistent dispatch views for custom *info* buttons (link buttons need no dispatch)."""
    infos = [r for r in rows if r.kind == "info"]
    ids = sorted({int(r.button_key[1:]) for r in infos})
    views = []
    for i in range(0, len(ids), 20):
        view = discord.ui.LayoutView(timeout=None)
        actions = PanelActions(service)
        chunk = ids[i:i + 20]
        action_rows = []
        for j in range(0, len(chunk), 5):
            btns = []
            for n in chunk[j:j + 5]:
                btn = discord.ui.Button(style=discord.ButtonStyle.secondary, label=f"c{n}", custom_id=f"j2c:x:{n}")

                async def cb(interaction: discord.Interaction, _k: str = f"x:{n}") -> None:
                    await actions.handle(_k, interaction)

                btn.callback = cb  # type: ignore[assignment]
                btns.append(btn)
            action_rows.append(discord.ui.ActionRow(*btns))
        view.add_item(discord.ui.Container(*action_rows))
        views.append(view)
    return views


class PanelActions:
    def __init__(self, service):
        self.s = service

    async def handle(self, key: str, interaction: discord.Interaction) -> None:
        try:
            if key.startswith("x:"):
                await self.do_info(interaction, key[2:])
            else:
                await getattr(self, f"do_{key}")(interaction)
        except J2CError as exc:
            await self._say(interaction, f"⚠️ {exc}")
        except discord.Forbidden:
            await self._say(interaction, "⚠️ I'm missing permissions for that. Ask an admin to check my role.")
        except Exception:
            log.exception("J2C panel action %s failed", key)
            await self._say(interaction, "⚠️ Something went wrong. Please try again.")

    @staticmethod
    async def _say(interaction: discord.Interaction, text: str, **kw) -> None:
        if interaction.response.is_done():
            await interaction.followup.send(text, ephemeral=True, **kw)
        else:
            await interaction.response.send_message(text, ephemeral=True, **kw)

    # ---- privacy -------------------------------------------------------
    async def do_lock(self, i):
        ch, rec = await self.s.context(i, "lock")
        await i.response.defer(ephemeral=True)
        await self.s.set_lock(ch, rec, True)
        await self._say(i, "🔒 Channel locked. Only permitted users can join.")

    async def do_unlock(self, i):
        ch, rec = await self.s.context(i, "unlock")
        await i.response.defer(ephemeral=True)
        await self.s.set_lock(ch, rec, False)
        await self._say(i, "🔓 Channel unlocked.")

    async def do_hide(self, i):
        ch, rec = await self.s.context(i, "hide")
        await i.response.defer(ephemeral=True)
        await self.s.set_hidden(ch, rec, True)
        await self._say(i, "🙈 Channel hidden from everyone except permitted users and members inside.")

    async def do_unhide(self, i):
        ch, rec = await self.s.context(i, "unhide")
        await i.response.defer(ephemeral=True)
        await self.s.set_hidden(ch, rec, False)
        await self._say(i, "👁️ Channel is visible again.")

    # ---- members -------------------------------------------------------
    async def do_limit(self, i):
        ch, rec = await self.s.context(i, "limit")

        async def submit(inter, value: str):
            try:
                n = int(value.strip())
            except ValueError:
                return await self._say(inter, "⚠️ Enter a number from 0 to 99.")
            try:
                await inter.response.defer(ephemeral=True)
                await self.s.set_limit(ch, n)
                await self._say(inter, f"👥 Limit set to {n or 'unlimited'}.")
            except J2CError as exc:
                await self._say(inter, f"⚠️ {exc}")

        await i.response.send_modal(TextModal(submit, title="User limit", label="Limit (0 = unlimited, max 99)",
                                              placeholder="0-99", max_length=2, default=str(ch.user_limit)))

    async def do_invite(self, i):
        ch, rec = await self.s.context(i, "invite")

        async def picked(inter, members):
            await inter.response.defer(ephemeral=True)
            out = []
            for m in members:
                if m.bot:
                    continue
                link = await self.s.invite(ch, rec, m, inter.user)
                out.append(f"{m.mention} invited" + (f" (DMs closed — share: {link})" if link else " via DM"))
            await inter.edit_original_response(content="\n".join(out) or "No valid users selected.", view=None)

        await i.response.send_message("Pick users to invite:", ephemeral=True,
                                      view=UserPickView(picked, author_id=i.user.id, placeholder="Select users to invite"))

    async def do_ban(self, i):
        ch, rec = await self.s.context(i, "ban")

        async def picked(inter, members):
            await inter.response.defer(ephemeral=True)
            out = []
            for m in members:
                try:
                    banned = await self.s.ban(ch, rec, m)
                    out.append(f"{'✖️ banned' if banned else '♻️ unbanned'} {m.mention}")
                except J2CError as exc:
                    out.append(f"⚠️ {exc}")
            await inter.edit_original_response(content="\n".join(out), view=None)

        await i.response.send_message("Pick users to ban (pick a banned user again to unban):", ephemeral=True,
                                      view=UserPickView(picked, author_id=i.user.id, placeholder="Select users"))

    async def do_permit(self, i):
        ch, rec = await self.s.context(i, "permit")

        async def picked(inter, members):
            await inter.response.defer(ephemeral=True)
            out = []
            for m in members:
                if m.bot:
                    continue
                on = await self.s.permit(ch, rec, m)
                out.append(f"{'✅ permitted' if on else '♻️ removed permit for'} {m.mention}")
            await inter.edit_original_response(content="\n".join(out) or "No valid users selected.", view=None)

        await i.response.send_message("Pick users to permit (pick again to remove):", ephemeral=True,
                                      view=UserPickView(picked, author_id=i.user.id, placeholder="Select users"))

    # ---- settings ------------------------------------------------------
    async def do_rename(self, i):
        ch, rec = await self.s.context(i, "rename")

        async def submit(inter, value: str):
            try:
                await inter.response.defer(ephemeral=True)
                new = await self.s.rename(ch, value)
                await self._say(inter, f"✏️ Renamed to **{new}**.")
            except J2CError as exc:
                await self._say(inter, f"⚠️ {exc}")

        await i.response.send_modal(TextModal(submit, title="Rename channel", label="New name",
                                              placeholder="My room", max_length=100, default=ch.name[:100]))

    async def do_bitrate(self, i):
        ch, rec = await self.s.context(i, "bitrate")
        limit = ch.guild.bitrate_limit // 1000
        options = [discord.SelectOption(label=f"{k} kbps", value=str(k * 1000), default=ch.bitrate == k * 1000)
                   for k in BITRATES_KBPS if k <= limit]

        async def chosen(inter, value: str):
            await inter.response.defer(ephemeral=True)
            await self.s.set_bitrate(ch, int(value))
            await inter.edit_original_response(content=f"🎧 Bitrate set to {int(value) // 1000} kbps.", view=None)

        await i.response.send_message("Choose a bitrate:", ephemeral=True, view=ChoiceView(
            chosen, author_id=i.user.id, placeholder="Bitrate", options=options))

    async def do_region(self, i):
        ch, rec = await self.s.context(i, "region")
        options = [discord.SelectOption(label=label, value=value or "auto", default=(ch.rtc_region == value))
                   for label, value in REGIONS]

        async def chosen(inter, value: str):
            await inter.response.defer(ephemeral=True)
            await self.s.set_region(ch, None if value == "auto" else value)
            await inter.edit_original_response(content=f"🌐 Region set to **{value}**.", view=None)

        await i.response.send_message("Choose a voice region:", ephemeral=True, view=ChoiceView(
            chosen, author_id=i.user.id, placeholder="Region", options=options))

    async def do_template(self, i):
        ch, rec = await self.s.context(i, "template")
        await i.response.send_message(
            "📋 **Template** — save this room's name, limit, bitrate, region and privacy as your default. "
            "It's applied automatically next time you join the hub.",
            ephemeral=True, view=TemplateView(self.s, ch, rec, i.user.id))

    # ---- room ----------------------------------------------------------
    async def do_chat(self, i):
        ch, rec = await self.s.context(i, "chat")
        await i.response.defer(ephemeral=True)
        await self.s.set_chat_locked(ch, rec, not rec.chat_locked)
        await self._say(i, "💬 Text chat is now **locked** (owner only)." if rec.chat_locked
                        else "💬 Text chat is now **open**.")

    async def do_waiting(self, i):
        ch, rec = await self.s.context(i, "waiting")
        await i.response.defer(ephemeral=True)
        on = await self.s.toggle_waiting(ch, rec)
        await self._say(i, "⏳ Waiting room **enabled**. Pair it with Lock: people wait there and you approve them."
                        if on else "⏳ Waiting room **removed**.")

    async def do_claim(self, i):
        ch, rec = await self.s.context(i, "claim")
        await i.response.defer(ephemeral=True)
        await self.s.claim(ch, rec, i.user)
        await self._say(i, "👑 You are now the owner.")

    async def do_transfer(self, i):
        ch, rec = await self.s.context(i, "transfer")

        async def picked(inter, members):
            if not members:
                return await inter.response.edit_message(content="No valid user selected.", view=None)
            await inter.response.defer(ephemeral=True)
            try:
                await self.s.transfer(ch, rec, members[0])
                msg = f"👑 Ownership transferred to {members[0].mention}."
            except J2CError as exc:
                msg = f"⚠️ {exc}"
            await inter.edit_original_response(content=msg, view=None)

        await i.response.send_message("Pick the new owner (must be in the channel):", ephemeral=True,
                                      view=UserPickView(picked, author_id=i.user.id, placeholder="New owner",
                                                        max_values=1))

    # ---- custom (admin-added) buttons -------------------------------------
    async def do_info(self, i, n: str):
        if i.guild is None:
            raise J2CError("This only works inside a server.")
        b = await self.s.layout.find(i.guild.id, f"c{n}")
        if b is None or b.removed or b.kind != "info":
            raise J2CError("This button has been removed by the server admins.")
        await self._say(i, b.payload or "​")

    # ---- admin: open the Customize panel ----------------------------------
    async def do_admin_edit(self, i):
        perms = getattr(i.user, "guild_permissions", None)
        if i.guild is None or perms is None or not (perms.administrator or perms.manage_guild):
            raise J2CError("Only server admins (Manage Server) can customise the J2C menu.")
        from .admin import open_admin_panel
        await open_admin_panel(self.s, i)
