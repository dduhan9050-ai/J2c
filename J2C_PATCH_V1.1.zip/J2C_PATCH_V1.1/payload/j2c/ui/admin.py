"""Administrator Edit / Customize panel (ephemeral, Manage Server only).

Home -> Buttons (edit / add / remove / restore / reorder)
     -> Permissions (category-wise Allow / Deny / Inherit)
     -> Menu channel (create / refresh / remove the persistent menu)
     -> Naming (owner-based VC name template)
"""
from __future__ import annotations

import logging

import discord

from .. import config
from ..services import layout, names
from ..services.channels import J2CError
from ..services.layout import LayoutError
from ..services.rules import CATEGORIES, SUBJECT_LABEL, SUBJECT_TYPES

log = logging.getLogger("j2c.admin")


def is_admin(user) -> bool:
    perms = getattr(user, "guild_permissions", None)
    return bool(perms and (perms.administrator or perms.manage_guild))


async def open_admin_panel(service, interaction: discord.Interaction) -> None:
    if interaction.guild is None or not is_admin(interaction.user):
        raise J2CError("Only server admins (Manage Server) can customise the J2C menu.")
    view = HomeView(service, interaction.user.id, interaction.guild)
    if interaction.response.is_done():
        await interaction.followup.send(content=await view.render(), view=view, ephemeral=True)
    else:
        await interaction.response.send_message(content=await view.render(), view=view, ephemeral=True)


class AdminView(discord.ui.View):
    """Base: only the admin who opened it can use it; every click re-checks the permission."""

    def __init__(self, service, author_id: int, guild: discord.Guild, *, timeout: float = 600):
        super().__init__(timeout=timeout)
        self.service, self.author_id, self.guild = service, author_id, guild

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        ok = interaction.user.id == self.author_id and is_admin(interaction.user)
        if not ok:
            await interaction.response.send_message("This panel belongs to another admin.", ephemeral=True)
        return ok

    async def on_error(self, interaction: discord.Interaction, error: Exception, item) -> None:
        if isinstance(error, (LayoutError, J2CError)):
            msg = f"⚠️ {error}"
        else:
            log.exception("J2C admin panel error", exc_info=error)
            msg = "⚠️ Something went wrong. Please try again."
        if interaction.response.is_done():
            await interaction.followup.send(msg, ephemeral=True)
        else:
            await interaction.response.send_message(msg, ephemeral=True)

    async def render(self) -> str:  # pragma: no cover - overridden
        return ""

    async def show(self, interaction: discord.Interaction, view: "AdminView | None" = None,
                   note: str | None = None) -> None:
        v = view or self
        text = await v.render()
        if note:
            text = f"{note}\n\n{text}"
        text = text[:2000]
        if interaction.response.is_done():
            await interaction.edit_original_response(content=text, view=v)
        else:
            await interaction.response.edit_message(content=text, view=v)

    def changed(self) -> None:
        """Tell live panels (room panels + menu) to re-render soon."""
        self.service.schedule_refresh(self.guild.id)


# =============================================================== home
class HomeView(AdminView):
    async def render(self) -> str:
        s = await self.service.repo.get_guild(self.guild.id)
        menu = await self.service.repo.get_menu(self.guild.id)
        ch = self.guild.get_channel(menu.channel_id) if menu else None
        return (f"## 💀 J2C Customize\n"
                f"**Menu channel:** {ch.mention if ch else 'not set'}\n"
                f"**VC name template:** `{s.name_template}` → e.g. "
                f"`{names.render(s.name_template, display_name='Death', username='death')}`\n"
                "Pick what to edit:")

    @discord.ui.button(label="Buttons", emoji="🎛️", style=discord.ButtonStyle.secondary, row=0)
    async def buttons(self, i: discord.Interaction, _b) -> None:
        await self.show(i, ButtonsView(self.service, self.author_id, self.guild))

    @discord.ui.button(label="Permissions", emoji="🔐", style=discord.ButtonStyle.secondary, row=0)
    async def permissions(self, i: discord.Interaction, _b) -> None:
        await self.show(i, PermissionsView(self.service, self.author_id, self.guild))

    @discord.ui.button(label="Menu channel", emoji="📌", style=discord.ButtonStyle.secondary, row=0)
    async def menu(self, i: discord.Interaction, _b) -> None:
        await self.show(i, MenuView(self.service, self.author_id, self.guild))

    @discord.ui.button(label="Naming", emoji="🏷️", style=discord.ButtonStyle.secondary, row=1)
    async def naming(self, i: discord.Interaction, _b) -> None:
        s = await self.service.repo.get_guild(self.guild.id)
        await i.response.send_modal(NamingModal(self, s.name_template))

    @discord.ui.button(label="Refresh panels", emoji="🔄", style=discord.ButtonStyle.secondary, row=1)
    async def refresh(self, i: discord.Interaction, _b) -> None:
        await i.response.defer()
        n = await self.service.refresh_all_panels(self.guild.id)
        await i.followup.send(f"🔄 Refreshed {n} room panel(s) and the menu.", ephemeral=True)

    @discord.ui.button(label="Close", emoji="✖️", style=discord.ButtonStyle.secondary, row=1)
    async def close(self, i: discord.Interaction, _b) -> None:
        await i.response.edit_message(content="Closed.", view=None)
        self.stop()


class NamingModal(discord.ui.Modal):
    def __init__(self, home: HomeView, current: str):
        super().__init__(title="Owner-based VC naming", timeout=300)
        self.home = home
        self.field = discord.ui.TextInput(
            label="Template ({username} {display_name} {count})", default=current[:80], max_length=80,
            placeholder="{username}Vc")
        self.add_item(self.field)

    async def on_submit(self, i: discord.Interaction) -> None:
        value = str(self.field.value).strip()
        if not value or not names.render(value, display_name="Test", username="test"):
            return await i.response.send_message("⚠️ Template can't be empty.", ephemeral=True)
        await self.home.service.repo.update_guild(self.home.guild.id, name_template=value[:80])
        await self.home.show(i, note=f"✅ New rooms will be named from `{value[:80]}`.")


# ============================================================ buttons
def _icon(b: layout.Button) -> str:
    if b.emoji:
        return b.emoji
    from . import icons
    f = icons.FALLBACK.get(b.key) if b.kind == "builtin" else None
    return f or ("🔗" if b.kind == "link" else "💬" if b.kind == "info" else "▫️")


class ButtonsView(AdminView):
    def __init__(self, service, author_id, guild):
        super().__init__(service, author_id, guild)
        self.selected: str | None = None
        self.buttons: list[layout.Button] = []
        self._picker: discord.ui.Select | None = None

    async def load(self) -> None:
        self.buttons = await self.service.layout.get(self.guild.id)
        vis = layout.visible(self.buttons)
        if self.selected not in {b.key for b in vis}:
            self.selected = vis[0].key if vis else None
        self._rebuild_select(vis)

    def _rebuild_select(self, vis: list[layout.Button]) -> None:
        if self._picker is not None:
            self.remove_item(self._picker)
            self._picker = None
        options = [discord.SelectOption(label=f"{n}. {b.label}"[:100], value=b.key,
                                        description=f"{b.section} • {b.kind}"[:100],
                                        default=(b.key == self.selected))
                   for n, b in enumerate(vis[:25], 1)]
        if not options:
            return
        sel = discord.ui.Select(placeholder="Pick a button to edit / move / remove", options=options, row=0)
        sel.callback = self._picked  # type: ignore[assignment]
        self._picker = sel
        self.add_item(sel)

    async def render(self) -> str:
        await self.load()
        vis = layout.visible(self.buttons)
        removed = [b for b in self.buttons if b.removed]
        lines = [f"## 🎛️ Panel buttons  ({len(vis)}/25 • space {layout.component_count(self.buttons)}/"
                 f"{layout.MAX_COMPONENTS})"]
        for n, b in enumerate(vis, 1):
            mark = "▶ " if b.key == self.selected else ""
            tag = "" if b.kind == "builtin" else f" `{b.kind}`"
            lines.append(f"{mark}{n}. {_icon(b)} **{b.label}** — {b.section}{tag}")
        if removed:
            lines.append("\n**Removed:** " + ", ".join(b.label for b in removed))
        return "\n".join(lines)[:1990]

    async def _picked(self, i: discord.Interaction) -> None:
        self.selected = i.data["values"][0]
        await self.show(i)

    def _need(self) -> str:
        if not self.selected:
            raise LayoutError("Pick a button first.")
        return self.selected

    @discord.ui.button(label="Edit", emoji="✏️", style=discord.ButtonStyle.secondary, row=1)
    async def edit(self, i: discord.Interaction, _b) -> None:
        key = self._need()
        b = await self.service.layout.find(self.guild.id, key)
        if b is None:
            raise LayoutError("That button no longer exists.")
        await i.response.send_modal(EditModal(self, b))

    @discord.ui.button(label="Up", emoji="⬆️", style=discord.ButtonStyle.secondary, row=1)
    async def up(self, i: discord.Interaction, _b) -> None:
        await self.service.layout.move(self.guild.id, self._need(), -1)
        self.changed()
        await self.show(i)

    @discord.ui.button(label="Down", emoji="⬇️", style=discord.ButtonStyle.secondary, row=1)
    async def down(self, i: discord.Interaction, _b) -> None:
        await self.service.layout.move(self.guild.id, self._need(), +1)
        self.changed()
        await self.show(i)

    @discord.ui.button(label="Remove", emoji="🗑️", style=discord.ButtonStyle.secondary, row=1)
    async def remove(self, i: discord.Interaction, _b) -> None:
        key = self._need()
        await self.service.layout.remove(self.guild.id, key)
        self.changed()
        await self.show(i, note="🗑️ Removed (you can restore it).")

    @discord.ui.button(label="Add", emoji="➕", style=discord.ButtonStyle.secondary, row=2)
    async def add(self, i: discord.Interaction, _b) -> None:
        await i.response.send_modal(AddModal(self))

    @discord.ui.button(label="Restore", emoji="♻️", style=discord.ButtonStyle.secondary, row=2)
    async def restore(self, i: discord.Interaction, _b) -> None:
        removed = [b for b in await self.service.layout.get(self.guild.id) if b.removed]
        if not removed:
            raise LayoutError("Nothing to restore — no buttons are removed.")
        await self.show(i, RestoreView(self.service, self.author_id, self.guild, self, removed))

    @discord.ui.button(label="Reset layout", emoji="🔄", style=discord.ButtonStyle.secondary, row=2)
    async def reset(self, i: discord.Interaction, _b) -> None:
        await self.show(i, ConfirmView(self.service, self.author_id, self.guild, self,
                                       "Reset the whole panel to the stock layout? Custom buttons will be deleted.",
                                       self._do_reset))

    async def _do_reset(self, i: discord.Interaction) -> str:
        await self.service.layout.reset_all(self.guild.id)
        self.changed()
        return "🔄 Layout reset to stock."

    @discord.ui.button(label="Back", emoji="◀️", style=discord.ButtonStyle.secondary, row=2)
    async def back(self, i: discord.Interaction, _b) -> None:
        await self.show(i, HomeView(self.service, self.author_id, self.guild))


class EditModal(discord.ui.Modal):
    def __init__(self, parent: ButtonsView, b: layout.Button):
        super().__init__(title=f"Edit: {b.label}"[:45], timeout=300)
        self.parent, self.key, self.kind = parent, b.key, b.kind
        self.label = discord.ui.TextInput(label="Label", default=b.label, max_length=layout.MAX_LABEL)
        self.emoji = discord.ui.TextInput(label="Emoji (blank = keep, 'none' = no icon)", required=False,
                                          default=b.emoji or None, max_length=64)
        self.section = discord.ui.TextInput(label="Section heading (same text = same group)", default=b.section,
                                            max_length=layout.MAX_SECTION)
        self.style = discord.ui.TextInput(label="Style: secondary / primary / success", default=b.style,
                                          max_length=10)
        for f in (self.label, self.emoji, self.section, self.style):
            self.add_item(f)
        self.payload = None
        if b.kind != "builtin":
            self.payload = discord.ui.TextInput(
                label="URL" if b.kind == "link" else "Text shown when clicked", default=b.payload,
                style=discord.TextStyle.short if b.kind == "link" else discord.TextStyle.paragraph,
                max_length=500 if b.kind == "link" else layout.MAX_INFO)
            # Discord allows 5 inputs per modal: drop the style field for custom buttons to make room
            self.remove_item(self.style)
            self.add_item(self.payload)

    async def on_submit(self, i: discord.Interaction) -> None:
        try:
            await self.parent.service.layout.edit(
                self.parent.guild.id, self.key, label=str(self.label.value), emoji=str(self.emoji.value or ""),
                section=str(self.section.value),
                style=str(self.style.value) if self.kind == "builtin" else None,
                payload=str(self.payload.value) if self.payload is not None else None)
        except LayoutError as exc:
            return await i.response.send_message(f"⚠️ {exc}", ephemeral=True)
        self.parent.changed()
        await self.parent.show(i, note="✏️ Saved.")


class AddModal(discord.ui.Modal, title="Add a button"):
    def __init__(self, parent: ButtonsView):
        super().__init__(timeout=300)
        self.parent = parent
        self.kind = discord.ui.TextInput(label="Type: link or info", default="info", max_length=4)
        self.label = discord.ui.TextInput(label="Label", max_length=layout.MAX_LABEL)
        self.emoji = discord.ui.TextInput(label="Emoji (optional)", required=False, max_length=64)
        self.section = discord.ui.TextInput(label="Section heading", default="⭐ Custom", required=False,
                                            max_length=layout.MAX_SECTION)
        self.content = discord.ui.TextInput(label="URL (link) or text to show (info)",
                                            style=discord.TextStyle.paragraph, max_length=layout.MAX_INFO)
        for f in (self.kind, self.label, self.emoji, self.section, self.content):
            self.add_item(f)

    async def on_submit(self, i: discord.Interaction) -> None:
        try:
            b = await self.parent.service.layout.add(
                self.parent.guild.id, kind=str(self.kind.value).strip().lower(), label=str(self.label.value),
                emoji=str(self.emoji.value or ""), section=str(self.section.value or ""),
                payload=str(self.content.value))
        except LayoutError as exc:
            return await i.response.send_message(f"⚠️ {exc}", ephemeral=True)
        self.parent.selected = b.key
        self.parent.changed()
        await self.parent.show(i, note=f"➕ Added **{b.label}**.")


class RestoreView(AdminView):
    def __init__(self, service, author_id, guild, parent: ButtonsView, removed: list[layout.Button]):
        super().__init__(service, author_id, guild)
        self.parent, self.removed = parent, removed
        opts = [discord.SelectOption(label=b.label[:100], value=b.key, description=b.section[:100])
                for b in removed[:25]]
        sel = discord.ui.Select(placeholder="Restore which button?", options=opts, row=0)
        sel.callback = self._chosen  # type: ignore[assignment]
        self.add_item(sel)

    async def render(self) -> str:
        return "## ♻️ Restore buttons\nRestored built-in buttons return with their stock look."

    async def _chosen(self, i: discord.Interaction) -> None:
        await self.service.layout.restore(self.guild.id, i.data["values"][0])
        self.changed()
        await self.show(i, ButtonsView(self.service, self.author_id, self.guild), note="♻️ Restored.")

    @discord.ui.button(label="Restore all", emoji="♻️", style=discord.ButtonStyle.secondary, row=1)
    async def all(self, i: discord.Interaction, _b) -> None:
        n = await self.service.layout.restore(self.guild.id)
        self.changed()
        await self.show(i, ButtonsView(self.service, self.author_id, self.guild), note=f"♻️ Restored {n} button(s).")

    @discord.ui.button(label="Back", emoji="◀️", style=discord.ButtonStyle.secondary, row=1)
    async def back(self, i: discord.Interaction, _b) -> None:
        await self.show(i, ButtonsView(self.service, self.author_id, self.guild))


class ConfirmView(AdminView):
    def __init__(self, service, author_id, guild, back: AdminView, question: str, action):
        super().__init__(service, author_id, guild, timeout=120)
        self.back_view, self.question, self.action = back, question, action

    async def render(self) -> str:
        return f"## ❓ Are you sure?\n{self.question}"

    @discord.ui.button(label="Yes", emoji="✅", style=discord.ButtonStyle.secondary)
    async def yes(self, i: discord.Interaction, _b) -> None:
        note = await self.action(i)
        if isinstance(self.back_view, ButtonsView):
            self.back_view.selected = None
        await self.show(i, self.back_view, note=note)

    @discord.ui.button(label="Cancel", emoji="✖️", style=discord.ButtonStyle.secondary)
    async def no(self, i: discord.Interaction, _b) -> None:
        await self.show(i, self.back_view, note="Cancelled.")


# ========================================================= permissions
STATE_ICON = {"allow": "✅ Allow", "deny": "✖️ Deny", None: "↩️ Inherit"}


class PermissionsView(AdminView):
    def __init__(self, service, author_id, guild):
        super().__init__(service, author_id, guild)
        self.category = "privacy"
        self.stype = "owner"
        self.target: int | None = None
        self._build()

    def _build(self) -> None:
        self.clear_items()
        cat = discord.ui.Select(placeholder="Category", row=0, options=[
            discord.SelectOption(label=t[0], value=k, description=t[1],
                                 default=(k == self.category)) for k, t in CATEGORIES.items()])
        cat.callback = self._cat  # type: ignore[assignment]
        self.add_item(cat)
        typ = discord.ui.Select(placeholder="Who", row=1, options=[
            discord.SelectOption(label=SUBJECT_LABEL[t], value=t, default=(t == self.stype))
            for t in SUBJECT_TYPES])
        typ.callback = self._type  # type: ignore[assignment]
        self.add_item(typ)
        if self.stype == "role":
            sel = discord.ui.RoleSelect(placeholder="Pick the role", row=2, min_values=1, max_values=1)
            sel.callback = self._role  # type: ignore[assignment]
            self.add_item(sel)
        elif self.stype == "member":
            sel = discord.ui.UserSelect(placeholder="Pick the member", row=2, min_values=1, max_values=1)
            sel.callback = self._member  # type: ignore[assignment]
            self.add_item(sel)
        elif self.stype == "trusted":
            sel = discord.ui.RoleSelect(placeholder="Set which roles count as trusted", row=2,
                                        min_values=0, max_values=10)
            sel.callback = self._trusted  # type: ignore[assignment]
            self.add_item(sel)
        for label, emoji, state in (("Allow", "✅", "allow"), ("Deny", "✖️", "deny"), ("Inherit", "↩️", None)):
            b = discord.ui.Button(label=label, emoji=emoji, style=discord.ButtonStyle.secondary, row=3)
            b.callback = self._setter(state)  # type: ignore[assignment]
            self.add_item(b)
        for label, emoji, cb in (("Matrix", "📋", self._matrix), ("Reset all", "🔄", self._reset),
                                 ("Back", "◀️", self._back)):
            b = discord.ui.Button(label=label, emoji=emoji, style=discord.ButtonStyle.secondary, row=4)
            b.callback = cb  # type: ignore[assignment]
            self.add_item(b)

    async def render(self) -> str:
        rules = (await self.service.rules.rules(self.guild.id)).get(self.category, {})
        sid = 0 if self.stype in ("owner", "admin", "trusted") else (self.target or -1)
        state = rules.get((self.stype, sid))
        who = SUBJECT_LABEL[self.stype]
        if self.stype == "role" and self.target:
            who = f"role <@&{self.target}>"
        elif self.stype == "member" and self.target:
            who = f"member <@{self.target}>"
        elif self.stype in ("role", "member"):
            who += " (not picked yet)"
        extra = ""
        if self.stype == "trusted":
            tr = await self.service.rules.trusted_roles(self.guild.id)
            extra = "\n**Trusted roles:** " + (", ".join(f"<@&{r}>" for r in sorted(tr)) or "none yet")
        return (f"## 🔐 Permissions\n**Category:** {CATEGORIES[self.category][0]} "
                f"({CATEGORIES[self.category][1]})\n**Who:** {who}\n"
                f"**Current:** {STATE_ICON[state]}{extra}\n"
                "-# Inherit = no rule. Order: baseline (owner + admins) → owner/admin/trusted → custom roles → "
                "member. Deny beats Allow within a level.")

    async def _cat(self, i):
        self.category = i.data["values"][0]
        self._build()
        await self.show(i)

    async def _type(self, i):
        self.stype = i.data["values"][0]
        self.target = None
        self._build()
        await self.show(i)

    async def _role(self, i):
        self.target = int(i.data["values"][0])
        await self.show(i)

    async def _member(self, i):
        self.target = int(i.data["values"][0])
        await self.show(i)

    async def _trusted(self, i):
        ids = [int(v) for v in i.data.get("values", [])]
        await self.service.rules.set_trusted_roles(self.guild.id, ids)
        await self.show(i, note="✅ Trusted roles updated.")

    def _setter(self, state):
        async def cb(i: discord.Interaction) -> None:
            if self.stype in ("role", "member") and not self.target:
                raise LayoutError(f"Pick a {'role' if self.stype == 'role' else 'member'} first.")
            sid = 0 if self.stype in ("owner", "admin", "trusted") else int(self.target)
            await self.service.rules.set_rule(self.guild.id, self.category, self.stype, sid, state)
            await self.show(i, note=f"Saved: {STATE_ICON[state]}")
        return cb

    async def _matrix(self, i):
        lines = await self.service.rules.matrix_lines(self.guild)
        await i.response.send_message("## 📋 Permission matrix\n" + "\n".join(lines)[:1900], ephemeral=True,
                                      allowed_mentions=discord.AllowedMentions.none())

    async def _reset(self, i):
        await self.show(i, ConfirmView(self.service, self.author_id, self.guild, self,
                                       "Clear ALL permission rules (trusted roles are kept)?", self._do_reset))

    async def _do_reset(self, i):
        await self.service.rules.reset(self.guild.id)
        return "🔄 All rules cleared (everything Inherits)."

    async def _back(self, i):
        await self.show(i, HomeView(self.service, self.author_id, self.guild))


# ============================================================== menu
class MenuView(AdminView):
    def __init__(self, service, author_id, guild):
        super().__init__(service, author_id, guild)
        sel = discord.ui.ChannelSelect(placeholder="Use an existing text channel for the menu", row=0,
                                       channel_types=[discord.ChannelType.text], min_values=1, max_values=1)
        sel.callback = self._chosen  # type: ignore[assignment]
        self.add_item(sel)

    async def render(self) -> str:
        rec = await self.service.repo.get_menu(self.guild.id)
        ch = self.guild.get_channel(rec.channel_id) if rec else None
        return ("## 📌 Menu channel\nA permanent, read-only channel with the J2C buttons. It survives restarts and "
                "is re-posted if the message is deleted.\n"
                f"**Current:** {ch.mention if ch else 'not set'}")

    async def _chosen(self, i: discord.Interaction) -> None:
        channel = self.guild.get_channel(int(i.data["values"][0]))
        if not isinstance(channel, discord.TextChannel):
            raise LayoutError("Pick a normal text channel.")
        await i.response.defer()
        await self.service.menu.setup(self.guild, channel)
        await self.show(i, note=f"✅ Menu posted in {channel.mention}.")

    @discord.ui.button(label="Create / refresh", emoji="📌", style=discord.ButtonStyle.secondary, row=1)
    async def create(self, i: discord.Interaction, _b) -> None:
        await i.response.defer()
        ch = await self.service.menu.setup(self.guild)
        await self.show(i, note=f"✅ Menu ready in {ch.mention}.")

    @discord.ui.button(label="Remove menu", emoji="🗑️", style=discord.ButtonStyle.secondary, row=1)
    async def remove(self, i: discord.Interaction, _b) -> None:
        await i.response.defer()
        done = await self.service.menu.remove(self.guild)
        await self.show(i, note="🗑️ Menu message removed (the channel is kept)." if done else "No menu is set.")

    @discord.ui.button(label="Back", emoji="◀️", style=discord.ButtonStyle.secondary, row=1)
    async def back(self, i: discord.Interaction, _b) -> None:
        await self.show(i, HomeView(self.service, self.author_id, self.guild))
