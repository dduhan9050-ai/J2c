"""Components V2 info / status panels."""
from __future__ import annotations

import discord

from .. import __version__, config
from ..services import names


def _footer() -> str:
    return f"-# {config.BRAND} • J2C v{__version__}"


def info_view(title: str, lines: list[str] | str, *, colour: int | None = None) -> discord.ui.LayoutView:
    body = lines if isinstance(lines, str) else "\n".join(lines)
    view = discord.ui.LayoutView(timeout=300)
    view.add_item(discord.ui.Container(
        discord.ui.TextDisplay(f"## {title}"),
        discord.ui.Separator(),
        discord.ui.TextDisplay(body or "​"),
        discord.ui.TextDisplay(_footer()),
        accent_colour=discord.Colour(colour if colour is not None else config.ACCENT),
    ))
    return view


def error_view(text: str) -> discord.ui.LayoutView:
    return info_view("⚠️ J2C", text, colour=config.ERROR_ACCENT)


async def status_view(service, guild: discord.Guild) -> discord.ui.LayoutView:
    from ..services.perms import missing_bot_perms
    s = await service.repo.get_guild(guild.id)
    hubs = [h for h in service.hubs.values() if h.guild_id == guild.id]
    active = [r for r in service.temp.values() if r.guild_id == guild.id]
    lines = []
    if hubs:
        for h in hubs:
            ch = guild.get_channel(h.channel_id)
            cat = guild.get_channel(h.category_id) if h.category_id else None
            lines.append(f"**Hub:** {ch.mention if ch else h.channel_id}"
                         f"{f' → `{cat.name}`' if cat else ''}")
    else:
        lines.append("**Hub:** not configured — run `/%s setup`" % config.COMMAND_NAME)
    menu = await service.repo.get_menu(guild.id)
    menu_ch = guild.get_channel(menu.channel_id) if menu else None
    lines += [
        f"**Menu channel:** {menu_ch.mention if menu_ch else 'not set — run `/%s menu`' % config.COMMAND_NAME}",
        f"**Active rooms:** {len(active)}",
        f"**Name template:** `{s.name_template}` → "
        f"`{names.render(s.name_template, display_name='Death', username='death')}`",
        f"**Default limit:** {s.default_limit or 'unlimited'} • **Bitrate:** "
        f"{(str(s.default_bitrate // 1000) + ' kbps') if s.default_bitrate else 'server default'}",
        f"**Banner:** {'on' if s.banner else 'off'} • **Auto-transfer:** {'on' if s.auto_transfer else 'off'} "
        f"• **Delete delay:** {s.delete_delay}s • **Rooms/user:** {s.max_per_user}",
    ]
    missing = missing_bot_perms(guild)
    if missing:
        lines.append("⚠️ **Bot is missing:** " + ", ".join(missing))
    return info_view("💀 J2C Status", lines)
