"""Button icons: application emojis cut from the supplied J2C button sheet.

On first start the 16 icons in assets/icons are uploaded as *application
emojis* (j2c_<name>). If that is unavailable (old discord.py, missing perms,
limits) unicode fallbacks are used, so the panel always works.
"""
from __future__ import annotations

import logging

import discord

from .. import config

log = logging.getLogger("j2c.icons")

NAMES = ["lock", "unlock", "hide", "unhide", "limit", "invite", "ban", "permit",
         "rename", "bitrate", "region", "template", "chat", "waiting", "claim", "transfer"]

FALLBACK = {
    "lock": "🔒", "unlock": "🔓", "hide": "🙈", "unhide": "👁️", "limit": "👥", "invite": "➕",
    "ban": "✖️", "permit": "✅", "rename": "✏️", "bitrate": "🎧", "region": "🌐", "template": "📋",
    "chat": "💬", "waiting": "⏳", "claim": "👑", "transfer": "🔁",
}

_ICONS: dict[str, discord.PartialEmoji] = {}


def get(name: str):
    return _ICONS.get(name) or FALLBACK.get(name)


async def ensure(bot) -> None:
    fetch = getattr(bot, "fetch_application_emojis", None)
    create = getattr(bot, "create_application_emoji", None)
    if fetch is None or create is None:
        log.info("application emojis unsupported by this discord.py; using unicode icons")
        return
    try:
        existing = {e.name: e for e in await fetch()}
    except Exception as exc:
        log.warning("could not list application emojis (%s); using unicode icons", exc)
        return
    for name in NAMES:
        emoji_name = f"j2c_{name}"
        emoji = existing.get(emoji_name)
        if emoji is None:
            path = config.ASSETS / "icons" / f"{name}.png"
            if not path.exists():
                continue
            try:
                emoji = await create(name=emoji_name, image=path.read_bytes())
            except Exception as exc:
                log.warning("could not create icon %s (%s); using fallback", emoji_name, exc)
                continue
        _ICONS[name] = discord.PartialEmoji(name=emoji.name, id=emoji.id, animated=getattr(emoji, "animated", False))
