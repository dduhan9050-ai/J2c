"""Tiny async wrapper over stdlib sqlite3 (no extra dependency needed)."""
from __future__ import annotations

import asyncio
import sqlite3
from pathlib import Path
from typing import Any, Iterable


class Database:
    def __init__(self, path: Path | str):
        self.path = Path(path)
        self._conn: sqlite3.Connection | None = None
        self._lock = asyncio.Lock()

    async def connect(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)

        def _open() -> sqlite3.Connection:
            c = sqlite3.connect(str(self.path), check_same_thread=False, isolation_level=None, timeout=30)
            c.row_factory = sqlite3.Row
            c.execute("PRAGMA journal_mode=WAL")
            c.execute("PRAGMA foreign_keys=ON")
            c.execute("PRAGMA busy_timeout=30000")
            return c

        self._conn = await asyncio.to_thread(_open)

    async def execute(self, sql: str, params: Iterable[Any] = ()) -> tuple[int, int | None]:
        assert self._conn is not None, "Database not connected"
        async with self._lock:
            def _run() -> tuple[int, int | None]:
                cur = self._conn.execute(sql, tuple(params))
                return cur.rowcount, cur.lastrowid
            return await asyncio.to_thread(_run)

    async def fetchone(self, sql: str, params: Iterable[Any] = ()) -> sqlite3.Row | None:
        assert self._conn is not None, "Database not connected"
        async with self._lock:
            return await asyncio.to_thread(lambda: self._conn.execute(sql, tuple(params)).fetchone())

    async def fetchall(self, sql: str, params: Iterable[Any] = ()) -> list[sqlite3.Row]:
        assert self._conn is not None, "Database not connected"
        async with self._lock:
            return await asyncio.to_thread(lambda: self._conn.execute(sql, tuple(params)).fetchall())

    def transaction(self) -> "_Tx":
        """``async with db.transaction() as run: await run(sql, params)`` - atomic multi-statement write."""
        return _Tx(self)

    async def close(self) -> None:
        if self._conn is not None:
            conn, self._conn = self._conn, None
            await asyncio.to_thread(conn.close)


class _Tx:
    def __init__(self, db: Database):
        self.db = db

    async def __aenter__(self):
        assert self.db._conn is not None, "Database not connected"
        await self.db._lock.acquire()
        try:
            await asyncio.to_thread(self.db._conn.execute, "BEGIN IMMEDIATE")
        except BaseException:
            self.db._lock.release()
            raise

        async def run(sql: str, params: Iterable[Any] = ()) -> None:
            await asyncio.to_thread(lambda: self.db._conn.execute(sql, tuple(params)))
        return run

    async def __aexit__(self, exc_type, exc, tb) -> bool:
        try:
            await asyncio.to_thread(self.db._conn.execute, "ROLLBACK" if exc_type else "COMMIT")
        finally:
            self.db._lock.release()
        return False
