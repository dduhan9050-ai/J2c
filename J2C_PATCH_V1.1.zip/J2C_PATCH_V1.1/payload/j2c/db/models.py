"""Plain dataclass models for the J2C tables."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .. import config


@dataclass(slots=True)
class GuildSettings:
    guild_id: int
    name_template: str = config.DEFAULT_NAME_TEMPLATE
    default_limit: int = 0
    default_bitrate: int | None = None
    banner: bool = True
    auto_transfer: bool = True
    delete_delay: int = config.DEFAULT_DELETE_DELAY
    max_per_user: int = 1
    enabled: bool = True

    @classmethod
    def from_row(cls, row: Any) -> "GuildSettings":
        return cls(
            guild_id=row["guild_id"], name_template=row["name_template"],
            default_limit=row["default_limit"], default_bitrate=row["default_bitrate"],
            banner=bool(row["banner"]), auto_transfer=bool(row["auto_transfer"]),
            delete_delay=row["delete_delay"], max_per_user=row["max_per_user"],
            enabled=bool(row["enabled"]),
        )


@dataclass(slots=True)
class Hub:
    channel_id: int
    guild_id: int
    category_id: int | None = None

    @classmethod
    def from_row(cls, row: Any) -> "Hub":
        return cls(row["channel_id"], row["guild_id"], row["category_id"])


@dataclass(slots=True)
class TempChannel:
    channel_id: int
    guild_id: int
    owner_id: int
    waiting_channel_id: int | None = None
    locked: bool = False
    hidden: bool = False
    chat_locked: bool = False
    panel_message_id: int | None = None
    owner_left_at: int | None = None
    auto_named: bool = False

    @classmethod
    def from_row(cls, row: Any) -> "TempChannel":
        return cls(
            channel_id=row["channel_id"], guild_id=row["guild_id"], owner_id=row["owner_id"],
            waiting_channel_id=row["waiting_channel_id"], locked=bool(row["locked"]),
            hidden=bool(row["hidden"]), chat_locked=bool(row["chat_locked"]),
            panel_message_id=row["panel_message_id"], owner_left_at=row["owner_left_at"],
            auto_named=bool(row["auto_named"]) if "auto_named" in row.keys() else False,
        )


@dataclass(slots=True)
class Profile:
    guild_id: int
    user_id: int
    name: str | None = None
    user_limit: int | None = None
    bitrate: int | None = None
    rtc_region: str | None = None
    locked: bool = False
    hidden: bool = False
    chat_locked: bool = False

    @classmethod
    def from_row(cls, row: Any) -> "Profile":
        return cls(
            guild_id=row["guild_id"], user_id=row["user_id"], name=row["name"],
            user_limit=row["user_limit"], bitrate=row["bitrate"], rtc_region=row["rtc_region"],
            locked=bool(row["locked"]), hidden=bool(row["hidden"]), chat_locked=bool(row["chat_locked"]),
        )


@dataclass(slots=True)
class ButtonRow:
    """Admin override / custom button. None fields mean 'use the built-in default'."""
    guild_id: int
    button_key: str
    kind: str = "builtin"
    label: str | None = None
    emoji: str | None = None
    style: str | None = None
    section: str | None = None
    payload: str | None = None
    position: int = 0
    removed: bool = False

    @classmethod
    def from_row(cls, row: Any) -> "ButtonRow":
        return cls(row["guild_id"], row["button_key"], row["kind"], row["label"], row["emoji"],
                   row["style"], row["section"], row["payload"], row["position"], bool(row["removed"]))


@dataclass(slots=True)
class MenuRecord:
    guild_id: int
    channel_id: int
    message_id: int | None = None

    @classmethod
    def from_row(cls, row: Any) -> "MenuRecord":
        return cls(row["guild_id"], row["channel_id"], row["message_id"])
