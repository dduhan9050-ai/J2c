-- J2C 0003: dedicated persistent J2C menu channel (one per server).
CREATE TABLE IF NOT EXISTS j2c_menu (
    guild_id   INTEGER PRIMARY KEY,
    channel_id INTEGER NOT NULL,
    message_id INTEGER,
    created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);
