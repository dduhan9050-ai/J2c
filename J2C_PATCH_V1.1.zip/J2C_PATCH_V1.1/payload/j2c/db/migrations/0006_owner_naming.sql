-- J2C 0006: owner-based VC naming.
-- auto_named = 1 -> the room name was generated from the owner, so it is re-generated when
-- ownership changes. Existing rooms default to 0 (their current names are left alone).
ALTER TABLE j2c_channels ADD COLUMN auto_named INTEGER NOT NULL DEFAULT 0;
-- Servers still on the old stock template move to the new one; customised templates are kept.
UPDATE j2c_guilds SET name_template = '{username}Vc' WHERE name_template = '{display_name}''s Room';
