-- J2C 0004: admin-customisable panel layout. A row exists only for buttons the admin
-- touched (NULL column = "use the built-in default"); untouched servers keep the stock layout.
CREATE TABLE IF NOT EXISTS j2c_buttons (
    guild_id   INTEGER NOT NULL,
    button_key TEXT    NOT NULL,
    kind       TEXT    NOT NULL DEFAULT 'builtin' CHECK (kind IN ('builtin','link','info')),
    label      TEXT,
    emoji      TEXT,
    style      TEXT,
    section    TEXT,
    payload    TEXT,
    position   INTEGER NOT NULL DEFAULT 0,
    removed    INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (guild_id, button_key)
);
