-- J2C 0005: category-wise permission rules (Allow / Deny; no row = Inherit).
CREATE TABLE IF NOT EXISTS j2c_perm_rules (
    guild_id     INTEGER NOT NULL,
    category     TEXT    NOT NULL CHECK (category IN ('privacy','members','settings','room')),
    subject_type TEXT    NOT NULL CHECK (subject_type IN ('owner','admin','trusted','role','member')),
    subject_id   INTEGER NOT NULL DEFAULT 0,
    state        TEXT    NOT NULL CHECK (state IN ('allow','deny')),
    updated_at   INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    PRIMARY KEY (guild_id, category, subject_type, subject_id)
);
CREATE TABLE IF NOT EXISTS j2c_trusted_roles (
    guild_id INTEGER NOT NULL,
    role_id  INTEGER NOT NULL,
    PRIMARY KEY (guild_id, role_id)
);
