"""Data access for J2C. All SQL lives here."""
from __future__ import annotations

from typing import Any

from .database import Database
from .. import config
from .models import ButtonRow, GuildSettings, Hub, MenuRecord, Profile, TempChannel

GUILD_FIELDS = {"name_template", "default_limit", "default_bitrate", "banner",
                "auto_transfer", "delete_delay", "max_per_user", "enabled"}
CHANNEL_FIELDS = {"owner_id", "waiting_channel_id", "locked", "hidden", "chat_locked",
                  "panel_message_id", "owner_left_at", "auto_named"}
PROFILE_FIELDS = {"name", "user_limit", "bitrate", "rtc_region", "locked", "hidden", "chat_locked"}


def _val(v: Any) -> Any:
    return int(v) if isinstance(v, bool) else v


def _check(fields: dict, allowed: set[str]) -> None:
    bad = set(fields) - allowed
    if bad:
        raise ValueError(f"Unknown fields: {sorted(bad)}")


class Repository:
    def __init__(self, db: Database):
        self.db = db

    # ---- guild settings -------------------------------------------------
    async def get_guild(self, guild_id: int) -> GuildSettings:
        row = await self.db.fetchone("SELECT * FROM j2c_guilds WHERE guild_id=?", (guild_id,))
        return GuildSettings.from_row(row) if row else GuildSettings(guild_id)

    async def update_guild(self, guild_id: int, **fields: Any) -> GuildSettings:
        _check(fields, GUILD_FIELDS)
        # New rows must start on the CURRENT default template (the SQL column default is the v1.0 one).
        insert = {"name_template": config.DEFAULT_NAME_TEMPLATE, **fields}
        cols = list(insert)
        ph = ",".join("?" for _ in cols)
        if fields:
            upd = ",".join(f"{c}=excluded.{c}" for c in fields) + ", updated_at=strftime('%s','now')"
        else:
            upd = "guild_id=guild_id"
        await self.db.execute(
            f"INSERT INTO j2c_guilds(guild_id,{','.join(cols)}) VALUES(?,{ph}) "
            f"ON CONFLICT(guild_id) DO UPDATE SET {upd}",
            (guild_id, *[_val(insert[c]) for c in cols]),
        )
        return await self.get_guild(guild_id)

    async def reset_guild(self, guild_id: int) -> None:
        for table in ("j2c_menu", "j2c_buttons", "j2c_perm_rules", "j2c_trusted_roles"):
            await self.db.execute(f"DELETE FROM {table} WHERE guild_id=?", (guild_id,))
        await self.db.execute("DELETE FROM j2c_hubs WHERE guild_id=?", (guild_id,))
        await self.db.execute("DELETE FROM j2c_guilds WHERE guild_id=?", (guild_id,))

    # ---- hubs ------------------------------------------------------------
    async def add_hub(self, channel_id: int, guild_id: int, category_id: int | None) -> Hub:
        await self.db.execute(
            "INSERT INTO j2c_hubs(channel_id,guild_id,category_id) VALUES(?,?,?) "
            "ON CONFLICT(channel_id) DO UPDATE SET category_id=excluded.category_id",
            (channel_id, guild_id, category_id))
        return Hub(channel_id, guild_id, category_id)

    async def remove_hub(self, channel_id: int) -> bool:
        n, _ = await self.db.execute("DELETE FROM j2c_hubs WHERE channel_id=?", (channel_id,))
        return n > 0

    async def list_hubs(self, guild_id: int | None = None) -> list[Hub]:
        if guild_id is None:
            rows = await self.db.fetchall("SELECT * FROM j2c_hubs")
        else:
            rows = await self.db.fetchall("SELECT * FROM j2c_hubs WHERE guild_id=?", (guild_id,))
        return [Hub.from_row(r) for r in rows]

    # ---- temp channels ---------------------------------------------------
    async def add_channel(self, channel_id: int, guild_id: int, owner_id: int, **fields: Any) -> TempChannel:
        _check(fields, CHANNEL_FIELDS - {"owner_id"})
        cols = ["channel_id", "guild_id", "owner_id", *fields]
        await self.db.execute(
            f"INSERT OR REPLACE INTO j2c_channels({','.join(cols)}) VALUES({','.join('?' for _ in cols)})",
            (channel_id, guild_id, owner_id, *[_val(v) for v in fields.values()]))
        return (await self.get_channel(channel_id))  # type: ignore[return-value]

    async def get_channel(self, channel_id: int) -> TempChannel | None:
        row = await self.db.fetchone("SELECT * FROM j2c_channels WHERE channel_id=?", (channel_id,))
        return TempChannel.from_row(row) if row else None

    async def list_channels(self, guild_id: int | None = None) -> list[TempChannel]:
        if guild_id is None:
            rows = await self.db.fetchall("SELECT * FROM j2c_channels")
        else:
            rows = await self.db.fetchall("SELECT * FROM j2c_channels WHERE guild_id=?", (guild_id,))
        return [TempChannel.from_row(r) for r in rows]

    async def update_channel(self, channel_id: int, **fields: Any) -> None:
        _check(fields, CHANNEL_FIELDS)
        if not fields:
            return
        sets = ",".join(f"{c}=?" for c in fields)
        await self.db.execute(f"UPDATE j2c_channels SET {sets} WHERE channel_id=?",
                              (*[_val(v) for v in fields.values()], channel_id))

    async def delete_channel(self, channel_id: int) -> None:
        await self.db.execute("DELETE FROM j2c_channels WHERE channel_id=?", (channel_id,))

    # ---- ACL (permit / ban) ---------------------------------------------
    async def acl_set(self, channel_id: int, user_id: int, kind: str) -> None:
        await self.db.execute(
            "INSERT INTO j2c_acl(channel_id,user_id,kind) VALUES(?,?,?) "
            "ON CONFLICT(channel_id,user_id) DO UPDATE SET kind=excluded.kind",
            (channel_id, user_id, kind))

    async def acl_remove(self, channel_id: int, user_id: int) -> None:
        await self.db.execute("DELETE FROM j2c_acl WHERE channel_id=? AND user_id=?", (channel_id, user_id))

    async def acl_get(self, channel_id: int, user_id: int) -> str | None:
        row = await self.db.fetchone("SELECT kind FROM j2c_acl WHERE channel_id=? AND user_id=?",
                                     (channel_id, user_id))
        return row["kind"] if row else None

    async def acl_list(self, channel_id: int, kind: str | None = None) -> list[tuple[int, str]]:
        if kind:
            rows = await self.db.fetchall("SELECT user_id,kind FROM j2c_acl WHERE channel_id=? AND kind=?",
                                          (channel_id, kind))
        else:
            rows = await self.db.fetchall("SELECT user_id,kind FROM j2c_acl WHERE channel_id=?", (channel_id,))
        return [(r["user_id"], r["kind"]) for r in rows]

    # ---- profiles (templates) -------------------------------------------
    async def get_profile(self, guild_id: int, user_id: int) -> Profile | None:
        row = await self.db.fetchone("SELECT * FROM j2c_profiles WHERE guild_id=? AND user_id=?",
                                     (guild_id, user_id))
        return Profile.from_row(row) if row else None

    async def save_profile(self, guild_id: int, user_id: int, **fields: Any) -> None:
        _check(fields, PROFILE_FIELDS)
        cols = list(fields)
        upd = ",".join(f"{c}=excluded.{c}" for c in cols)
        await self.db.execute(
            f"INSERT INTO j2c_profiles(guild_id,user_id,{','.join(cols)}) "
            f"VALUES(?,?,{','.join('?' for _ in cols)}) "
            f"ON CONFLICT(guild_id,user_id) DO UPDATE SET {upd}, updated_at=strftime('%s','now')",
            (guild_id, user_id, *[_val(fields[c]) for c in cols]))

    async def delete_profile(self, guild_id: int, user_id: int) -> None:
        await self.db.execute("DELETE FROM j2c_profiles WHERE guild_id=? AND user_id=?", (guild_id, user_id))

    # ---- meta -------------------------------------------------------------
    async def meta_get(self, key: str) -> str | None:
        row = await self.db.fetchone("SELECT value FROM j2c_meta WHERE key=?", (key,))
        return row["value"] if row else None

    async def meta_set(self, key: str, value: str) -> None:
        await self.db.execute(
            "INSERT INTO j2c_meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value))

    # ---- persistent menu channel -----------------------------------------
    async def get_menu(self, guild_id: int) -> MenuRecord | None:
        row = await self.db.fetchone("SELECT * FROM j2c_menu WHERE guild_id=?", (guild_id,))
        return MenuRecord.from_row(row) if row else None

    async def list_menus(self) -> list[MenuRecord]:
        return [MenuRecord.from_row(r) for r in await self.db.fetchall("SELECT * FROM j2c_menu")]

    async def set_menu(self, guild_id: int, channel_id: int, message_id: int | None) -> None:
        await self.db.execute(
            "INSERT INTO j2c_menu(guild_id,channel_id,message_id) VALUES(?,?,?) "
            "ON CONFLICT(guild_id) DO UPDATE SET channel_id=excluded.channel_id, message_id=excluded.message_id",
            (guild_id, channel_id, message_id))

    async def clear_menu(self, guild_id: int) -> None:
        await self.db.execute("DELETE FROM j2c_menu WHERE guild_id=?", (guild_id,))

    # ---- button layout -----------------------------------------------------
    async def list_buttons(self, guild_id: int) -> list[ButtonRow]:
        rows = await self.db.fetchall("SELECT * FROM j2c_buttons WHERE guild_id=? ORDER BY position, button_key",
                                      (guild_id,))
        return [ButtonRow.from_row(r) for r in rows]

    async def list_custom_buttons(self) -> list[ButtonRow]:
        rows = await self.db.fetchall("SELECT * FROM j2c_buttons WHERE kind!='builtin' AND removed=0")
        return [ButtonRow.from_row(r) for r in rows]

    async def save_buttons(self, guild_id: int, rows: list[ButtonRow]) -> None:
        """Upsert many button rows atomically (one transaction)."""
        async with self.db.transaction() as run:
            for b in rows:
                await run(
                    "INSERT INTO j2c_buttons(guild_id,button_key,kind,label,emoji,style,section,payload,position,removed) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(guild_id,button_key) DO UPDATE SET "
                    "kind=excluded.kind,label=excluded.label,emoji=excluded.emoji,style=excluded.style,"
                    "section=excluded.section,payload=excluded.payload,position=excluded.position,removed=excluded.removed",
                    (guild_id, b.button_key, b.kind, b.label, b.emoji, b.style, b.section, b.payload,
                     b.position, int(b.removed)))

    async def delete_buttons(self, guild_id: int, keys: list[str] | None = None) -> None:
        if keys is None:
            await self.db.execute("DELETE FROM j2c_buttons WHERE guild_id=?", (guild_id,))
            return
        for k in keys:
            await self.db.execute("DELETE FROM j2c_buttons WHERE guild_id=? AND button_key=?", (guild_id, k))

    # ---- category permission rules ------------------------------------------
    async def list_rules(self, guild_id: int) -> list[tuple[str, str, int, str]]:
        rows = await self.db.fetchall(
            "SELECT category,subject_type,subject_id,state FROM j2c_perm_rules WHERE guild_id=?", (guild_id,))
        return [(r["category"], r["subject_type"], r["subject_id"], r["state"]) for r in rows]

    async def set_rule(self, guild_id: int, category: str, subject_type: str, subject_id: int,
                       state: str | None) -> None:
        """state = 'allow' | 'deny' | None (None = Inherit = delete the rule)."""
        if state is None:
            await self.db.execute(
                "DELETE FROM j2c_perm_rules WHERE guild_id=? AND category=? AND subject_type=? AND subject_id=?",
                (guild_id, category, subject_type, subject_id))
            return
        await self.db.execute(
            "INSERT INTO j2c_perm_rules(guild_id,category,subject_type,subject_id,state) VALUES(?,?,?,?,?) "
            "ON CONFLICT(guild_id,category,subject_type,subject_id) DO UPDATE SET state=excluded.state, "
            "updated_at=strftime('%s','now')", (guild_id, category, subject_type, subject_id, state))

    async def clear_rules(self, guild_id: int) -> None:
        await self.db.execute("DELETE FROM j2c_perm_rules WHERE guild_id=?", (guild_id,))

    async def list_trusted_roles(self, guild_id: int) -> list[int]:
        rows = await self.db.fetchall("SELECT role_id FROM j2c_trusted_roles WHERE guild_id=?", (guild_id,))
        return [r["role_id"] for r in rows]

    async def set_trusted_roles(self, guild_id: int, role_ids: list[int]) -> None:
        async with self.db.transaction() as run:
            await run("DELETE FROM j2c_trusted_roles WHERE guild_id=?", (guild_id,))
            for rid in dict.fromkeys(role_ids):
                await run("INSERT INTO j2c_trusted_roles(guild_id,role_id) VALUES(?,?)", (guild_id, rid))
