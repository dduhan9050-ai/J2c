"""/j2c command group (hybrid: works as slash command and prefix command)."""
from __future__ import annotations

import logging
from typing import Literal, Optional

import discord
from discord import app_commands
from discord.ext import commands

from .. import __version__, config
from ..services import names
from ..services.channels import J2CError
from ..services.perms import missing_bot_perms
from ..ui.panel import PanelView, banner_file
from ..ui.views import error_view, info_view, status_view

log = logging.getLogger("j2c.commands")
ADMIN = commands.has_guild_permissions(manage_guild=True)

SETTINGS = Literal["name_template", "default_limit", "default_bitrate", "banner",
                   "auto_transfer", "delete_delay", "max_per_user"]


def _parse_bool(v: str) -> bool:
    s = v.strip().lower()
    if s in ("on", "true", "yes", "1", "enable", "enabled"):
        return True
    if s in ("off", "false", "no", "0", "disable", "disabled"):
        return False
    raise ValueError("use on/off")


def _parse_int(v: str, lo: int, hi: int) -> int:
    n = int(v.strip())
    if not lo <= n <= hi:
        raise ValueError(f"must be between {lo} and {hi}")
    return n


class J2CCommands(commands.Cog, name="J2C"):
    def __init__(self, service):
        self.service = service

    async def cog_command_error(self, ctx: commands.Context, error: Exception) -> None:
        while getattr(error, "original", None) is not None:
            error = error.original
        if isinstance(error, (commands.MissingPermissions, commands.CheckFailure, commands.NoPrivateMessage)):
            await ctx.send(view=error_view("You need the **Manage Server** permission to use this."),
                           ephemeral=True)
        elif isinstance(error, J2CError):
            await ctx.send(view=error_view(str(error)), ephemeral=True)
        elif isinstance(error, (commands.BadArgument, commands.MissingRequiredArgument)):
            await ctx.send(view=error_view(str(error)), ephemeral=True)
        else:
            log.exception("J2C command error", exc_info=error)
            await ctx.send(view=error_view("Something went wrong. Check the bot logs."), ephemeral=True)

    # ---------------------------------------------------------------- group
    @commands.hybrid_group(name=config.COMMAND_NAME, fallback="status",
                           description="Join-to-Create voice channels")
    @commands.guild_only()
    async def j2c(self, ctx: commands.Context) -> None:
        """Show J2C status for this server."""
        await ctx.send(view=await status_view(self.service, ctx.guild), ephemeral=True)

    @j2c.command(name="setup", description="Create / register the Join-to-Create hub")
    @app_commands.describe(category="Category for temp rooms (created if omitted)",
                           hub="An existing voice channel to use as the hub (created if omitted)")
    @commands.guild_only()
    @ADMIN
    async def setup_cmd(self, ctx: commands.Context, category: Optional[discord.CategoryChannel] = None,
                        hub: Optional[discord.VoiceChannel] = None) -> None:
        await ctx.defer(ephemeral=True)
        guild = ctx.guild
        missing = missing_bot_perms(guild)
        if missing:
            raise J2CError("I'm missing permissions: " + ", ".join(missing))
        if hub is None:
            if category is None:
                category = await guild.create_category("🎙️ Join to Create", reason="J2C setup")
            hub = await guild.create_voice_channel(
                "➕ Join to Create", category=category, reason="J2C setup",
                overwrites={guild.default_role: discord.PermissionOverwrite(speak=False, stream=False)})
        elif category is None:
            category = hub.category
        await self.service.repo.update_guild(guild.id)
        h = await self.service.repo.add_hub(hub.id, guild.id, category.id if category else None)
        self.service.hubs[h.channel_id] = h
        await ctx.send(view=info_view("✅ J2C ready", [
            f"**Hub:** {hub.mention}", f"**Rooms go to:** {category.name if category else 'hub category'}",
            "Members join the hub to get their own room with a control panel.",
            f"Tune it with `/{config.COMMAND_NAME} config`.",
        ]), ephemeral=True)

    @j2c.command(name="remove-hub", description="Stop using a voice channel as a J2C hub")
    @commands.guild_only()
    @ADMIN
    async def remove_hub(self, ctx: commands.Context, hub: discord.VoiceChannel) -> None:
        if not await self.service.repo.remove_hub(hub.id):
            raise J2CError(f"{hub.mention} is not a J2C hub.")
        self.service.hubs.pop(hub.id, None)
        await ctx.send(view=info_view("Hub removed", f"{hub.mention} is no longer a hub (channel kept)."),
                       ephemeral=True)

    @j2c.command(name="config", description="Change a J2C setting")
    @app_commands.describe(setting="Which setting", value="New value (on/off, number, or text)")
    @commands.guild_only()
    @ADMIN
    async def config_cmd(self, ctx: commands.Context, setting: SETTINGS, value: str) -> None:
        try:
            if setting == "name_template":
                if not value.strip() or not names.render(value, display_name="Test", username="test"):
                    raise ValueError("empty name")
                new = value.strip()[:80]
            elif setting == "default_limit":
                new = _parse_int(value, 0, 99)
            elif setting == "default_bitrate":
                new = None if value.strip().lower() in ("auto", "off", "default", "0") \
                    else _parse_int(value, 8, 384) * 1000
            elif setting in ("banner", "auto_transfer"):
                new = _parse_bool(value)
            elif setting == "delete_delay":
                new = _parse_int(value, 0, 60)
            else:  # max_per_user
                new = _parse_int(value, 1, 3)
        except ValueError as exc:
            raise J2CError(f"Invalid value for `{setting}`: {exc}")
        await self.service.repo.update_guild(ctx.guild.id, **{setting: new})
        await ctx.send(view=info_view("✅ Updated", f"`{setting}` → `{new}`"), ephemeral=True)

    @j2c.command(name="panel", description="Post the J2C control panel in this channel")
    @commands.guild_only()
    @ADMIN
    async def panel_cmd(self, ctx: commands.Context) -> None:
        settings = await self.service.repo.get_guild(ctx.guild.id)
        file = banner_file() if settings.banner else None
        kwargs = {"file": file} if file else {}
        buttons = await self.service.layout.visible(ctx.guild.id)
        await ctx.channel.send(view=PanelView(self.service, banner=file is not None, buttons=buttons), **kwargs)
        await ctx.send(view=info_view("Panel posted", "Buttons control the room you're currently in."),
                       ephemeral=True)

    @j2c.command(name="controls", description="Open the control panel for your own J2C room")
    @commands.guild_only()
    async def controls(self, ctx: commands.Context) -> None:
        vs = ctx.author.voice
        if vs is None or vs.channel is None or vs.channel.id not in self.service.temp:
            raise J2CError("Join your J2C voice channel first.")
        buttons = await self.service.layout.visible(ctx.guild.id)
        await ctx.send(view=PanelView(self.service, owner_id=self.service.temp[vs.channel.id].owner_id,
                                      buttons=buttons), ephemeral=True)

    @j2c.command(name="cleanup", description="Delete empty / orphaned J2C rooms")
    @commands.guild_only()
    @ADMIN
    async def cleanup(self, ctx: commands.Context) -> None:
        before = len([r for r in self.service.temp.values() if r.guild_id == ctx.guild.id])
        await ctx.defer(ephemeral=True)
        await self.service.reconcile()
        after = len([r for r in self.service.temp.values() if r.guild_id == ctx.guild.id])
        await ctx.send(view=info_view("🧹 Cleanup", f"Removed {before - after} room(s). {after} active."),
                       ephemeral=True)

    @j2c.command(name="reset", description="Remove J2C configuration for this server (rooms are kept)")
    @commands.guild_only()
    @ADMIN
    async def reset(self, ctx: commands.Context) -> None:
        if self.service.menu is not None:
            await self.service.menu.remove(ctx.guild)
        await self.service.repo.reset_guild(ctx.guild.id)
        self.service.layout.invalidate(ctx.guild.id)
        self.service.rules.invalidate(ctx.guild.id)
        for cid in [c for c, h in self.service.hubs.items() if h.guild_id == ctx.guild.id]:
            self.service.hubs.pop(cid, None)
        await ctx.send(view=info_view("J2C reset", "Hubs and settings removed for this server."), ephemeral=True)

    # ------------------------------------------------- v1.1: menu / customise
    @j2c.command(name="menu", description="Create or refresh the persistent J2C menu channel")
    @app_commands.describe(channel="Existing text channel to use (a read-only one is created if omitted)")
    @commands.guild_only()
    @ADMIN
    async def menu_cmd(self, ctx: commands.Context, channel: Optional[discord.TextChannel] = None) -> None:
        await ctx.defer(ephemeral=True)
        missing = missing_bot_perms(ctx.guild)
        if missing:
            raise J2CError("I'm missing permissions: " + ", ".join(missing))
        ch = await self.service.menu.setup(ctx.guild, channel)
        await ctx.send(view=info_view("📌 J2C menu ready", [
            f"**Channel:** {ch.mention}",
            "The menu is permanent: it survives restarts and is re-posted if the message is deleted.",
            f"Customise it with `/{config.COMMAND_NAME} customize`."]), ephemeral=True)

    @j2c.command(name="menu-remove", description="Remove the persistent menu message (the channel is kept)")
    @app_commands.describe(delete_channel="Also delete the menu channel")
    @commands.guild_only()
    @ADMIN
    async def menu_remove_cmd(self, ctx: commands.Context, delete_channel: bool = False) -> None:
        await ctx.defer(ephemeral=True)
        if not await self.service.menu.remove(ctx.guild, delete_channel=delete_channel):
            raise J2CError("No J2C menu is set up in this server.")
        await ctx.send(view=info_view("Menu removed", "The J2C menu was removed."), ephemeral=True)

    @j2c.command(name="customize", description="Admin: edit buttons, permissions, menu channel and naming")
    @commands.guild_only()
    @ADMIN
    async def customize_cmd(self, ctx: commands.Context) -> None:
        from ..ui.admin import HomeView
        view = HomeView(self.service, ctx.author.id, ctx.guild)
        await ctx.send(await view.render(), view=view, ephemeral=True)

    @j2c.command(name="permissions", description="Admin: show the category permission matrix")
    @commands.guild_only()
    @ADMIN
    async def permissions_cmd(self, ctx: commands.Context) -> None:
        lines = await self.service.rules.matrix_lines(ctx.guild)
        await ctx.send(view=info_view("🔐 J2C permissions", lines), ephemeral=True)

    @j2c.command(name="sync", description="(Bot owner) force-sync application commands globally")
    @commands.is_owner()
    async def sync_cmd(self, ctx: commands.Context) -> None:
        await ctx.defer(ephemeral=True)
        synced = await ctx.bot.tree.sync()
        await ctx.send(view=info_view("Synced", f"{len(synced)} global command(s)."), ephemeral=True)

    @j2c.command(name="version", description="Show the installed J2C version")
    async def version(self, ctx: commands.Context) -> None:
        await ctx.send(view=info_view("J2C", f"Version **{__version__}** — {config.BRAND}"), ephemeral=True)
