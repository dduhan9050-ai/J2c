"""Event listeners (voice-state, channel and guild lifecycle)."""
from __future__ import annotations

import discord
from discord.ext import commands


class J2CEvents(commands.Cog, name="J2C Events"):
    def __init__(self, service):
        self.service = service

    @commands.Cog.listener()
    async def on_voice_state_update(self, member: discord.Member, before: discord.VoiceState,
                                    after: discord.VoiceState) -> None:
        await self.service.on_voice_state(member, before, after)

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel) -> None:
        if self.service.loaded:
            await self.service.on_channel_delete(channel)
            if self.service.menu is not None:
                await self.service.menu.on_channel_deleted(channel)

    @commands.Cog.listener()
    async def on_raw_message_delete(self, payload: discord.RawMessageDeleteEvent) -> None:
        """Keep the persistent menu alive: re-post it if someone deletes the message."""
        if self.service.loaded and self.service.menu is not None:
            await self.service.menu.on_message_deleted(payload.guild_id, payload.channel_id, payload.message_id)

    @commands.Cog.listener()
    async def on_guild_remove(self, guild: discord.Guild) -> None:
        if self.service.loaded:
            await self.service.on_guild_remove(guild)
            self.service.layout.invalidate(guild.id)
            self.service.rules.invalidate(guild.id)
