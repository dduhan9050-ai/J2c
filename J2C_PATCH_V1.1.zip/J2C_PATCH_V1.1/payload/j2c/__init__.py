"""DEATH DEVELOPMENT - J2C (Join To Create) voice channel system."""

__version__ = "1.1.0"
__all__ = ["__version__"]
