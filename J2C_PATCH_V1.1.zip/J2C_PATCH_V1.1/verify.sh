#!/usr/bin/env bash
# Post-install checks.  ./verify.sh --bot-dir /home/ubuntu/YOUR_BOT [--service NAME] [--python PATH]
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BOT_DIR=""; SERVICE=""; PY=""; FAIL=0
while [ $# -gt 0 ]; do case "$1" in --bot-dir) BOT_DIR="$2"; shift 2;; --service) SERVICE="$2"; shift 2;; --python) PY="$2"; shift 2;; *) echo "unknown option $1"; exit 1;; esac; done
[ -d "$BOT_DIR/j2c" ] || { echo "--bot-dir must contain j2c/"; exit 1; }
BOT_DIR="$(cd "$BOT_DIR" && pwd)"
if [ -z "$PY" ]; then for p in "$BOT_DIR/venv/bin/python" "$BOT_DIR/.venv/bin/python" "$(command -v python3)"; do [ -x "$p" ] && { PY="$p"; break; }; done; fi
good() { printf '  \033[32m✔\033[0m %s\n' "$*"; }
bad() { printf '  \033[31m✘\033[0m %s\n' "$*"; FAIL=1; }
VER="$(tr -d '[:space:]' < "$HERE/VERSION")"
echo "J2C V$VER verification for $BOT_DIR"
grep -q "__version__ = \"$VER\"" "$BOT_DIR/j2c/__init__.py" && good "installed version is $VER" || bad "installed version is not $VER"
bad_files=0; while read -r h rel; do [ "$(sha256sum "$BOT_DIR/$rel" 2>/dev/null | cut -d' ' -f1)" = "$h" ] || { bad "file differs/missing: $rel"; bad_files=1; }; done < "$HERE/MANIFEST.sha256"
[ $bad_files = 0 ] && good "all $(wc -l < "$HERE/MANIFEST.sha256") patch files match the manifest"
[ -f "$BOT_DIR/j2c/assets/j2c_buttons.png" ] && good "your J2C image is in place" || bad "j2c/assets/j2c_buttons.png missing"
( cd "$BOT_DIR" && "$PY" -I -c "import sys; sys.path.insert(0,'.'); import j2c.ext, j2c.cogs.commands, j2c.ui.admin; print('OK')" 2>&1 ) | grep -q '^OK' && good "modules import" || bad "import failed"
st="$( cd "$BOT_DIR" && "$PY" -m j2c.db.migrate --status 2>&1 )"; echo "$st" | sed 's/^/    /'
echo "$st" | grep -q 'pending: \[\]' && good "no pending migrations" || bad "migrations pending - run ./migrate.sh --bot-dir $BOT_DIR"
if [ -n "$SERVICE" ]; then
  systemctl is-active --quiet "$SERVICE" && good "service $SERVICE is active" || bad "service $SERVICE is not active"
  L="$(sudo journalctl -u "$SERVICE" -n 400 --no-pager 2>/dev/null)"
  echo "$L" | grep -q "\[J2C\] ready v$VER" && good "log shows: [J2C] ready v$VER" || bad "no '[J2C] ready v$VER' line in the recent log"
  echo "$L" | grep -q "\[J2C\] FAILED" && bad "log contains '[J2C] FAILED'" || good "no [J2C] FAILED lines"
else echo "  (add --service NAME to check the running service and logs)"; fi
[ $FAIL = 0 ] && { echo "ALL CHECKS PASSED"; exit 0; } || { echo "SOME CHECKS FAILED"; exit 1; }
