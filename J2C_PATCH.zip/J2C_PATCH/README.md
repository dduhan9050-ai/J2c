# 💀 DEATH DEVELOPMENT — J2C Patch (Join To Create)

A **patch**, not a bot. It adds a complete Join‑To‑Create voice system to your **existing** bot on your AWS Ubuntu VPS.
You upload only this ZIP. Your `.env`, tokens, database credentials and every unrelated module are never touched.

---

## What you get

| Piece | What it does |
|---|---|
| `j2c/` package | Services, DB models + repository, SQL migrations, Components V2 panel, button/modal/select handlers, voice‑state + channel listeners, `/j2c` commands, assets |
| 16‑button panel | Lock · Unlock · Hide · Unhide · Limit · Invite · Ban · Permit · Rename · Bitrate · Region · Template · Chat · Waiting · Claim · Transfer |
| Your button image | Shipped as `j2c/assets/j2c_buttons.png` (panel banner) + 16 cropped buttons + 16 icon PNGs (auto‑uploaded as *application emojis* for the button faces, unicode fallback if that fails) |
| `install.sh` | Validate → backup → apply → integrate → import‑check → migrate → restart → health‑check. **Any failure = automatic rollback.** |
| `rollback.sh` | One command back to the previous version (also installed into your bot as `.j2c_patch/rollback.sh`) |
| `verify.sh` | Post‑install health checks (checksums, entry integration, imports, migrations, service state, logs) |

### How it integrates (the only edit to your existing code)
The installer adds **one 2‑line managed block** to your bot's entry file (backed up first, removed again on rollback):

```python
# >>> J2C PATCH BEGIN (Death Development) - managed block, do not edit
import j2c.bootstrap  # noqa: F401
# <<< J2C PATCH END
```
It loads J2C right before your bot connects. If J2C ever fails to load, your bot **still starts** and logs `[J2C] FAILED …`.
Kill switch without uninstalling: add `Environment=J2C_DISABLE=1` to your service and restart.

J2C stores its data in **its own SQLite file** `data/j2c.db` (tables are all prefixed `j2c_`). It does not touch your database.

---

## 0 · Requirements (the installer checks all of these)

* Python **3.10+**, SQLite 3.24+ (standard on Ubuntu 22.04/24.04)
* **discord.py ≥ 2.6.0** (needed for Components V2). If yours is older, run the installer with `--install-deps` — it upgrades discord.py in your bot's venv and records the old version so rollback can restore it.
* Your bot must have the **voice_states** + **guilds** intents (`discord.Intents.default()` already does).
* Bot permissions in the server: **Manage Channels, Manage Roles (Permissions), Move Members, View Channels, Connect, Send Messages**.
* The bot must be a `commands.Bot` (or `AutoShardedBot`).

---

## 1 · Upload the ZIP (run on YOUR computer)

```bash
# edit these three values once
KEY=~/.ssh/YOUR_KEY.pem
HOST=ubuntu@YOUR_EC2_PUBLIC_IP
ZIP=./J2C_PATCH.zip

scp -i "$KEY" "$ZIP" "$HOST":/home/ubuntu/
```
> Windows PowerShell: `scp -i C:\path\YOUR_KEY.pem .\J2C_PATCH.zip ubuntu@YOUR_EC2_PUBLIC_IP:/home/ubuntu/`

## 2 · Extract (run on the VPS)

```bash
ssh -i ~/.ssh/YOUR_KEY.pem ubuntu@YOUR_EC2_PUBLIC_IP

sudo apt-get install -y unzip            # only if unzip is missing
cd /home/ubuntu
rm -rf j2c_patch && mkdir j2c_patch
unzip -o J2C_PATCH.zip -d j2c_patch
cd j2c_patch/J2C_PATCH
chmod +x install.sh rollback.sh verify.sh tools/*.py
```

## 3 · Dry run (changes nothing)

```bash
BOT_DIR=/home/ubuntu/YOUR_BOT_FOLDER      # the folder that contains your bot's main file + .env
./install.sh --bot-dir "$BOT_DIR" --dry-run
```
It auto‑detects your venv, entry file (`main.py`, `bot.py`, …), the discord.py version and your service manager, and prints every problem it finds. Nothing is modified.
If detection guesses wrong, add flags: `--entry bot.py`, `--python /path/to/venv/bin/python`, `--service mybot`.

## 4 · Apply the patch

```bash
./install.sh --bot-dir "$BOT_DIR"
# discord.py older than 2.6 (the dry run told you)?  add:  --install-deps
# several services or non-standard setup?            add:  --service YOUR_SERVICE_NAME
```
What happens, in order: validate → **backup** (`$BOT_DIR/.j2c_backups/…`) → dependencies → stage + checksum + syntax‑check → atomic file swap → entry integration → import check with your bot's Python → **database migrations** → **restart** your service → health check (service active, `[J2C] ready` in logs, no crash loop).
If anything fails, it **rolls back by itself** (files, entry file, database, discord.py version, service restarted on the old code).

Service manager options (auto‑detected):

| Your setup | Flag |
|---|---|
| systemd (most common) | auto, or `--service mybot` (`.service` optional) |
| systemd *user* unit | `--service mybot --user-unit` |
| pm2 | auto, or `--manager pm2 --service mybot` |
| supervisor | auto, or `--manager supervisor --service mybot` |
| anything else | `--restart-cmd "your restart command"` |
| restart yourself later | `--no-restart` |

## 5 · Dependencies / migrations (manual commands, if you ever need them)

```bash
# the installer already does both; these are the equivalents
"$BOT_DIR/venv/bin/pip" install -r "$BOT_DIR/requirements-j2c.txt"
cd "$BOT_DIR" && ./venv/bin/python -m j2c.db.migrate            # apply pending migrations
cd "$BOT_DIR" && ./venv/bin/python -m j2c.db.migrate --status   # show applied / pending
```
(Replace `./venv/bin/python` with your bot's interpreter.) Migrations are additive and checksummed, so rollbacks never need a schema downgrade.

## 6 · Restart / logs / verify

```bash
# restart (only needed if you used --no-restart)
sudo systemctl restart YOUR_SERVICE

# logs
sudo journalctl -u YOUR_SERVICE -n 100 --no-pager | grep -i j2c
sudo journalctl -u YOUR_SERVICE -f                    # live
#   pm2:  pm2 logs YOUR_PM2_NAME --lines 100

# you should see:
#   [J2C] migration applied: 0001_init.sql ...
#   [J2C] ready v1.0.0 db=/home/ubuntu/YOUR_BOT_FOLDER/data/j2c.db command=/j2c hubs=0 rooms=0
#   [J2C] startup complete

# full health check
./verify.sh --bot-dir "$BOT_DIR"
```

## 7 · Set it up in Discord

1. In your server run **`/j2c setup`** (needs *Manage Server*). It creates a **➕ Join to Create** voice channel + category and registers them. Or use your own: `/j2c setup category:<cat> hub:<voice channel>`.
2. Join the hub → your own room is created, you're moved into it, and the **J2C Control Panel** is posted in that room's chat.
3. Slash commands not showing? See *Slash‑command sync* below. Prefix form also works: `!j2c status` (uses your bot's prefix).

| Command | Who | Purpose |
|---|---|---|
| `/j2c` (status) | everyone | hubs, active rooms, settings, missing bot permissions |
| `/j2c setup [category] [hub]` | Manage Server | create/register a hub |
| `/j2c remove-hub <hub>` | Manage Server | stop using a channel as a hub |
| `/j2c config <setting> <value>` | Manage Server | `name_template` (`{display_name}` `{username}` `{count}`), `default_limit`, `default_bitrate`, `banner`, `auto_transfer`, `delete_delay`, `max_per_user` |
| `/j2c panel` | Manage Server | post a standalone panel in the current channel (acts on the room the clicker is in) |
| `/j2c controls` | everyone | private copy of the panel for your own room |
| `/j2c cleanup` · `/j2c reset` | Manage Server | delete empty/orphan rooms · remove server config |
| `/j2c sync` | bot owner | force a global slash‑command sync |

**Buttons:** Lock/Unlock (block joining) · Hide/Unhide · Limit · Invite (permit + DM single‑use link) · Ban/Permit (pick again to undo) · Rename · Bitrate · Region · Template (save/apply your room defaults) · Chat (lock the room's text chat) · Waiting (waiting‑room channel with Approve/Deny) · Claim (take over when the owner left) · Transfer. Owners who leave are auto‑replaced after 30 s if others remain.

### Slash‑command sync
J2C auto‑syncs **only when that is safe** (your other slash commands are already registered globally, or you have none). If your bot syncs per‑guild or manually, J2C logs a notice instead of risking duplicates — just run your normal sync / restart. Force it with `/j2c sync`, or disable auto‑sync with `J2C_AUTO_SYNC=0`.

### Optional settings (environment variables on your service; never in `.env` by the patcher)
`J2C_DISABLE=1` · `J2C_COMMAND_NAME=j2c` · `J2C_DB_PATH=/path/j2c.db` · `J2C_AUTO_SYNC=auto|0|1` · `J2C_CREATE_COOLDOWN=4` · `J2C_OWNER_GRACE=30`
(If you set `J2C_DB_PATH`, pass the same path to the installer with `--db`.)

---

## 8 · Roll back

```bash
# undo the last patch (works even if you deleted the patch folder)
/home/ubuntu/YOUR_BOT_FOLDER/.j2c_patch/rollback.sh

# options
.../rollback.sh --backup 0001_20261110-223000_none-to-1.0.0   # a specific backup (see list below)
.../rollback.sh --restore-db      # also restore the J2C database from the backup
.../rollback.sh --restore-deps    # also put the previous discord.py version back
.../rollback.sh --no-restart

# list backups / history / state
/home/ubuntu/YOUR_BOT_FOLDER/.j2c_patch/status.sh

# remove J2C completely (keeps data/j2c.db and backups)
/home/ubuntu/YOUR_BOT_FOLDER/.j2c_patch/uninstall.sh
```
Rolling back once returns to the previous J2C version; rolling back again steps further back, ending at "no J2C" with your entry file restored byte‑for‑byte.

**Manual emergency rollback** (if the scripts themselves are unusable):
```bash
cd /home/ubuntu/YOUR_BOT_FOLDER
ls .j2c_backups/                                   # pick the newest folder
B=.j2c_backups/<that-folder>
cp "$B"/entry/* .                                  # restores the original entry file (only if it had been changed)
rm -rf j2c && [ -d "$B/j2c_prev" ] && cp -r "$B/j2c_prev" j2c
sudo systemctl restart YOUR_SERVICE
```
Fastest "just turn it off" switch: add `Environment=J2C_DISABLE=1` to the service → `sudo systemctl daemon-reload && sudo systemctl restart YOUR_SERVICE`.

---

## 9 · Future J2C updates (no full bot upload, ever)

Updates arrive as another small ZIP with the **same layout**. Do exactly steps 1‑2 and 4:

```bash
# local
scp -i ~/.ssh/YOUR_KEY.pem J2C_PATCH_1.1.0_delta.zip ubuntu@YOUR_EC2_PUBLIC_IP:/home/ubuntu/
# VPS
cd /home/ubuntu && rm -rf j2c_patch && mkdir j2c_patch && unzip -o J2C_PATCH_1.1.0_delta.zip -d j2c_patch
cd j2c_patch/J2C_PATCH && chmod +x *.sh tools/*.py
./install.sh --bot-dir /home/ubuntu/YOUR_BOT_FOLDER
```
* **Delta** ZIPs contain only changed files and declare which version they need; **full** ZIPs replace the package. Both keep your database, per‑server settings, and your own `j2c/local.json`.
* Same version again = no‑op; older version = refused (use `--force`).
* Every update is backed up and auto‑rolled‑back on failure, exactly like the first install.
* Building updates yourself: edit `payload/`, bump `__version__` in `payload/j2c/__init__.py`, then `python3 tools/build_patch.py` (full) or `python3 tools/build_patch.py --delta-from J2C_PATCH.zip`.

---

## Safety guarantees

* Writes only: `j2c/`, `requirements-j2c.txt`, `.j2c_backups/`, `.j2c_patch/`, and the 2‑line block in the entry file. Paths in the manifest are validated; anything outside that scope is refused.
* `.env`, tokens, DB credentials, cogs and config files are never read or written (verified by byte‑comparison in the test run).
* Validation before any change: bot dir/permissions, Python & SQLite versions, discord.py version + `LayoutView`, entry file syntax, payload checksums, conflicting `j2c` folders/commands, free disk.
* Backups of files, entry file, J2C database (SQLite online backup) and discord.py version; last 15 kept.

## Troubleshooting

| Symptom | Fix |
|---|---|
| `discord.py X does not satisfy >= 2.6.0` | re‑run with `--install-deps` (needs internet on the VPS) |
| `Multiple systemd units reference this bot` | add `--service NAME` |
| `Could not detect the bot's entry file` | add `--entry yourfile.py` |
| `[J2C] FAILED to load: …` in logs | the bot still runs; send me the traceback, or `rollback.sh` |
| `/j2c` missing in Discord | slash sync note above; `!j2c status` works regardless |
| Command name clash | set `J2C_COMMAND_NAME=j2cx` on the service |
| Panel buttons show unicode icons | normal fallback if application emojis can't be created |
| Docker‑based bot | not auto‑restarted: use `--no-restart`, then restart the container yourself (mount `j2c/` and `data/` as volumes) |
