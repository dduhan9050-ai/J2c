#!/usr/bin/env bash
# Roll back the last patch.  ./rollback.sh --bot-dir /home/ubuntu/YOUR_BOT [--backup ID] [--restore-db] [--restore-deps]
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec python3 "$HERE/tools/j2c_patch.py" rollback "$@"
