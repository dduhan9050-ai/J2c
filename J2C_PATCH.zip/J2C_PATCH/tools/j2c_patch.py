#!/usr/bin/env python3
"""DEATH DEVELOPMENT - J2C patch installer (stdlib only, Python 3.8+).

Applies / updates / rolls back the J2C module on an EXISTING bot without
touching anything unrelated. It only ever writes:
  * <bot>/j2c/                      (the J2C package)
  * <bot>/requirements-j2c.txt      (J2C's own dependency list)
  * <bot>/.j2c_backups/, <bot>/.j2c_patch/   (backups + installer state)
  * one marked 2-line block in your bot's entry file (backed up first)
It NEVER reads or writes .env, tokens, other modules or your own databases.

Commands:  apply | validate | rollback | verify | status | backups | uninstall
"""
from __future__ import annotations

import argparse
import ast
import datetime as dt
import fcntl
import hashlib
import json
import os
import re
import shlex
import shutil
import sqlite3
import subprocess
import sys
import time
from pathlib import Path

STATE_DIR = ".j2c_patch"
BACKUP_DIR = ".j2c_backups"
RECORD = "j2c/.j2c_install.json"
BEGIN = "# >>> J2C PATCH BEGIN (Death Development) - managed block, do not edit"
END = "# <<< J2C PATCH END"
IMPORT_LINE = "import j2c.bootstrap  # noqa: F401"
BLOCK_RE = re.compile(r"\r?\n?# >>> J2C PATCH BEGIN.*?# <<< J2C PATCH END\r?\n?", re.S)
READY_MARKER = "[J2C] ready"
FAIL_MARKER = "[J2C] FAILED"
KEEP_BACKUPS = 15
ALLOWED_FILES = {"requirements-j2c.txt"}
ENTRY_CANDIDATES = ["main.py", "bot.py", "app.py", "run.py", "start.py", "index.py", "__main__.py"]

PROBE = r"""
import sys, json, sqlite3
d = {"py": list(sys.version_info[:3]), "sqlite": sqlite3.sqlite_version, "discord": None, "layout": False}
try:
    import discord
    d["discord"] = discord.__version__
    d["layout"] = hasattr(discord.ui, "LayoutView")
except Exception as e:
    d["discord_error"] = repr(e)
print(json.dumps(d))
"""
IMPORT_CHECK = (
    "import sys; sys.path.insert(0, sys.argv[1]); "
    "import j2c.bootstrap, j2c.ext, j2c.cogs.commands, j2c.cogs.events, j2c.ui.panel; print('IMPORT_OK')"
)
MIGRATE_CODE = (
    "import sys; sys.path.insert(0, sys.argv[1]); from j2c.db.migrate import main; "
    "sys.exit(main(sys.argv[2:]))"
)

C = sys.stdout.isatty()


def _c(code: str, s: str) -> str:
    return f"\033[{code}m{s}\033[0m" if C else s


def step(n, total, msg):
    print(_c("1;36", f"\n[{n}/{total}] {msg}"))


def ok(msg):
    print(_c("32", "  ✔ ") + msg)


def warn(msg):
    print(_c("33", "  ! ") + msg)


def info(msg):
    print("    " + msg)


def fail(msg):
    print(_c("31", "  ✘ ") + msg)


class PatchError(Exception):
    pass


# --------------------------------------------------------------------- utils
def sh(cmd, cwd=None, timeout=300, input_=None):
    try:
        return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout, input=input_)
    except FileNotFoundError as e:
        return subprocess.CompletedProcess(cmd, 127, "", str(e))
    except subprocess.TimeoutExpired:
        return subprocess.CompletedProcess(cmd, 124, "", "timeout")


def sudo():
    return [] if hasattr(os, "geteuid") and os.geteuid() == 0 else ["sudo"]


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def vt(v) -> tuple:
    out = []
    for part in re.split(r"[.\-+]", str(v)):
        m = re.match(r"\d+", part)
        if not m:
            break
        out.append(int(m.group()))
    return tuple(out) or (0,)


def now_id() -> str:
    return dt.datetime.now().strftime("%Y%m%d-%H%M%S")


def next_backup_id(bot: Path, frm: str, to: str) -> str:
    seqs = [int(d.name[:4]) for d in list_backups(bot) if d.name[:4].isdigit()]
    return f"{(max(seqs) + 1 if seqs else 1):04d}_{now_id()}_{frm}-to-{to}"


def load_json(p: Path, default=None):
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return default


def write_json(p: Path, data) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def copytree(src: Path, dst: Path) -> None:
    shutil.copytree(src, dst, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))


def history(bot: Path, line: str) -> None:
    p = bot / BACKUP_DIR / "history.log"
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "a", encoding="utf-8") as f:
        f.write(f"{dt.datetime.now().isoformat(timespec='seconds')} {line}\n")


class Lock:
    def __init__(self, bot: Path):
        (bot / STATE_DIR).mkdir(parents=True, exist_ok=True)
        self.f = open(bot / STATE_DIR / "lock", "w")

    def __enter__(self):
        try:
            fcntl.flock(self.f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            raise PatchError("Another J2C patch operation is already running.")
        return self

    def __exit__(self, *a):
        fcntl.flock(self.f, fcntl.LOCK_UN)
        self.f.close()


# ------------------------------------------------------------------ manifest
def load_manifest(patch_dir: Path) -> dict:
    m = load_json(patch_dir / "patch.json")
    if not m:
        raise PatchError(f"patch.json missing or unreadable in {patch_dir}")
    for k in ("name", "version", "mode", "files"):
        if k not in m:
            raise PatchError(f"patch.json is missing key '{k}'")
    if m["mode"] not in ("full", "delta"):
        raise PatchError("patch.json mode must be 'full' or 'delta'")
    for rel in list(m["files"]) + list(m.get("delete", [])):
        norm = os.path.normpath(rel)
        if norm.startswith("..") or os.path.isabs(norm) or not (norm.startswith("j2c" + os.sep) or norm in ALLOWED_FILES):
            raise PatchError(f"Refusing path outside J2C scope in manifest: {rel}")
    return m


def verify_payload(patch_dir: Path, m: dict) -> list[str]:
    problems = []
    for rel, meta in m["files"].items():
        p = patch_dir / "payload" / rel
        if not p.is_file():
            problems.append(f"missing payload file: {rel}")
        elif sha256(p) != meta["sha256"]:
            problems.append(f"checksum mismatch (corrupt/modified): {rel}")
    return problems


# -------------------------------------------------------------- environment
def probe_python(py: str, bot: Path) -> dict | None:
    r = sh([py, "-I", "-c", PROBE], cwd=str(bot))
    if r.returncode != 0:
        return None
    try:
        return json.loads(r.stdout.strip().splitlines()[-1])
    except Exception:
        return None


def find_python(bot: Path, explicit: str | None, hint: str | None) -> str:
    cands = [explicit] if explicit else []
    for d in ("venv", ".venv", "env", "virtualenv"):
        cands.append(str(bot / d / "bin" / "python"))
    if hint:
        cands.append(hint)
    cands += [shutil.which("python3") or "", sys.executable]
    for c in cands:
        if c and Path(c).exists() and probe_python(c, bot):
            return c
    raise PatchError("No usable Python interpreter found. Pass --python /path/to/venv/bin/python")


def detect_entry(bot: Path, explicit: str | None, hint: str | None) -> Path:
    if explicit:
        p = (bot / explicit) if not os.path.isabs(explicit) else Path(explicit)
        if not p.is_file():
            raise PatchError(f"--entry file not found: {p}")
        return p
    if hint and Path(hint).is_file():
        return Path(hint)
    cands = ENTRY_CANDIDATES + [bot.name + ".py"]
    scored = []
    for name in cands:
        p = bot / name
        if p.is_file():
            t = p.read_text(encoding="utf-8", errors="ignore")
            score = (".run(" in t) * 2 + bool(re.search(r"commands\.Bot|discord\.Client|Bot\(", t))
            if score:
                scored.append((score, p))
    if scored:
        scored.sort(key=lambda x: -x[0])
        return scored[0][1]
    raise PatchError("Could not detect the bot's entry file. Pass --entry main.py (the file you run).")


# ---------------------------------------------------------- service handling
def _systemd_scan(bot: Path):
    real = os.path.realpath(bot)
    dirs = [(Path("/etc/systemd/system"), False), (Path.home() / ".config/systemd/user", True)]
    found = []
    for d, user in dirs:
        if not d.is_dir():
            continue
        for f in d.glob("*.service"):
            try:
                t = f.read_text(errors="ignore")
            except OSError:
                continue
            wd = re.search(r"^WorkingDirectory=(.+)$", t, re.M)
            ex = re.search(r"^ExecStart=(.+)$", t, re.M)
            hit = (wd and os.path.realpath(wd.group(1).strip().lstrip("-")) == real) or \
                  (ex and real in ex.group(1))
            if hit:
                found.append({"kind": "systemd", "name": f.name, "user": user,
                              "exec": ex.group(1).strip() if ex else ""})
    return found


def detect_service(bot: Path, args) -> dict | None:
    saved = load_json(bot / STATE_DIR / "service.json")
    if args.restart_cmd:
        return {"kind": "custom", "cmd": args.restart_cmd}
    if args.service:
        kind = args.manager or "systemd"
        name = args.service if kind != "systemd" or args.service.endswith(".service") else args.service + ".service"
        user = bool(args.user_unit)
        return {"kind": kind, "name": name, "user": user, "exec": ""}
    if saved:
        return saved
    found = _systemd_scan(bot)
    if len(found) == 1:
        return found[0]
    if len(found) > 1:
        raise PatchError("Multiple systemd units reference this bot: " + ", ".join(f["name"] for f in found)
                         + ". Pass --service <name>.")
    if shutil.which("pm2"):
        r = sh(["pm2", "jlist"])
        if r.returncode == 0:
            try:
                for p in json.loads(r.stdout[r.stdout.index("["):]):
                    if os.path.realpath(p.get("pm2_env", {}).get("pm_cwd", "")) == os.path.realpath(bot):
                        return {"kind": "pm2", "name": p["name"]}
            except Exception:
                pass
    conf = Path("/etc/supervisor/conf.d")
    if conf.is_dir():
        for f in conf.glob("*.conf"):
            t = f.read_text(errors="ignore")
            if re.search(rf"^directory\s*=\s*{re.escape(str(bot))}/?\s*$", t, re.M):
                m = re.search(r"^\[program:([^\]]+)\]", t, re.M)
                if m:
                    return {"kind": "supervisor", "name": m.group(1)}
    return None


def _sysd(svc, *a):
    base = ["systemctl"] + (["--user"] if svc.get("user") else [])
    return (([] if svc.get("user") else sudo()) + base + list(a))


def svc_ctl(svc: dict, action: str) -> subprocess.CompletedProcess:
    k = svc["kind"]
    if k == "systemd":
        return sh(_sysd(svc, action, svc["name"]), timeout=120)
    if k == "pm2":
        return sh(["pm2", {"stop": "stop", "start": "start", "restart": "restart"}[action], svc["name"]], timeout=120)
    if k == "supervisor":
        return sh(sudo() + ["supervisorctl", action, svc["name"]], timeout=120)
    if k == "custom":
        if action == "restart":
            return sh(["bash", "-lc", svc["cmd"]], timeout=180)
        return subprocess.CompletedProcess([], 0, "", "")
    raise PatchError(f"Unknown service manager: {k}")


def svc_logs(svc: dict, since_epoch: float) -> str:
    k = svc["kind"]
    if k == "systemd":
        cmd = ["journalctl"] + (["--user"] if svc.get("user") else []) + \
              ["-u", svc["name"], "--since", f"@{int(since_epoch)}", "--no-pager", "-o", "cat"]
        r = sh(cmd, timeout=30)
        if r.returncode != 0 or (not r.stdout and "ermission" in r.stderr):
            r = sh(sudo() + cmd, timeout=30)
        return r.stdout
    if k == "pm2":
        r = sh(["pm2", "logs", svc["name"], "--lines", "300", "--nostream", "--raw"], timeout=30)
        return r.stdout + r.stderr
    return ""


def svc_state(svc: dict) -> str:
    k = svc["kind"]
    if k == "systemd":
        return sh(_sysd(svc, "is-active", svc["name"])).stdout.strip() or "unknown"
    if k == "pm2":
        r = sh(["pm2", "jlist"])
        try:
            for p in json.loads(r.stdout[r.stdout.index("["):]):
                if p["name"] == svc["name"]:
                    return "active" if p["pm2_env"]["status"] == "online" else p["pm2_env"]["status"]
        except Exception:
            pass
        return "unknown"
    if k == "supervisor":
        out = sh(sudo() + ["supervisorctl", "status", svc["name"]]).stdout
        return "active" if "RUNNING" in out else out.strip() or "unknown"
    return "unknown"


def n_restarts(svc: dict) -> int:
    if svc["kind"] != "systemd":
        return 0
    out = sh(_sysd(svc, "show", svc["name"], "-p", "NRestarts", "--value")).stdout.strip()
    return int(out) if out.isdigit() else 0


def restart_and_check(svc: dict, timeout: int = 40) -> tuple[bool, str]:
    before = n_restarts(svc)
    t0 = time.time() - 2
    r = svc_ctl(svc, "restart")
    if r.returncode != 0:
        return False, f"restart command failed: {r.stderr.strip() or r.stdout.strip()}"
    if svc["kind"] == "custom":
        return True, "custom restart command ran (no health check available)"
    deadline = time.time() + timeout
    seen_ready = False
    state = "unknown"
    time.sleep(4)
    while time.time() < deadline:
        state = svc_state(svc)
        logs = svc_logs(svc, t0)
        if FAIL_MARKER in logs:
            return False, "J2C reported a load failure in the bot logs"
        if state in ("failed", "inactive", "dead", "FATAL", "stopped", "errored"):
            return False, f"service state is '{state}' after restart"
        if n_restarts(svc) > before:
            return False, "service is crash-looping after restart"
        if READY_MARKER in logs and state == "active":
            seen_ready = True
            time.sleep(4)  # make sure it stays up
            if svc_state(svc) == "active" and n_restarts(svc) == before:
                return True, "service active and J2C reported ready"
        time.sleep(2)
    if state == "active":
        return True, ("service is active but the '[J2C] ready' log line was not seen "
                      "(logs may be unreadable) - run verify.sh")
    return False, f"service state '{state}' (ready marker seen: {seen_ready})"


# -------------------------------------------------------------- entry block
def inject_entry(entry: Path) -> bool:
    raw = entry.read_bytes().decode("utf-8")
    if BEGIN in raw:
        return False
    nl = "\r\n" if "\r\n" in raw else "\n"
    tree = ast.parse(raw)
    lines = raw.splitlines(keepends=True)
    after = 0
    for i, node in enumerate(tree.body):
        is_doc = (i == 0 and isinstance(node, ast.Expr) and isinstance(getattr(node, "value", None), ast.Constant)
                  and isinstance(node.value.value, str))
        if is_doc or isinstance(node, (ast.Import, ast.ImportFrom)):
            after = node.end_lineno
            continue
        break
    if after == 0:
        while after < len(lines) and lines[after].startswith("#"):
            after += 1
    if after and not lines[after - 1].endswith(("\n", "\r")):
        lines[after - 1] += nl
    block = f"{nl}{BEGIN}{nl}{IMPORT_LINE}{nl}{END}{nl}"
    lines.insert(after, block)
    new = "".join(lines)
    ast.parse(new)  # must still be valid python
    entry.write_bytes(new.encode("utf-8"))
    return True


def remove_entry_block(entry: Path) -> bool:
    raw = entry.read_bytes().decode("utf-8")      # bytes: keep CRLF/LF exactly as the file had them
    new = BLOCK_RE.sub("", raw, count=1) if BEGIN in raw else raw
    if new != raw:
        ast.parse(new)
        entry.write_bytes(new.encode("utf-8"))
        return True
    return False


# ------------------------------------------------------------------- backups
def list_backups(bot: Path) -> list[Path]:
    root = bot / BACKUP_DIR
    if not root.is_dir():
        return []
    return sorted([d for d in root.iterdir() if (d / "meta.json").is_file()], key=lambda d: d.name)


def db_files(db: Path) -> list[Path]:
    return [db, Path(str(db) + "-wal"), Path(str(db) + "-shm")]


def sqlite_backup(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    a = sqlite3.connect(str(src))
    b = sqlite3.connect(str(dst))
    try:
        a.backup(b)
    finally:
        b.close()
        a.close()


def prune(bot: Path) -> None:
    for d in list_backups(bot)[:-KEEP_BACKUPS]:
        shutil.rmtree(d, ignore_errors=True)


def installed_record(bot: Path) -> dict | None:
    return load_json(bot / RECORD)


def resolve_db(bot: Path, args) -> Path:
    raw = getattr(args, "db", None) or os.environ.get("J2C_DB_PATH")
    if not raw:
        return bot / "data" / "j2c.db"
    p = Path(raw)
    return p if p.is_absolute() else bot / p


# ---------------------------------------------------------------- validation
def validate(args, bot: Path, patch_dir: Path, m: dict):
    """Returns (ctx, problems, warnings). Never modifies anything."""
    problems, warns = [], []
    ctx: dict = {}
    if not bot.is_dir():
        problems.append(f"bot directory not found: {bot}")
        return ctx, problems, warns
    if not os.access(bot, os.W_OK):
        problems.append(f"bot directory is not writable by this user: {bot}")
    problems += verify_payload(patch_dir, m)

    try:
        svc = detect_service(bot, args)
    except PatchError as e:
        svc = None
        problems.append(str(e))
    ctx["service"] = svc
    hint_py = None
    hint_entry = None
    if svc and svc.get("exec"):
        toks = shlex.split(svc["exec"].lstrip("-@+!"))
        for t in toks:
            if t.endswith("python") or re.search(r"/python3?(\.\d+)?$", t):
                hint_py = t
            if t.endswith(".py"):
                hint_entry = t if os.path.isabs(t) else str(bot / t)
    try:
        ctx["python"] = py = find_python(bot, args.python, hint_py)
        ctx["probe"] = pr = probe_python(py, bot)
    except PatchError as e:
        problems.append(str(e))
        return ctx, problems, warns
    min_py = vt(m.get("min_python", "3.10"))
    if tuple(pr["py"]) < min_py:
        problems.append(f"Python {'.'.join(map(str, pr['py']))} is too old (need >= {m.get('min_python')})")
    if vt(pr["sqlite"]) < (3, 24):
        problems.append(f"SQLite {pr['sqlite']} too old (need >= 3.24)")
    min_dc = m.get("min_discord", "2.6.0")
    need_deps = pr["discord"] is None or vt(pr["discord"]) < vt(min_dc) or not pr["layout"]
    ctx["need_deps"] = need_deps
    if need_deps:
        have = pr["discord"] or "not installed"
        msg = (f"discord.py {have} in {py} does not satisfy >= {min_dc} (Components V2 needs LayoutView). "
               f"Re-run with --install-deps to upgrade it (the old version is recorded for rollback).")
        (warns if args.install_deps else problems).append(msg)

    try:
        ctx["entry"] = entry = detect_entry(bot, args.entry, hint_entry)
        ast.parse(entry.read_text(encoding="utf-8"))
        if not os.access(entry, os.W_OK):
            problems.append(f"entry file not writable: {entry}")
        if BEGIN not in entry.read_text(encoding="utf-8"):
            txt = entry.read_text(encoding="utf-8", errors="ignore")
            if not re.search(r"Intents\.(all|default)\(|voice_states", txt):
                warns.append("could not confirm the voice_states intent in the entry file; J2C needs it "
                             "(Intents.default() already includes it).")
    except (PatchError, SyntaxError) as e:
        problems.append(f"entry file: {e}")

    rec = installed_record(bot)
    ctx["record"] = rec
    cur = rec["version"] if rec else None
    if rec and vt(m["version"]) < vt(cur) and not args.force:
        problems.append(f"installed J2C {cur} is newer than this patch {m['version']} (use --force to downgrade)")
    if rec and vt(m["version"]) == vt(cur) and not args.force:
        warns.append(f"J2C {cur} is already installed; applying the same version again requires --force")
        ctx["same_version"] = True
    req = m.get("requires_installed")
    if m["mode"] == "delta" and (not rec or vt(cur) < vt(req or "0")):
        problems.append(f"this update needs J2C >= {req} already installed (found {cur or 'none'})")
    if (bot / "j2c").exists() and not rec and not args.force:
        problems.append("a 'j2c' folder already exists but was not installed by this patch. "
                        "Move it away or use --force (it will be backed up).")
    if (bot / "j2c.py").exists():
        problems.append("a j2c.py file in the bot root would shadow the j2c package. Rename it.")
    if shutil.disk_usage(bot).free < 80 * 1024 * 1024:
        problems.append("less than 80 MB free disk space")
    clash = []
    for p in bot.rglob("*.py"):
        if any(part in (".git", "venv", ".venv", "env", "node_modules", "j2c", STATE_DIR, BACKUP_DIR) for part in p.relative_to(bot).parts):
            continue
        try:
            if re.search(r"""(?:hybrid_group|group|command)\(\s*(?:name\s*=\s*)?["']j2c["']""", p.read_text(errors="ignore")):
                clash.append(str(p.relative_to(bot)))
        except OSError:
            pass
    if clash:
        warns.append("your bot already defines a 'j2c' command in " + ", ".join(clash)
                     + " - set J2C_COMMAND_NAME=j2cx (service Environment=) to avoid a conflict")
    ctx["db"] = resolve_db(bot, args)
    return ctx, problems, warns


# ---------------------------------------------------------------- apply flow
def apply(args) -> int:
    patch_dir = Path(args.patch_dir).resolve()
    bot = resolve_bot(args)
    m = load_manifest(patch_dir)
    total = 10
    print(_c("1", f"DEATH DEVELOPMENT • J2C patch {m['version']} ({m['mode']}) → {bot}"))

    step(1, total, "Validating environment")
    ctx, problems, warns = validate(args, bot, patch_dir, m)
    for w in warns:
        warn(w)
    if problems:
        for p in problems:
            fail(p)
        print(_c("31", "\nValidation failed. NOTHING was changed."))
        return 2
    py, entry, svc, db = ctx["python"], ctx["entry"], ctx["service"], ctx["db"]
    ok(f"python: {py} (discord.py {ctx['probe']['discord'] or 'missing'})")
    ok(f"entry file: {entry.relative_to(bot) if entry.is_relative_to(bot) else entry}")
    ok(f"service: {svc['kind'] + ':' + svc.get('name', '') if svc else 'none detected (restart manually)'}")
    ok(f"database: {db}")
    ok("payload checksums verified")
    if ctx.get("same_version") and not args.force:
        print("Nothing to do.")
        return 0
    if args.dry_run:
        print(_c("32", "\nDry run complete - validation passed, nothing changed."))
        return 0

    with Lock(bot):
        rec_prev = ctx["record"]
        bid = next_backup_id(bot, (rec_prev or {}).get("version", "none"), m["version"])
        bdir = bot / BACKUP_DIR / bid
        meta = {"id": bid, "created": dt.datetime.now().isoformat(timespec="seconds"),
                "from_version": (rec_prev or {}).get("version"), "to_version": m["version"],
                "entry": str(entry), "entry_injected": False, "had_j2c_dir": (bot / "j2c").exists(),
                "db_path": str(db), "db_existed": db.exists(), "db_backup": None,
                "pip": {"changed": False, "previous": ctx["probe"]["discord"], "python": py},
                "had_requirements": (bot / "requirements-j2c.txt").exists(),
                "service": svc, "rolled_back": None}

        step(2, total, "Creating backup")
        bdir.mkdir(parents=True)
        if (bot / "j2c").exists():
            copytree(bot / "j2c", bdir / "j2c_prev")
        (bdir / "entry").mkdir()
        shutil.copy2(entry, bdir / "entry" / entry.name)
        if (bot / "requirements-j2c.txt").exists():
            shutil.copy2(bot / "requirements-j2c.txt", bdir / "requirements-j2c.txt")
        if db.exists():
            sqlite_backup(db, bdir / "db" / db.name)
            meta["db_backup"] = f"db/{db.name}"
        write_json(bdir / "meta.json", meta)
        ok(f"backup: {bdir}")

        try:
            step(3, total, "Dependencies")
            if ctx["need_deps"] and args.install_deps and not args.skip_deps:
                req = m.get("requirements") or ["discord.py>=2.6.0"]
                r = sh([py, "-m", "pip", "install", "--upgrade", *req], timeout=900)
                if r.returncode != 0:
                    raise PatchError("pip install failed:\n" + (r.stderr or r.stdout)[-1500:])
                meta["pip"]["changed"] = True
                write_json(bdir / "meta.json", meta)
                ok("installed: " + ", ".join(req))
            else:
                ok("all requirements already satisfied" if not ctx["need_deps"] else "skipped (--skip-deps)")

            step(4, total, "Staging and verifying new J2C files")
            stage = bot / STATE_DIR / "staging" / bid
            if stage.exists():
                shutil.rmtree(stage)
            stage_j2c = stage / "j2c"
            if (bot / "j2c").exists():
                copytree(bot / "j2c", stage_j2c)
            else:
                stage_j2c.mkdir(parents=True)
            prev_files = set((rec_prev or {}).get("files", {}))
            if m["mode"] == "full":
                for rel in prev_files - set(m["files"]):
                    (stage / rel).unlink(missing_ok=True)
            for rel in m.get("delete", []):
                (stage / rel).unlink(missing_ok=True)
            preserve = set(m.get("preserve", []))
            for rel in m["files"]:
                if rel in ALLOWED_FILES:
                    continue
                dst = stage / rel
                if rel in preserve and dst.exists():
                    continue
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(patch_dir / "payload" / rel, dst)
            for rel, meta_f in m["files"].items():
                if rel in ALLOWED_FILES:
                    continue
                if rel not in preserve and sha256(stage / rel) != meta_f["sha256"]:
                    raise PatchError(f"staged file failed checksum: {rel}")
            check = ("import ast,sys,pathlib\n"
                     "for p in pathlib.Path(sys.argv[1]).rglob('*.py'):\n"
                     "    ast.parse(p.read_text(encoding='utf-8'), str(p))\nprint('SYNTAX_OK')")
            r = sh([py, "-I", "-c", check, str(stage_j2c)])
            if "SYNTAX_OK" not in r.stdout:
                raise PatchError("syntax check failed with the bot's Python:\n" + r.stderr[-1500:])
            record = {"name": m["name"], "version": m["version"], "mode": m["mode"],
                      "installed_at": meta["created"], "backup_id": bid, "entry": str(entry),
                      "files": {k: v["sha256"] for k, v in m["files"].items() if k not in ALLOWED_FILES}}
            write_json(stage_j2c / ".j2c_install.json", record)
            ok(f"{len(m['files'])} file(s) staged, checksums and syntax OK")

            step(5, total, "Installing files (atomic swap; your other files are untouched)")
            cur = bot / "j2c"
            old = bot / STATE_DIR / f"old_j2c_{bid}"
            if cur.exists():
                os.rename(cur, old)
            os.rename(stage_j2c, cur)
            if "requirements-j2c.txt" in m["files"]:
                shutil.copy2(patch_dir / "payload" / "requirements-j2c.txt", bot / "requirements-j2c.txt")
            shutil.rmtree(stage, ignore_errors=True)
            ok("J2C files in place")

            step(6, total, "Integrating with the bot entry file")
            if inject_entry(entry):
                meta["entry_injected"] = True
                write_json(bdir / "meta.json", meta)
                ok(f"added 1 managed import to {entry.name} (original saved in backup)")
            else:
                ok("entry file already integrated")

            step(7, total, "Import check with the bot's Python")
            r = sh([py, "-I", "-c", IMPORT_CHECK, str(bot)], cwd=str(bot))
            if "IMPORT_OK" not in r.stdout:
                raise PatchError("J2C modules failed to import:\n" + (r.stderr or r.stdout)[-2000:])
            ok("j2c.bootstrap / j2c.ext / commands / events / panel import cleanly")

            step(8, total, "Running database migrations")
            mig = [py, "-I", "-c", MIGRATE_CODE, str(bot)] + (["--db", str(db)] if args.db else [])
            r = sh(mig, cwd=str(bot))
            if r.returncode != 0:
                raise PatchError("migration failed:\n" + (r.stderr or r.stdout)[-1500:])
            ok(r.stdout.strip().splitlines()[-1] if r.stdout.strip() else "migrations up to date")

            step(9, total, "Restarting the bot")
            if args.no_restart or not svc:
                warn("not restarting (--no-restart or no service detected). Restart your bot manually to load J2C.")
            else:
                good, msg = restart_and_check(svc)
                if not good:
                    raise PatchError("post-restart health check failed: " + msg)
                ok(msg)
                write_json(bot / STATE_DIR / "service.json", svc)
        except (PatchError, Exception) as exc:  # noqa: BLE001 - any failure => rollback
            print()
            fail(f"INSTALL FAILED: {exc}")
            print(_c("33", "Rolling back automatically..."))
            try:
                do_rollback(bot, bid, restore_db=True, restore_deps=True, restart=bool(svc) and not args.no_restart,
                            auto=True, svc=svc, python=py, quiet=False)
                print(_c("31", "\nPatch NOT applied. Your bot was restored to its previous state."))
                return 1
            except Exception as rexc:  # noqa: BLE001
                fail(f"ROLLBACK ERROR: {rexc}")
                print(_c("31", f"Backup is intact at {bdir}. Restore manually: ./.j2c_patch/rollback.sh"))
                return 3

        step(10, total, "Finalising")
        shutil.rmtree(bot / STATE_DIR / f"old_j2c_{bid}", ignore_errors=True)
        install_helpers(bot, patch_dir)
        history(bot, f"APPLIED {m['version']} ({m['mode']}) backup={bid}")
        prune(bot)
        ok("rollback tooling installed at .j2c_patch/ (works even if you delete the patch folder)")
        print(_c("1;32", f"\n✔ J2C {m['version']} installed. Verify with:  ./verify.sh --bot-dir {bot}"))
        return 0


def install_helpers(bot: Path, patch_dir: Path) -> None:
    d = bot / STATE_DIR
    d.mkdir(exist_ok=True)
    shutil.copy2(Path(__file__).resolve(), d / "j2c_patch.py")
    for name, cmd in (("rollback.sh", "rollback"), ("verify.sh", "verify"), ("status.sh", "status"),
                      ("uninstall.sh", "uninstall")):
        s = d / name
        s.write_text(
            "#!/usr/bin/env bash\nset -euo pipefail\nHERE=\"$(cd \"$(dirname \"${BASH_SOURCE[0]}\")\" && pwd)\"\n"
            f"exec python3 \"$HERE/j2c_patch.py\" {cmd} --bot-dir \"{bot}\" \"$@\"\n")
        s.chmod(0o755)


# ------------------------------------------------------------------ rollback
def do_rollback(bot: Path, backup_id: str, *, restore_db: bool, restore_deps: bool, restart: bool,
                auto: bool, svc, python, quiet=False) -> None:
    bdirs = {d.name: d for d in list_backups(bot)}
    if backup_id == "latest":
        live = [d for d in bdirs.values() if not load_json(d / "meta.json", {}).get("rolled_back")]
        if not live:
            raise PatchError("No backups available to roll back to.")
        bdir = live[-1]
    else:
        if backup_id not in bdirs:
            raise PatchError(f"Backup '{backup_id}' not found. See: backups")
        bdir = bdirs[backup_id]
    meta = load_json(bdir / "meta.json")
    say = (lambda s: None) if quiet else ok
    print(_c("1", f"Rolling back to state before {meta['to_version']} (backup {meta['id']})"))
    entry = Path(meta["entry"])
    svc = svc or meta.get("service")
    db = Path(meta["db_path"])

    stopped = False
    if svc and restore_db and svc["kind"] != "custom" and (meta.get("db_backup") or not meta["db_existed"]):
        svc_ctl(svc, "stop")
        stopped = True

    cur = bot / "j2c"
    if cur.exists():
        keep = bdir / "rolled_back_j2c"
        shutil.rmtree(keep, ignore_errors=True)
        shutil.move(str(cur), str(keep))
    if meta["had_j2c_dir"] and (bdir / "j2c_prev").is_dir():
        copytree(bdir / "j2c_prev", cur)
        say("restored previous j2c/ files")
    else:
        say("removed j2c/ (it did not exist before this patch)")

    if entry.exists():
        if auto:
            if meta["entry_injected"]:
                shutil.copy2(bdir / "entry" / entry.name, entry)
                say(f"restored original {entry.name}")
        elif not meta["had_j2c_dir"]:
            if remove_entry_block(entry):
                say(f"removed J2C import block from {entry.name}")

    req = bot / "requirements-j2c.txt"
    if meta["had_requirements"] and (bdir / "requirements-j2c.txt").exists():
        shutil.copy2(bdir / "requirements-j2c.txt", req)
    elif req.exists():
        req.unlink()

    if restore_db:
        if meta.get("db_backup"):
            for f in db_files(db):
                f.unlink(missing_ok=True)
            db.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(bdir / meta["db_backup"], db)
            say("restored J2C database from backup")
        elif not meta["db_existed"]:
            for f in db_files(db):
                f.unlink(missing_ok=True)
            say("removed J2C database created by the failed install")
    elif not auto:
        info("database kept as-is (migrations are additive; older code works with it). Use --restore-db to revert it.")

    if restore_deps and meta["pip"]["changed"] and meta["pip"]["previous"]:
        pyexe = python or meta["pip"].get("python") or sys.executable
        r = sh([pyexe, "-m", "pip", "install", f"discord.py=={meta['pip']['previous']}"], timeout=900)
        say(f"discord.py restored to {meta['pip']['previous']}" if r.returncode == 0
            else f"WARNING: could not restore discord.py=={meta['pip']['previous']}: {r.stderr[-300:]}")

    if svc and (restart or stopped) and svc["kind"] != "custom":
        if stopped and not restart:
            svc_ctl(svc, "start")
        else:
            good, msg = restart_and_check(svc, timeout=30)
            (say if good else warn)(f"service: {msg}")
    elif svc and svc["kind"] == "custom" and restart:
        svc_ctl(svc, "restart")

    meta["rolled_back"] = dt.datetime.now().isoformat(timespec="seconds")
    write_json(bdir / "meta.json", meta)
    history(bot, f"ROLLED BACK {meta['to_version']} backup={meta['id']} auto={auto}")


def rollback_cmd(args) -> int:
    bot = resolve_bot(args)
    with Lock(bot):
        try:
            svc = detect_service(bot, args)
        except PatchError:
            svc = None
        py = None
        try:
            py = find_python(bot, args.python, None)
        except PatchError:
            pass
        try:
            do_rollback(bot, args.backup, restore_db=args.restore_db, restore_deps=args.restore_deps,
                        restart=not args.no_restart, auto=False, svc=svc, python=py)
        except PatchError as e:
            fail(str(e))
            return 1
    print(_c("1;32", "\n✔ Rollback complete."))
    return 0


def uninstall_cmd(args) -> int:
    bot = resolve_bot(args)
    rec = installed_record(bot)
    if not rec:
        fail("J2C is not installed here.")
        return 1
    with Lock(bot):
        try:
            svc = detect_service(bot, args)
        except PatchError:
            svc = None
        entry = Path(rec["entry"])
        if entry.exists() and remove_entry_block(entry):
            ok(f"removed J2C import block from {entry.name}")
        dest = bot / BACKUP_DIR / f"uninstalled_{now_id()}"
        dest.mkdir(parents=True, exist_ok=True)
        shutil.move(str(bot / "j2c"), str(dest / "j2c"))
        (bot / "requirements-j2c.txt").unlink(missing_ok=True)
        ok(f"j2c/ moved to {dest} (database data/j2c.db kept)")
        history(bot, "UNINSTALLED")
        if svc and not args.no_restart:
            good, msg = restart_and_check(svc, timeout=30)
            (ok if good else warn)(f"service: {msg}")
    return 0


# ----------------------------------------------------------- verify / status
def resolve_bot(args) -> Path:
    raw = args.bot_dir or os.environ.get("BOT_DIR")
    if not raw:
        raise PatchError("Pass --bot-dir /path/to/your/bot (or export BOT_DIR).")
    return Path(raw).expanduser().resolve()


def verify_cmd(args) -> int:
    bot = resolve_bot(args)
    bad = 0
    rec = installed_record(bot)
    if not rec:
        fail("J2C is not installed (no j2c/.j2c_install.json).")
        return 1
    ok(f"installed version: {rec['version']} (installed {rec['installed_at']})")
    missing = [f for f, h in rec["files"].items()
               if not (bot / f).is_file() or sha256(bot / f) != h]
    preserved = set((load_json(Path(args.patch_dir) / "patch.json", {}) if args.patch_dir else {}).get("preserve", []))
    missing = [f for f in missing if f not in preserved]
    if missing:
        fail(f"{len(missing)} file(s) missing or modified: " + ", ".join(missing[:8]))
        bad += 1
    else:
        ok(f"all {len(rec['files'])} installed files match their checksums")
    entry = Path(rec["entry"])
    if entry.exists() and BEGIN in entry.read_text(encoding="utf-8", errors="ignore"):
        ok(f"entry integration present in {entry.name}")
    else:
        fail(f"entry integration block missing in {entry} - run apply with --force to re-add it")
        bad += 1
    try:
        py = find_python(bot, args.python, None)
        r = sh([py, "-I", "-c", IMPORT_CHECK, str(bot)], cwd=str(bot))
        if "IMPORT_OK" in r.stdout:
            ok("all J2C modules import with the bot's Python")
        else:
            fail("import check failed:\n" + r.stderr[-800:])
            bad += 1
        db_args = ["--db", str(resolve_db(bot, args))] if args.db else []
        r = sh([py, "-I", "-c", MIGRATE_CODE, str(bot), "--status"] + db_args, cwd=str(bot))
        out = r.stdout.strip().replace("\n", " | ")
        (ok if r.returncode == 0 and "pending: []" in r.stdout else warn)(f"migrations: {out or r.stderr.strip()}")
    except PatchError as e:
        fail(str(e))
        bad += 1
    try:
        svc = detect_service(bot, args)
    except PatchError:
        svc = None
    if svc:
        state = svc_state(svc)
        (ok if state == "active" else fail)(f"service {svc.get('name', svc['kind'])}: {state}")
        bad += state != "active"
        if svc["kind"] in ("systemd", "pm2"):
            if svc["kind"] == "systemd":
                since = time.time() - 6 * 3600
                logs = svc_logs(svc, since)
            else:
                logs = svc_logs(svc, 0)
            if FAIL_MARKER in logs:
                fail("logs contain '[J2C] FAILED' - run: journalctl -u " + svc.get("name", "") + " -n 100")
                bad += 1
            elif READY_MARKER in logs:
                ok("logs contain '[J2C] ready'")
            else:
                warn("no '[J2C] ready' line in recent logs (restart the bot, or the log is not readable by this user)")
    else:
        warn("no service detected; check your bot's logs manually")
    print(_c("1;32", "\nVerification passed.") if not bad else _c("1;31", f"\nVerification found {bad} problem(s)."))
    return 1 if bad else 0


def status_cmd(args) -> int:
    bot = resolve_bot(args)
    rec = installed_record(bot)
    print(f"bot dir : {bot}")
    print(f"J2C     : {rec['version'] + ' (installed ' + rec['installed_at'] + ')' if rec else 'not installed'}")
    for d in list_backups(bot):
        mt = load_json(d / "meta.json", {})
        print(f"backup  : {d.name}{'  [rolled back]' if mt.get('rolled_back') else ''}")
    h = bot / BACKUP_DIR / "history.log"
    if h.exists():
        print("history :\n  " + "\n  ".join(h.read_text().strip().splitlines()[-8:]))
    return 0


# ----------------------------------------------------------------------- CLI
def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="j2c_patch", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    def common(p):
        p.add_argument("--bot-dir", help="path of your existing bot (or export BOT_DIR)")
        p.add_argument("--python", help="python of the bot's venv (auto-detected)")
        p.add_argument("--service", help="service name (auto-detected)")
        p.add_argument("--manager", choices=["systemd", "pm2", "supervisor"], help="service manager for --service")
        p.add_argument("--user-unit", action="store_true", help="--service is a systemd *user* unit")
        p.add_argument("--restart-cmd", help="custom restart command (instead of a detected service)")
        p.add_argument("--db", help="J2C database path (default <bot>/data/j2c.db or $J2C_DB_PATH)")
        p.add_argument("--no-restart", action="store_true")

    a = sub.add_parser("apply", help="install or update J2C")
    common(a)
    a.add_argument("--patch-dir", required=True)
    a.add_argument("--entry", help="bot entry file (auto-detected)")
    a.add_argument("--install-deps", action="store_true", help="pip install/upgrade discord.py if needed")
    a.add_argument("--skip-deps", action="store_true")
    a.add_argument("--dry-run", action="store_true", help="validate only")
    a.add_argument("--force", action="store_true")
    v = sub.add_parser("validate", help="same as apply --dry-run")
    common(v)
    v.add_argument("--patch-dir", required=True)
    v.add_argument("--entry")
    v.add_argument("--install-deps", action="store_true")
    v.add_argument("--skip-deps", action="store_true")
    v.add_argument("--force", action="store_true")
    r = sub.add_parser("rollback", help="restore the state before the last (or a chosen) patch")
    common(r)
    r.add_argument("--backup", default="latest")
    r.add_argument("--restore-db", action="store_true", help="also restore the J2C database from the backup")
    r.add_argument("--restore-deps", action="store_true", help="also restore the previous discord.py version")
    ve = sub.add_parser("verify", help="post-install health checks")
    common(ve)
    ve.add_argument("--patch-dir")
    for n in ("status", "backups"):
        common(sub.add_parser(n))
    common(sub.add_parser("uninstall", help="remove J2C (keeps database + backups)"))
    return ap


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.cmd == "validate":
            args.dry_run = True
            return apply(args)
        return {"apply": apply, "rollback": rollback_cmd, "verify": verify_cmd, "status": status_cmd,
                "backups": status_cmd, "uninstall": uninstall_cmd}[args.cmd](args)
    except PatchError as e:
        fail(str(e))
        return 2


if __name__ == "__main__":
    sys.exit(main())
