#!/usr/bin/env python3
"""Build patch.json + a distributable ZIP from the payload/ folder.

  python3 tools/build_patch.py                       # full patch  -> dist/J2C_PATCH.zip
  python3 tools/build_patch.py --delta-from OLD.zip  # only files changed since OLD.zip
                                                     #   -> dist/J2C_PATCH_<ver>_delta.zip

The version is read from payload/j2c/__init__.py (__version__). Bump it for every
update; the installer refuses downgrades and skips same-version re-applies.
"""
import argparse, hashlib, json, re, sys, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PAYLOAD = ROOT / "payload"
TOP = ["README.md", "VERSION", "install.sh", "rollback.sh", "verify.sh", "patch.json"]
EXEC = {"install.sh", "rollback.sh", "verify.sh", "tools/j2c_patch.py", "tools/build_patch.py"}


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def collect():
    files = {}
    for p in sorted(PAYLOAD.rglob("*")):
        if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc":
            rel = p.relative_to(PAYLOAD).as_posix()
            files[rel] = {"sha256": sha(p), "size": p.stat().st_size}
    return files


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--delta-from")
    ap.add_argument("--requires")
    ap.add_argument("--out", default=str(ROOT / "dist"))
    a = ap.parse_args()
    version = re.search(r'__version__\s*=\s*"([^"]+)"', (PAYLOAD / "j2c/__init__.py").read_text()).group(1)
    files = collect()
    manifest = {"name": "DEATH DEVELOPMENT J2C", "version": version, "mode": "full", "requires_installed": None,
                "min_python": "3.10", "min_discord": "2.6.0", "requirements": ["discord.py>=2.6.0"],
                "preserve": ["j2c/local.json"], "delete": [], "files": files}
    name = "J2C_PATCH.zip"
    if a.delta_from:
        with zipfile.ZipFile(a.delta_from) as z:
            old = json.loads(z.read([n for n in z.namelist() if n.endswith("patch.json")][0]))
        if old["mode"] == "delta":
            sys.exit("--delta-from must be a FULL patch zip")
        changed = {k: v for k, v in files.items() if old["files"].get(k, {}).get("sha256") != v["sha256"]}
        manifest.update(mode="delta", requires_installed=old["version"], files=changed,
                        delete=sorted(set(old["files"]) - set(files)))
        name = f"J2C_PATCH_{version}_delta.zip"
    (ROOT / "patch.json").write_text(json.dumps(manifest, indent=2) + "\n")
    (ROOT / "VERSION").write_text(version + "\n")
    out = Path(a.out)
    out.mkdir(exist_ok=True)
    target = out / name
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as z:
        def add(path, arc):
            zi = zipfile.ZipInfo.from_file(path, "J2C_PATCH/" + arc)
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = ((0o755 if arc in EXEC else 0o644) | 0o100000) << 16
            z.writestr(zi, path.read_bytes())
        for t in TOP:
            if (ROOT / t).exists():
                add(ROOT / t, t)
        for t in ("tools/j2c_patch.py", "tools/build_patch.py"):
            add(ROOT / t, t)
        for rel in manifest["files"]:
            add(PAYLOAD / rel, "payload/" + rel)
    print(f"built {target}  version={version} mode={manifest['mode']} files={len(manifest['files'])}")


if __name__ == "__main__":
    main()
