#!/usr/bin/env bash
# Post-install checks.  ./verify.sh --bot-dir /home/ubuntu/YOUR_BOT
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec python3 "$HERE/tools/j2c_patch.py" verify --patch-dir "$HERE" "$@"
