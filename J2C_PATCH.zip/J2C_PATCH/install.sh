#!/usr/bin/env bash
# DEATH DEVELOPMENT J2C - apply / update the patch.
#   ./install.sh --bot-dir /home/ubuntu/YOUR_BOT [--install-deps] [--service NAME] [--dry-run] [--no-restart]
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
command -v python3 >/dev/null || { echo "python3 is required (sudo apt install -y python3)"; exit 2; }
exec python3 "$HERE/tools/j2c_patch.py" apply --patch-dir "$HERE" "$@"
