"""J2C runtime configuration.

Only reads optional ``J2C_*`` environment variables. It never reads, writes or
modifies your ``.env`` file; if you want to override a default, export the
variable in your service file (Environment=J2C_...) or shell.
"""
from __future__ import annotations

import logging
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent  # the bot directory
ASSETS = Path(__file__).resolve().parent / "assets"
BRAND = "Death Development"
READY_MARKER = "[J2C] ready"
FAIL_MARKER = "[J2C] FAILED"

log = logging.getLogger("j2c")


def _bool(name: str, default: bool) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return v.strip().lower() in ("1", "true", "yes", "on")


def _int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


def _db_path() -> Path:
    raw = os.environ.get("J2C_DB_PATH")
    if not raw:
        return ROOT / "data" / "j2c.db"
    p = Path(raw)
    return p if p.is_absolute() else ROOT / p


DISABLED = _bool("J2C_DISABLE", False)
COMMAND_NAME = os.environ.get("J2C_COMMAND_NAME", "j2c").strip().lower() or "j2c"
DB_PATH = _db_path()
AUTO_SYNC = os.environ.get("J2C_AUTO_SYNC", "auto").strip().lower()  # auto | 0 | 1
CREATE_COOLDOWN = _int("J2C_CREATE_COOLDOWN", 4)   # seconds between creations per user
OWNER_GRACE = _int("J2C_OWNER_GRACE", 30)          # seconds before auto ownership transfer
ACCENT = 0x8B0000
DEFAULT_NAME_TEMPLATE = "{display_name}'s Room"
DEFAULT_DELETE_DELAY = 3
BANNER_FILE = ASSETS / "j2c_buttons.png"
BANNER_NAME = "j2c_buttons.png"


def say(msg: str) -> None:
    """Log + print (flushed) so the line always reaches journald / pm2 logs."""
    log.info(msg)
    print(msg, flush=True)
