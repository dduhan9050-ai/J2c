"""Single-line integration hook.

The patch installer adds ``import j2c.bootstrap`` to your bot's entry file.
Importing this module wraps ``discord.Client.start`` so that, right before the
bot connects, the ``j2c.ext`` extension is loaded. Failures are isolated: if
J2C cannot load, your bot still starts normally and logs ``[J2C] FAILED``.

Set ``J2C_DISABLE=1`` in the environment to turn J2C off without uninstalling.
"""
from __future__ import annotations

import os
import traceback

EXTENSION = "j2c.ext"


def _install() -> None:
    if os.environ.get("J2C_DISABLE", "").strip().lower() in ("1", "true", "yes", "on"):
        print("[J2C] disabled via J2C_DISABLE", flush=True)
        return

    import discord
    from discord.ext import commands

    if getattr(discord.Client, "_j2c_patched", False):
        return

    original = discord.Client.start

    async def start(self, *args, **kwargs):  # type: ignore[no-untyped-def]
        if isinstance(self, commands.Bot) and EXTENSION not in getattr(self, "extensions", {}):
            try:
                await self.load_extension(EXTENSION)
            except Exception as exc:  # never take the bot down
                print(f"[J2C] FAILED to load: {exc!r}", flush=True)
                traceback.print_exc()
        return await original(self, *args, **kwargs)

    start.__wrapped__ = original  # type: ignore[attr-defined]
    discord.Client.start = start  # type: ignore[method-assign]
    discord.Client._j2c_patched = True  # type: ignore[attr-defined]


try:
    _install()
except Exception as _exc:  # pragma: no cover
    print(f"[J2C] FAILED to install bootstrap: {_exc!r}", flush=True)
