"""The J2C control panel (Components V2) and its button actions."""
from __future__ import annotations

import logging

import discord

from .. import __version__, config
from ..services.channels import J2CError
from . import icons
from .pickers import (BITRATES_KBPS, REGIONS, ChoiceView, TemplateView, TextModal, UserPickView)

log = logging.getLogger("j2c.panel")

S, D, P, G = (discord.ButtonStyle.secondary, discord.ButtonStyle.danger,
              discord.ButtonStyle.primary, discord.ButtonStyle.success)

# (section title, [(key, label, style)])  -- mirrors the 4x4 button sheet
SECTIONS = [
    ("🔒 Privacy", [("lock", "Lock", S), ("unlock", "Unlock", S), ("hide", "Hide", S), ("unhide", "Unhide", S)]),
    ("👥 Members", [("limit", "Limit", S), ("invite", "Invite", S), ("ban", "Ban", D), ("permit", "Permit", S)]),
    ("⚙️ Settings", [("rename", "Rename", S), ("bitrate", "Bitrate", S), ("region", "Region", S),
                     ("template", "Template", S)]),
    ("👑 Room", [("chat", "Chat", S), ("waiting", "Waiting", S), ("claim", "Claim", G), ("transfer", "Transfer", P)]),
]


def banner_file() -> discord.File | None:
    try:
        if config.BANNER_FILE.exists():
            return discord.File(str(config.BANNER_FILE), filename=config.BANNER_NAME)
    except Exception:
        log.exception("banner unavailable")
    return None


class PanelView(discord.ui.LayoutView):
    def __init__(self, service, *, owner_id: int | None = None, banner: bool = False):
        super().__init__(timeout=None)
        self.service = service
        self.actions = PanelActions(service)
        header = "## 💀 J2C Control Panel"
        if owner_id:
            header += f"\n👑 Owner: <@{owner_id}>"
        children: list = [discord.ui.TextDisplay(header)]
        if banner:
            try:
                children.append(discord.ui.MediaGallery(
                    discord.MediaGalleryItem(f"attachment://{config.BANNER_NAME}")))
            except Exception:
                log.exception("could not build banner gallery; continuing without it")
        children.append(discord.ui.Separator())
        for title, buttons in SECTIONS:
            children.append(discord.ui.TextDisplay(f"**{title}**"))
            children.append(discord.ui.ActionRow(*[self._button(k, label, style) for k, label, style in buttons]))
        children.append(discord.ui.Separator(visible=False))
        children.append(discord.ui.TextDisplay(
            f"-# {config.BRAND} • J2C v{__version__} • Only the owner can use these controls. "
            "Owner gone? Use **Claim**."))
        self.add_item(discord.ui.Container(*children, accent_colour=discord.Colour(config.ACCENT)))

    def _button(self, key: str, label: str, style: discord.ButtonStyle) -> discord.ui.Button:
        btn = discord.ui.Button(style=style, label=label, custom_id=f"j2c:{key}", emoji=icons.get(key))

        async def callback(interaction: discord.Interaction, _key: str = key) -> None:
            await self.actions.handle(_key, interaction)

        btn.callback = callback  # type: ignore[assignment]
        return btn


class PanelActions:
    def __init__(self, service):
        self.s = service

    async def handle(self, key: str, interaction: discord.Interaction) -> None:
        try:
            await getattr(self, f"do_{key}")(interaction)
        except J2CError as exc:
            await self._say(interaction, f"⚠️ {exc}")
        except discord.Forbidden:
            await self._say(interaction, "⚠️ I'm missing permissions for that. Ask an admin to check my role.")
        except Exception:
            log.exception("J2C panel action %s failed", key)
            await self._say(interaction, "⚠️ Something went wrong. Please try again.")

    @staticmethod
    async def _say(interaction: discord.Interaction, text: str, **kw) -> None:
        if interaction.response.is_done():
            await interaction.followup.send(text, ephemeral=True, **kw)
        else:
            await interaction.response.send_message(text, ephemeral=True, **kw)

    # ---- privacy -------------------------------------------------------
    async def do_lock(self, i):
        ch, rec = await self.s.context(i)
        await i.response.defer(ephemeral=True)
        await self.s.set_lock(ch, rec, True)
        await self._say(i, "🔒 Channel locked. Only permitted users can join.")

    async def do_unlock(self, i):
        ch, rec = await self.s.context(i)
        await i.response.defer(ephemeral=True)
        await self.s.set_lock(ch, rec, False)
        await self._say(i, "🔓 Channel unlocked.")

    async def do_hide(self, i):
        ch, rec = await self.s.context(i)
        await i.response.defer(ephemeral=True)
        await self.s.set_hidden(ch, rec, True)
        await self._say(i, "🙈 Channel hidden from everyone except permitted users and members inside.")

    async def do_unhide(self, i):
        ch, rec = await self.s.context(i)
        await i.response.defer(ephemeral=True)
        await self.s.set_hidden(ch, rec, False)
        await self._say(i, "👁️ Channel is visible again.")

    # ---- members -------------------------------------------------------
    async def do_limit(self, i):
        ch, rec = await self.s.context(i)

        async def submit(inter, value: str):
            try:
                n = int(value.strip())
            except ValueError:
                return await self._say(inter, "⚠️ Enter a number from 0 to 99.")
            try:
                await inter.response.defer(ephemeral=True)
                await self.s.set_limit(ch, n)
                await self._say(inter, f"👥 Limit set to {n or 'unlimited'}.")
            except J2CError as exc:
                await self._say(inter, f"⚠️ {exc}")

        await i.response.send_modal(TextModal(submit, title="User limit", label="Limit (0 = unlimited, max 99)",
                                              placeholder="0-99", max_length=2, default=str(ch.user_limit)))

    async def do_invite(self, i):
        ch, rec = await self.s.context(i)

        async def picked(inter, members):
            await inter.response.defer(ephemeral=True)
            out = []
            for m in members:
                if m.bot:
                    continue
                link = await self.s.invite(ch, rec, m, inter.user)
                out.append(f"{m.mention} invited" + (f" (DMs closed — share: {link})" if link else " via DM"))
            await inter.edit_original_response(content="\n".join(out) or "No valid users selected.", view=None)

        await i.response.send_message("Pick users to invite:", ephemeral=True,
                                      view=UserPickView(picked, author_id=i.user.id, placeholder="Select users to invite"))

    async def do_ban(self, i):
        ch, rec = await self.s.context(i)

        async def picked(inter, members):
            await inter.response.defer(ephemeral=True)
            out = []
            for m in members:
                try:
                    banned = await self.s.ban(ch, rec, m)
                    out.append(f"{'⛔ banned' if banned else '♻️ unbanned'} {m.mention}")
                except J2CError as exc:
                    out.append(f"⚠️ {exc}")
            await inter.edit_original_response(content="\n".join(out), view=None)

        await i.response.send_message("Pick users to ban (pick a banned user again to unban):", ephemeral=True,
                                      view=UserPickView(picked, author_id=i.user.id, placeholder="Select users"))

    async def do_permit(self, i):
        ch, rec = await self.s.context(i)

        async def picked(inter, members):
            await inter.response.defer(ephemeral=True)
            out = []
            for m in members:
                if m.bot:
                    continue
                on = await self.s.permit(ch, rec, m)
                out.append(f"{'✅ permitted' if on else '♻️ removed permit for'} {m.mention}")
            await inter.edit_original_response(content="\n".join(out) or "No valid users selected.", view=None)

        await i.response.send_message("Pick users to permit (pick again to remove):", ephemeral=True,
                                      view=UserPickView(picked, author_id=i.user.id, placeholder="Select users"))

    # ---- settings ------------------------------------------------------
    async def do_rename(self, i):
        ch, rec = await self.s.context(i)

        async def submit(inter, value: str):
            try:
                await inter.response.defer(ephemeral=True)
                new = await self.s.rename(ch, value)
                await self._say(inter, f"✏️ Renamed to **{new}**.")
            except J2CError as exc:
                await self._say(inter, f"⚠️ {exc}")

        await i.response.send_modal(TextModal(submit, title="Rename channel", label="New name",
                                              placeholder="My room", max_length=100, default=ch.name[:100]))

    async def do_bitrate(self, i):
        ch, rec = await self.s.context(i)
        limit = ch.guild.bitrate_limit // 1000
        options = [discord.SelectOption(label=f"{k} kbps", value=str(k * 1000), default=ch.bitrate == k * 1000)
                   for k in BITRATES_KBPS if k <= limit]

        async def chosen(inter, value: str):
            await inter.response.defer(ephemeral=True)
            await self.s.set_bitrate(ch, int(value))
            await inter.edit_original_response(content=f"🎧 Bitrate set to {int(value) // 1000} kbps.", view=None)

        await i.response.send_message("Choose a bitrate:", ephemeral=True, view=ChoiceView(
            chosen, author_id=i.user.id, placeholder="Bitrate", options=options))

    async def do_region(self, i):
        ch, rec = await self.s.context(i)
        options = [discord.SelectOption(label=label, value=value or "auto", default=(ch.rtc_region == value))
                   for label, value in REGIONS]

        async def chosen(inter, value: str):
            await inter.response.defer(ephemeral=True)
            await self.s.set_region(ch, None if value == "auto" else value)
            await inter.edit_original_response(content=f"🌐 Region set to **{value}**.", view=None)

        await i.response.send_message("Choose a voice region:", ephemeral=True, view=ChoiceView(
            chosen, author_id=i.user.id, placeholder="Region", options=options))

    async def do_template(self, i):
        ch, rec = await self.s.context(i)
        await i.response.send_message(
            "📋 **Template** — save this room's name, limit, bitrate, region and privacy as your default. "
            "It's applied automatically next time you join the hub.",
            ephemeral=True, view=TemplateView(self.s, ch, rec, i.user.id))

    # ---- room ----------------------------------------------------------
    async def do_chat(self, i):
        ch, rec = await self.s.context(i)
        await i.response.defer(ephemeral=True)
        await self.s.set_chat_locked(ch, rec, not rec.chat_locked)
        await self._say(i, "💬 Text chat is now **locked** (owner only)." if rec.chat_locked
                        else "💬 Text chat is now **open**.")

    async def do_waiting(self, i):
        ch, rec = await self.s.context(i)
        await i.response.defer(ephemeral=True)
        on = await self.s.toggle_waiting(ch, rec)
        await self._say(i, "⏳ Waiting room **enabled**. Pair it with Lock: people wait there and you approve them."
                        if on else "⏳ Waiting room **removed**.")

    async def do_claim(self, i):
        ch, rec = await self.s.context(i, owner_only=False)
        await i.response.defer(ephemeral=True)
        await self.s.claim(ch, rec, i.user)
        await self._say(i, "👑 You are now the owner.")

    async def do_transfer(self, i):
        ch, rec = await self.s.context(i)

        async def picked(inter, members):
            if not members:
                return await inter.response.edit_message(content="No valid user selected.", view=None)
            await inter.response.defer(ephemeral=True)
            try:
                await self.s.transfer(ch, rec, members[0])
                msg = f"👑 Ownership transferred to {members[0].mention}."
            except J2CError as exc:
                msg = f"⚠️ {exc}"
            await inter.edit_original_response(content=msg, view=None)

        await i.response.send_message("Pick the new owner (must be in the channel):", ephemeral=True,
                                      view=UserPickView(picked, author_id=i.user.id, placeholder="New owner",
                                                        max_values=1))
