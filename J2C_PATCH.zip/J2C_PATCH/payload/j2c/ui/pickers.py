"""Modals, selects and the waiting-room approval view (ephemeral / transient UI)."""
from __future__ import annotations

import discord

from .. import config

REGIONS = [
    ("Automatic", None), ("US East", "us-east"), ("US West", "us-west"), ("US Central", "us-central"),
    ("US South", "us-south"), ("Brazil", "brazil"), ("Rotterdam (EU)", "rotterdam"), ("Russia", "russia"),
    ("India", "india"), ("Singapore", "singapore"), ("Hong Kong", "hongkong"), ("Japan", "japan"),
    ("South Korea", "south-korea"), ("Sydney", "sydney"), ("South Africa", "southafrica"),
]
BITRATES_KBPS = [8, 16, 24, 32, 48, 64, 96, 128, 256, 384]


class TextModal(discord.ui.Modal):
    def __init__(self, handler, *, title: str, label: str, placeholder: str = "",
                 min_length: int = 1, max_length: int = 100, default: str | None = None):
        super().__init__(title=title, timeout=300)
        self.handler = handler
        self.field = discord.ui.TextInput(label=label, placeholder=placeholder, min_length=min_length,
                                          max_length=max_length, default=default, required=True)
        self.add_item(self.field)

    async def on_submit(self, interaction: discord.Interaction) -> None:
        await self.handler(interaction, str(self.field.value))


class UserPickView(discord.ui.View):
    def __init__(self, handler, *, author_id: int, placeholder: str, max_values: int = 5):
        super().__init__(timeout=120)
        self.handler, self.author_id = handler, author_id
        self.select = discord.ui.UserSelect(placeholder=placeholder, min_values=1, max_values=max_values)
        self.select.callback = self._picked
        self.add_item(self.select)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        return interaction.user.id == self.author_id

    async def _picked(self, interaction: discord.Interaction) -> None:
        members = []
        for u in self.select.values:
            m = interaction.guild.get_member(u.id)
            if m is None:
                try:
                    m = await interaction.guild.fetch_member(u.id)
                except discord.HTTPException:
                    continue
            members.append(m)
        await self.handler(interaction, members)


class ChoiceView(discord.ui.View):
    """One string-select; handler receives the chosen value."""

    def __init__(self, handler, *, author_id: int, placeholder: str, options: list[discord.SelectOption]):
        super().__init__(timeout=120)
        self.handler, self.author_id = handler, author_id
        self.select = discord.ui.Select(placeholder=placeholder, options=options[:25])
        self.select.callback = self._chosen
        self.add_item(self.select)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        return interaction.user.id == self.author_id

    async def _chosen(self, interaction: discord.Interaction) -> None:
        await self.handler(interaction, self.select.values[0])


class TemplateView(discord.ui.View):
    def __init__(self, service, ch, rec, author_id: int):
        super().__init__(timeout=120)
        self.service, self.ch, self.rec, self.author_id = service, ch, rec, author_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        return interaction.user.id == self.author_id

    @discord.ui.button(label="Save current settings", style=discord.ButtonStyle.success, emoji="💾")
    async def save(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.service.save_template(self.ch, self.rec, interaction.user.id)
        await interaction.response.edit_message(
            content="💾 Saved. Your next J2C room will be created with these settings.", view=None)

    @discord.ui.button(label="Apply saved", style=discord.ButtonStyle.primary, emoji="📋")
    async def apply(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        profile = await self.service.repo.get_profile(self.ch.guild.id, interaction.user.id)
        if profile is None:
            return await interaction.response.edit_message(content="You have no saved template yet.", view=None)
        await interaction.response.defer()
        await self.service.apply_template(self.ch, self.rec, profile)
        await interaction.edit_original_response(content="📋 Template applied.", view=None)

    @discord.ui.button(label="Reset template", style=discord.ButtonStyle.danger, emoji="🗑️")
    async def reset(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        await self.service.repo.delete_profile(self.ch.guild.id, interaction.user.id)
        await interaction.response.edit_message(content="🗑️ Template removed.", view=None)


class WaitingApprovalView(discord.ui.View):
    def __init__(self, service, owner_id: int, user_id: int, main_id: int, waiting_id: int):
        super().__init__(timeout=300)
        self.service, self.owner_id, self.user_id = service, owner_id, user_id
        self.main_id, self.waiting_id = main_id, waiting_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        rec = self.service.temp.get(self.main_id)
        ok = rec is not None and (interaction.user.id == rec.owner_id
                                  or interaction.user.guild_permissions.manage_guild)
        if not ok:
            await interaction.response.send_message("Only the channel owner can decide.", ephemeral=True)
        return ok

    def _member(self, interaction):
        m = interaction.guild.get_member(self.user_id)
        if m is None or m.voice is None or m.voice.channel is None or m.voice.channel.id != self.waiting_id:
            return None
        return m

    @discord.ui.button(label="Approve", style=discord.ButtonStyle.success, emoji="✅")
    async def approve(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        m, main = self._member(interaction), interaction.guild.get_channel(self.main_id)
        if m is None or main is None:
            return await interaction.response.edit_message(content="They already left the waiting room.", view=None)
        rec = self.service.temp[self.main_id]
        if await self.service.repo.acl_get(main.id, m.id) != "permit":
            await self.service.permit(main, rec, m)
        await m.move_to(main, reason="J2C: approved from waiting room")
        await interaction.response.edit_message(content=f"✅ {m.mention} was let in.", view=None)

    @discord.ui.button(label="Deny", style=discord.ButtonStyle.danger, emoji="⛔")
    async def deny(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        m = self._member(interaction)
        if m is not None:
            await self.service._safe_disconnect(m, "J2C: denied from waiting room")
        await interaction.response.edit_message(content="⛔ Request denied.", view=None)
