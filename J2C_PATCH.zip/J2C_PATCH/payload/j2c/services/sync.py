"""Safe application-command sync.

Syncing the global tree blindly could duplicate commands for bots that sync per
guild. So J2C only auto-syncs when it is provably safe:
  * the bot's other slash commands are already registered globally, or
  * the bot has no other slash commands at all.
Otherwise it logs a notice and your existing sync mechanism picks J2C up.
"""
from __future__ import annotations

import hashlib

from .. import __version__, config

META_KEY = "command_sync_hash"


def _fingerprint(bot) -> str:
    names = sorted(c.qualified_name for c in bot.tree.walk_commands())
    return hashlib.sha256(f"{__version__}|{config.COMMAND_NAME}|{names}".encode()).hexdigest()[:16]


async def maybe_sync(bot, repo) -> str:
    mode = config.AUTO_SYNC
    if mode in ("0", "off", "false", "no"):
        return "auto-sync disabled (J2C_AUTO_SYNC=0)"
    fp = _fingerprint(bot)
    if mode == "auto" and await repo.meta_get(META_KEY) == fp:
        return "commands already synced"
    local_other = {c.name for c in bot.tree.get_commands() if c.name != config.COMMAND_NAME}
    if mode == "auto":
        remote = {c.name for c in await bot.tree.fetch_commands()}
        if local_other and not local_other <= remote:
            return ("skipped auto-sync: your bot's slash commands are not registered globally; "
                    "run your normal sync so /%s appears" % config.COMMAND_NAME)
    await bot.tree.sync()
    await repo.meta_set(META_KEY, fp)
    return "synced application commands"
