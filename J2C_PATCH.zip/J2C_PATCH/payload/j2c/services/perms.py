"""Permission helpers."""
from __future__ import annotations

REQUIRED_BOT_PERMS = {
    "manage_channels": "Manage Channels",
    "manage_roles": "Manage Permissions (Manage Roles)",
    "move_members": "Move Members",
    "view_channel": "View Channels",
    "connect": "Connect",
    "send_messages": "Send Messages",
}


def missing_bot_perms(guild) -> list[str]:
    perms = guild.me.guild_permissions
    if perms.administrator:
        return []
    return [label for attr, label in REQUIRED_BOT_PERMS.items() if not getattr(perms, attr, False)]
