"""Forward-only SQL migration runner (stdlib only).

Usage (from the bot directory):
    python -m j2c.db.migrate            # apply pending migrations
    python -m j2c.db.migrate --status   # show applied / pending
    python -m j2c.db.migrate --db /path/to/j2c.db

Rules every migration follows: additive only (new tables / nullable or defaulted
columns), so older J2C code keeps working on a newer schema and rollbacks never
require a schema downgrade. Applied migrations are checksummed; editing one
after it ran is detected and refused.
"""
from __future__ import annotations

import argparse
import hashlib
import re
import sqlite3
import sys
import time
from pathlib import Path

MIGRATIONS_DIR = Path(__file__).resolve().parent / "migrations"
_NAME = re.compile(r"^(\d{4})_([a-z0-9_]+)\.sql$")


class MigrationError(RuntimeError):
    pass


def discover(directory: Path = MIGRATIONS_DIR) -> list[tuple[int, str, Path]]:
    found = []
    for p in sorted(directory.glob("*.sql")):
        m = _NAME.match(p.name)
        if not m:
            raise MigrationError(f"Bad migration filename: {p.name}")
        found.append((int(m.group(1)), m.group(2), p))
    versions = [v for v, _, _ in found]
    if len(versions) != len(set(versions)):
        raise MigrationError("Duplicate migration version numbers")
    return found


def _checksum(text: str) -> str:
    return hashlib.sha256(text.replace("\r\n", "\n").encode()).hexdigest()


def _ensure_table(conn: sqlite3.Connection) -> None:
    conn.execute(
        "CREATE TABLE IF NOT EXISTS j2c_schema_migrations ("
        "version INTEGER PRIMARY KEY, name TEXT NOT NULL, checksum TEXT NOT NULL, "
        "applied_at INTEGER NOT NULL)"
    )


def status(db_path: Path | str) -> tuple[list[int], list[int]]:
    conn = sqlite3.connect(str(db_path), isolation_level=None)
    try:
        _ensure_table(conn)
        applied = {r[0] for r in conn.execute("SELECT version FROM j2c_schema_migrations")}
    finally:
        conn.close()
    known = [v for v, _, _ in discover()]
    return sorted(applied), [v for v in known if v not in applied]


def migrate(db_path: Path | str, log=print) -> list[str]:
    db_path = Path(db_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path), isolation_level=None, timeout=30)
    applied_now: list[str] = []
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        _ensure_table(conn)
        applied = {r[0]: r[1] for r in conn.execute("SELECT version, checksum FROM j2c_schema_migrations")}
        known = discover()
        newest_known = max((v for v, _, _ in known), default=0)
        if applied and max(applied) > newest_known:
            log(f"[J2C] note: database schema v{max(applied)} is newer than this code (v{newest_known}); "
                "continuing (migrations are additive).")
        for version, name, path in known:
            sql = path.read_text(encoding="utf-8")
            digest = _checksum(sql)
            if version in applied:
                if applied[version] != digest:
                    raise MigrationError(
                        f"Migration {path.name} was modified after being applied "
                        f"(checksum mismatch). Refusing to continue.")
                continue
            script = (
                "BEGIN IMMEDIATE;\n" + sql + "\n"
                f"INSERT INTO j2c_schema_migrations(version,name,checksum,applied_at) "
                f"VALUES({int(version)},'{name}','{digest}',{int(time.time())});\nCOMMIT;"
            )
            try:
                conn.executescript(script)
            except Exception as exc:
                try:
                    conn.execute("ROLLBACK")
                except sqlite3.Error:
                    pass
                raise MigrationError(f"Migration {path.name} failed: {exc}") from exc
            applied_now.append(path.name)
            log(f"[J2C] migration applied: {path.name}")
    finally:
        conn.close()
    return applied_now


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="j2c.db.migrate")
    ap.add_argument("--db", help="database path (default: J2C_DB_PATH or <bot>/data/j2c.db)")
    ap.add_argument("--status", action="store_true")
    args = ap.parse_args(argv)
    if args.db:
        db = Path(args.db)
    else:
        from .. import config
        db = config.DB_PATH
    try:
        if args.status:
            applied, pending = status(db)
            print(f"database: {db}\napplied: {applied}\npending: {pending}")
            return 0
        done = migrate(db)
        print(f"[J2C] migrations up to date ({len(done)} applied now) -> {db}")
        return 0
    except MigrationError as exc:
        print(f"[J2C] MIGRATION ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
