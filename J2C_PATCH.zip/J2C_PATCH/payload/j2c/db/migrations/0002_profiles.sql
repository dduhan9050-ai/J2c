-- J2C 0002: per-user saved room templates (the "Template" button).
CREATE TABLE j2c_profiles (
    guild_id    INTEGER NOT NULL,
    user_id     INTEGER NOT NULL,
    name        TEXT,
    user_limit  INTEGER,
    bitrate     INTEGER,
    rtc_region  TEXT,
    locked      INTEGER NOT NULL DEFAULT 0,
    hidden      INTEGER NOT NULL DEFAULT 0,
    chat_locked INTEGER NOT NULL DEFAULT 0,
    updated_at  INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    PRIMARY KEY (guild_id, user_id)
);
