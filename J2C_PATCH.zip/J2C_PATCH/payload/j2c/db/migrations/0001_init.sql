-- J2C 0001: core tables. All tables are prefixed j2c_ and never touch bot tables.
CREATE TABLE j2c_guilds (
    guild_id        INTEGER PRIMARY KEY,
    name_template   TEXT    NOT NULL DEFAULT '{display_name}''s Room',
    default_limit   INTEGER NOT NULL DEFAULT 0,
    default_bitrate INTEGER,
    banner          INTEGER NOT NULL DEFAULT 1,
    auto_transfer   INTEGER NOT NULL DEFAULT 1,
    delete_delay    INTEGER NOT NULL DEFAULT 3,
    max_per_user    INTEGER NOT NULL DEFAULT 1,
    enabled         INTEGER NOT NULL DEFAULT 1,
    created_at      INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    updated_at      INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

CREATE TABLE j2c_hubs (
    channel_id  INTEGER PRIMARY KEY,
    guild_id    INTEGER NOT NULL,
    category_id INTEGER,
    created_at  INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);
CREATE INDEX idx_j2c_hubs_guild ON j2c_hubs(guild_id);

CREATE TABLE j2c_channels (
    channel_id         INTEGER PRIMARY KEY,
    guild_id           INTEGER NOT NULL,
    owner_id           INTEGER NOT NULL,
    waiting_channel_id INTEGER,
    locked             INTEGER NOT NULL DEFAULT 0,
    hidden             INTEGER NOT NULL DEFAULT 0,
    chat_locked        INTEGER NOT NULL DEFAULT 0,
    panel_message_id   INTEGER,
    owner_left_at      INTEGER,
    created_at         INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);
CREATE INDEX idx_j2c_channels_owner ON j2c_channels(guild_id, owner_id);

CREATE TABLE j2c_acl (
    channel_id INTEGER NOT NULL,
    user_id    INTEGER NOT NULL,
    kind       TEXT    NOT NULL CHECK (kind IN ('permit','ban')),
    created_at INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    PRIMARY KEY (channel_id, user_id),
    FOREIGN KEY (channel_id) REFERENCES j2c_channels(channel_id) ON DELETE CASCADE
);

CREATE TABLE j2c_meta (
    key   TEXT PRIMARY KEY,
    value TEXT
);
