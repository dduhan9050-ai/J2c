"""Tiny async wrapper over stdlib sqlite3 (no extra dependency needed)."""
from __future__ import annotations

import asyncio
import sqlite3
from pathlib import Path
from typing import Any, Iterable


class Database:
    def __init__(self, path: Path | str):
        self.path = Path(path)
        self._conn: sqlite3.Connection | None = None
        self._lock = asyncio.Lock()

    async def connect(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)

        def _open() -> sqlite3.Connection:
            c = sqlite3.connect(str(self.path), check_same_thread=False, isolation_level=None, timeout=30)
            c.row_factory = sqlite3.Row
            c.execute("PRAGMA journal_mode=WAL")
            c.execute("PRAGMA foreign_keys=ON")
            c.execute("PRAGMA busy_timeout=30000")
            return c

        self._conn = await asyncio.to_thread(_open)

    async def execute(self, sql: str, params: Iterable[Any] = ()) -> tuple[int, int | None]:
        assert self._conn is not None, "Database not connected"
        async with self._lock:
            def _run() -> tuple[int, int | None]:
                cur = self._conn.execute(sql, tuple(params))
                return cur.rowcount, cur.lastrowid
            return await asyncio.to_thread(_run)

    async def fetchone(self, sql: str, params: Iterable[Any] = ()) -> sqlite3.Row | None:
        assert self._conn is not None, "Database not connected"
        async with self._lock:
            return await asyncio.to_thread(lambda: self._conn.execute(sql, tuple(params)).fetchone())

    async def fetchall(self, sql: str, params: Iterable[Any] = ()) -> list[sqlite3.Row]:
        assert self._conn is not None, "Database not connected"
        async with self._lock:
            return await asyncio.to_thread(lambda: self._conn.execute(sql, tuple(params)).fetchall())

    async def close(self) -> None:
        if self._conn is not None:
            conn, self._conn = self._conn, None
            await asyncio.to_thread(conn.close)
