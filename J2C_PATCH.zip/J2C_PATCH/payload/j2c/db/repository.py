"""Data access for J2C. All SQL lives here."""
from __future__ import annotations

from typing import Any

from .database import Database
from .models import GuildSettings, Hub, Profile, TempChannel

GUILD_FIELDS = {"name_template", "default_limit", "default_bitrate", "banner",
                "auto_transfer", "delete_delay", "max_per_user", "enabled"}
CHANNEL_FIELDS = {"owner_id", "waiting_channel_id", "locked", "hidden", "chat_locked",
                  "panel_message_id", "owner_left_at"}
PROFILE_FIELDS = {"name", "user_limit", "bitrate", "rtc_region", "locked", "hidden", "chat_locked"}


def _val(v: Any) -> Any:
    return int(v) if isinstance(v, bool) else v


def _check(fields: dict, allowed: set[str]) -> None:
    bad = set(fields) - allowed
    if bad:
        raise ValueError(f"Unknown fields: {sorted(bad)}")


class Repository:
    def __init__(self, db: Database):
        self.db = db

    # ---- guild settings -------------------------------------------------
    async def get_guild(self, guild_id: int) -> GuildSettings:
        row = await self.db.fetchone("SELECT * FROM j2c_guilds WHERE guild_id=?", (guild_id,))
        return GuildSettings.from_row(row) if row else GuildSettings(guild_id)

    async def update_guild(self, guild_id: int, **fields: Any) -> GuildSettings:
        _check(fields, GUILD_FIELDS)
        if fields:
            cols = list(fields)
            ph = ",".join("?" for _ in cols)
            upd = ",".join(f"{c}=excluded.{c}" for c in cols)
            await self.db.execute(
                f"INSERT INTO j2c_guilds(guild_id,{','.join(cols)}) VALUES(?,{ph}) "
                f"ON CONFLICT(guild_id) DO UPDATE SET {upd}, updated_at=strftime('%s','now')",
                (guild_id, *[_val(fields[c]) for c in cols]),
            )
        else:
            await self.db.execute("INSERT OR IGNORE INTO j2c_guilds(guild_id) VALUES(?)", (guild_id,))
        return await self.get_guild(guild_id)

    async def reset_guild(self, guild_id: int) -> None:
        await self.db.execute("DELETE FROM j2c_hubs WHERE guild_id=?", (guild_id,))
        await self.db.execute("DELETE FROM j2c_guilds WHERE guild_id=?", (guild_id,))

    # ---- hubs ------------------------------------------------------------
    async def add_hub(self, channel_id: int, guild_id: int, category_id: int | None) -> Hub:
        await self.db.execute(
            "INSERT INTO j2c_hubs(channel_id,guild_id,category_id) VALUES(?,?,?) "
            "ON CONFLICT(channel_id) DO UPDATE SET category_id=excluded.category_id",
            (channel_id, guild_id, category_id))
        return Hub(channel_id, guild_id, category_id)

    async def remove_hub(self, channel_id: int) -> bool:
        n, _ = await self.db.execute("DELETE FROM j2c_hubs WHERE channel_id=?", (channel_id,))
        return n > 0

    async def list_hubs(self, guild_id: int | None = None) -> list[Hub]:
        if guild_id is None:
            rows = await self.db.fetchall("SELECT * FROM j2c_hubs")
        else:
            rows = await self.db.fetchall("SELECT * FROM j2c_hubs WHERE guild_id=?", (guild_id,))
        return [Hub.from_row(r) for r in rows]

    # ---- temp channels ---------------------------------------------------
    async def add_channel(self, channel_id: int, guild_id: int, owner_id: int, **fields: Any) -> TempChannel:
        _check(fields, CHANNEL_FIELDS - {"owner_id"})
        cols = ["channel_id", "guild_id", "owner_id", *fields]
        await self.db.execute(
            f"INSERT OR REPLACE INTO j2c_channels({','.join(cols)}) VALUES({','.join('?' for _ in cols)})",
            (channel_id, guild_id, owner_id, *[_val(v) for v in fields.values()]))
        return (await self.get_channel(channel_id))  # type: ignore[return-value]

    async def get_channel(self, channel_id: int) -> TempChannel | None:
        row = await self.db.fetchone("SELECT * FROM j2c_channels WHERE channel_id=?", (channel_id,))
        return TempChannel.from_row(row) if row else None

    async def list_channels(self, guild_id: int | None = None) -> list[TempChannel]:
        if guild_id is None:
            rows = await self.db.fetchall("SELECT * FROM j2c_channels")
        else:
            rows = await self.db.fetchall("SELECT * FROM j2c_channels WHERE guild_id=?", (guild_id,))
        return [TempChannel.from_row(r) for r in rows]

    async def update_channel(self, channel_id: int, **fields: Any) -> None:
        _check(fields, CHANNEL_FIELDS)
        if not fields:
            return
        sets = ",".join(f"{c}=?" for c in fields)
        await self.db.execute(f"UPDATE j2c_channels SET {sets} WHERE channel_id=?",
                              (*[_val(v) for v in fields.values()], channel_id))

    async def delete_channel(self, channel_id: int) -> None:
        await self.db.execute("DELETE FROM j2c_channels WHERE channel_id=?", (channel_id,))

    # ---- ACL (permit / ban) ---------------------------------------------
    async def acl_set(self, channel_id: int, user_id: int, kind: str) -> None:
        await self.db.execute(
            "INSERT INTO j2c_acl(channel_id,user_id,kind) VALUES(?,?,?) "
            "ON CONFLICT(channel_id,user_id) DO UPDATE SET kind=excluded.kind",
            (channel_id, user_id, kind))

    async def acl_remove(self, channel_id: int, user_id: int) -> None:
        await self.db.execute("DELETE FROM j2c_acl WHERE channel_id=? AND user_id=?", (channel_id, user_id))

    async def acl_get(self, channel_id: int, user_id: int) -> str | None:
        row = await self.db.fetchone("SELECT kind FROM j2c_acl WHERE channel_id=? AND user_id=?",
                                     (channel_id, user_id))
        return row["kind"] if row else None

    async def acl_list(self, channel_id: int, kind: str | None = None) -> list[tuple[int, str]]:
        if kind:
            rows = await self.db.fetchall("SELECT user_id,kind FROM j2c_acl WHERE channel_id=? AND kind=?",
                                          (channel_id, kind))
        else:
            rows = await self.db.fetchall("SELECT user_id,kind FROM j2c_acl WHERE channel_id=?", (channel_id,))
        return [(r["user_id"], r["kind"]) for r in rows]

    # ---- profiles (templates) -------------------------------------------
    async def get_profile(self, guild_id: int, user_id: int) -> Profile | None:
        row = await self.db.fetchone("SELECT * FROM j2c_profiles WHERE guild_id=? AND user_id=?",
                                     (guild_id, user_id))
        return Profile.from_row(row) if row else None

    async def save_profile(self, guild_id: int, user_id: int, **fields: Any) -> None:
        _check(fields, PROFILE_FIELDS)
        cols = list(fields)
        upd = ",".join(f"{c}=excluded.{c}" for c in cols)
        await self.db.execute(
            f"INSERT INTO j2c_profiles(guild_id,user_id,{','.join(cols)}) "
            f"VALUES(?,?,{','.join('?' for _ in cols)}) "
            f"ON CONFLICT(guild_id,user_id) DO UPDATE SET {upd}, updated_at=strftime('%s','now')",
            (guild_id, user_id, *[_val(fields[c]) for c in cols]))

    async def delete_profile(self, guild_id: int, user_id: int) -> None:
        await self.db.execute("DELETE FROM j2c_profiles WHERE guild_id=? AND user_id=?", (guild_id, user_id))

    # ---- meta -------------------------------------------------------------
    async def meta_get(self, key: str) -> str | None:
        row = await self.db.fetchone("SELECT value FROM j2c_meta WHERE key=?", (key,))
        return row["value"] if row else None

    async def meta_set(self, key: str, value: str) -> None:
        await self.db.execute(
            "INSERT INTO j2c_meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value))
