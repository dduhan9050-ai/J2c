"""Event listeners (voice-state, channel and guild lifecycle)."""
from __future__ import annotations

import discord
from discord.ext import commands


class J2CEvents(commands.Cog, name="J2C Events"):
    def __init__(self, service):
        self.service = service

    @commands.Cog.listener()
    async def on_voice_state_update(self, member: discord.Member, before: discord.VoiceState,
                                    after: discord.VoiceState) -> None:
        await self.service.on_voice_state(member, before, after)

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel) -> None:
        if self.service.loaded:
            await self.service.on_channel_delete(channel)

    @commands.Cog.listener()
    async def on_guild_remove(self, guild: discord.Guild) -> None:
        if self.service.loaded:
            await self.service.on_guild_remove(guild)
