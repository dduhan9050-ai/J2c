"""discord.py extension entry point: ``await bot.load_extension("j2c.ext")``.

Loaded automatically by ``j2c.bootstrap`` (installed into your entry file by the
patcher). You can also load it yourself from your own setup_hook instead.
"""
from __future__ import annotations

import asyncio
import logging

from discord.ext import commands

from . import __version__, config
from .db.database import Database
from .db.migrate import migrate
from .db.repository import Repository
from .services.channels import J2CService

log = logging.getLogger("j2c")


async def setup(bot: commands.Bot) -> None:
    if config.DISABLED:
        config.say("[J2C] disabled via J2C_DISABLE")
        return
    if not getattr(bot.intents, "voice_states", False):
        raise RuntimeError("J2C needs the voice_states intent (discord.Intents.voice_states = True).")
    if not getattr(bot.intents, "guilds", False):
        raise RuntimeError("J2C needs the guilds intent.")

    await asyncio.to_thread(migrate, config.DB_PATH, config.say)
    db = Database(config.DB_PATH)
    await db.connect()
    repo = Repository(db)
    service = J2CService(bot, repo)
    await service.load_cache()

    from .cogs.commands import J2CCommands
    from .cogs.events import J2CEvents

    await bot.add_cog(J2CEvents(service))
    try:
        await bot.add_cog(J2CCommands(service))
    except commands.CommandRegistrationError as exc:
        config.say(f"[J2C] WARNING: command '/{config.COMMAND_NAME}' conflicts with an existing command ({exc}). "
                   "Set J2C_COMMAND_NAME to another name. Voice features still work.")

    bot._j2c_service = service  # type: ignore[attr-defined]
    bot._j2c_db = db  # type: ignore[attr-defined]
    service.start_background()
    config.say(f"{config.READY_MARKER} v{__version__} db={config.DB_PATH} command=/{config.COMMAND_NAME} "
               f"hubs={len(service.hubs)} rooms={len(service.temp)}")


async def teardown(bot: commands.Bot) -> None:
    service = getattr(bot, "_j2c_service", None)
    db = getattr(bot, "_j2c_db", None)
    for name in ("J2C", "J2C Events"):
        await bot.remove_cog(name)
    if service:
        await service.shutdown()
    if db:
        await db.close()
